/*
 * Copyright (C) 2012, Nokia gate5 GmbH Berlin
 *
 * These coded instructions, statements, and computer programs contain
 * unpublished proprietary information of Nokia gate5 GmbH, and are
 * copy protected by law. They may not be disclosed to third parties
 * or copied or duplicated in any form, in whole or in part, without
 * the specific, prior written permission of Nokia gate5 GmbH.
 */ (function(g, a, b, c, e) {
    var i = e.call([]);
    if (!g.isArray) g.isArray = function(a) {
        return e.call(a) === i
    };
    if (!b.trim) b.trim = function() {
        return this.replace(/^\s*/, "").replace(/\s*$/, "")
    };
    if (!a.bind) a.bind = function(a) {
        var d = this,
            e;
        return 1 < arguments.length ? (e = c.call(arguments, 1), function() {
            return d.apply(a, arguments.length ? e.concat(c.call(arguments)) : e)
        }) : function() {
            return arguments.length ? d.apply(a, arguments) : d.call(a)
        }
    };
    window.history.pushState ||
    function(a, d) {
        function e(a, b, c, i) {
            f.setStorage(c, {
                state: a,
                title: b
            });
            f.hash = c;
            i ? (c || (c = d.hash || "#"), d.replace(c)) : d.hash = c
        }
        if (!("pushState" in a.history)) {
            var f = {};
            "sessionStorage" in a && a.JSON ? (f.setStorage = function(d, f) {
                a.sessionStorage[d] = JSON.stringify(f)
            }, f.getStorage = function(d) {
                return a.sessionStorage[d] ? JSON.parse(a.sessionStorage[d]) : void 0
            }) : (f.fake_storage = {}, f.setStorage = function(a, d) {
                f.fake_storage[a] = d
            }, f.getStorage = function(a) {
                return f.fake_storage[a]
            });
            a.history.pushState = function(a, d, f) {
                e(a, d, f, !1)
            };
            a.history.replaceState = function(a, d, f) {
                e(a, d, f, !0)
            };
            f.hashchange = function() {
                var e = d.hash;
                if (e !== f.hash) f.hash = e, e = f.hash ? f.getStorage(f.hash) : {}, "onpopstate" in a && "function" === typeof a.onpopstate && a.onpopstate.apply(a, [{
                    state: e ? e.state : null
                }])
            };
            "onhashchange" in a ? a.onhashchange = f.hashchange : f.hashInterval = setInterval(function() {
                d.hash !== f.hash && f.hashchange()
            }, 100);
            d.hash && f.hashchange()
        }
    }(window, document.location)
})(Array, Function.prototype, String.prototype, [].slice, {}.toString);
(function() {
    if (!this.nokia || !this.nokia.mh5) {
        var g = {},
            a = {},
            b = b || this.mh5Config || {};
        nokia = this.nokia || {};
        nokia.mh5 = this.nokia.mh5 = {
            assetsPath: "./fw/",
            win: b.win || this,
            doc: b.doc || this.document,
            modulePaths: b.modulePaths || {},
            buildNS: function(a) {
                var c;
                for (var a = a.split("."), e = 0, b = nokia.mh5.win, h; h = a[e++];) c = b[h] = b[h] || {
                    isNs: !0
                }, b = c;
                return b
            },
            provide: function(b) {
                a[b] = 1;
                return nokia.mh5.buildNS(b)
            },
            require: function(b) {
                if (a[b]) return nokia.mh5.resolve(b);
                if (g[b]) throw Error("Circular Reference in require chain: " + g);
                g[b] = 1;
                nokia.mh5.buildNS(b);
                var e = nokia.mh5.getLoadPath(b);
                try {
                    nokia.mh5._getScript(e)
                } catch (i) {
                    throw Error("Could not load " + b + ", reason: " + i.message);
                } finally {
                    delete g[b]
                }
                a[b] || (a[b] = 1);
                return nokia.mh5.resolve(b)
            },
            _getScript: function(a) {
                var b = new XMLHttpRequest;
                b.open("GET", a, !1);
                b.send(null);
                var i = b.status;
                if (!(!i && location && "file:" === location.protocol || 200 <= i && 300 > i || 304 === i || 1223 === i || 0 === i)) throw Error("Unable to load " + a + " status: " + b.status);
                return nokia.mh5.win.eval(b.responseText)
            },
            getLoadPath: function(a, b) {
                var i = nokia.mh5.modulePaths[a];
                if (!i) for (var h = a.split("."), d = h.pop(), j = []; h.length;) {
                    i = h.join(".");
                    if (i = nokia.mh5.modulePaths[i]) {
                        i += j.join("/");
                        i += "/" !== i.charAt(i.length - 1) ? "/" + d : d;
                        break
                    }
                    j.splice(0, 0, h.pop())
                }
                return i + ("." + (b || "js"))
            }
        };
        nokia.mh5.modulePaths["nokia.mh5"] = nokia.mh5.modulePaths["nokia.mh5"] ||
        function() {
            for (var a = document.getElementsByTagName("script"), b = 0, i = /(^|\/|\\)core[\.\w]*?\.js$/i, h = "", d, j, f; d = a[b++];) if (d = d.src || "", j = d.match(i)) {
                if (-1 === d.indexOf("://")) {
                    h = nokia.mh5.win.location.href;
                    f = h.indexOf("#");
                    var k = h.indexOf("?");
                    f = f > k && -1 < k ? k : f;
                    h = -1 < f ? h.substring(0, f) : h;
                    h = h.substring(0, h.lastIndexOf("/") + 1)
                }
                f = h + d.substring(0, j.index);
                f = "/" === f.charAt(f.length - 1) ? f : f + "/"
            }
            return f
        }()
    }
}).call(this);
nokia.mh5.each = function(g, a, b) {
    if (!g) return null;
    var c = 0,
        e = g.length,
        i, b = b || g;
    if ("number" !== typeof e || "[object Object]" === Object.prototype.toString.call(g) && !(e - 1 in g)) for (i in g) {
        if (g.hasOwnProperty(i) && !1 === a.call(b, g[i], i, g)) break
    } else for (i = g[0]; c < e && !1 !== a.call(b, i, c, g); i = g[++c]);
    return g
};
nokia.mh5.extend = function(g, a) {
    for (var b = Object, c = b.defineProperty, e = b.getOwnPropertyNames, b = b.getOwnPropertyDescriptor, i = [].slice.call(arguments, 1), h = 0, d = i.length, j, f, k, m, n; h < d; ++h) for (a = i[h], m = a ? e(a) : [], j = 0, f = m.length; j < f; ++j) k = m[j], (n = b(a, k)) ? n.enumerable && ("function" !== typeof a || "prototype" !== k) && c(g, k, n) : g[k] = a[k];
    return g
};
nokia.mh5.extendDeep = function(g, a) {
    for (var b in a) if (a.hasOwnProperty(b)) if (a[b] && g[b] && "object" === typeof g[b] && !Array.isArray(g[b])) {
        var c = g[b];
        g[b] = {};
        nokia.mh5.extend(g[b], c);
        nokia.mh5.extendDeep(g[b], a[b])
    } else a[b] && "object" === typeof a[b] && !Array.isArray(a[b]) ? (g[b] = {}, nokia.mh5.extendDeep(g[b], a[b])) : g[b] = a[b];
    return g
};
nokia.mh5.type = function(g) {
    return null === g && "null" || void 0 === g && "undefined" || g.callee && "arguments" || "object" === typeof g && "number" === typeof g.length && !g.propertyIsEnumerable("length") && "array" || g instanceof Date && "date" || typeof g
};
nokia.mh5.resolve = function(g, a) {
    a = a || nokia.mh5.win;
    return !g ? a : g.split(".").reduce(function(a, c) {
        return a && a[c]
    }, a)
};
nokia.mh5.Class = function(g) {
    function a(a, f) {
        var k = !f,
            g;
        k ? f = typeof a === h ? a() : a : typeof f === h && (f = f(a[e]));
        g = d.call(f, c) ? f[c] : !k ?
        function() {
            a.apply(this, arguments)
        } : function() {};
        k ? (b.prototype = f, g[e] = new b) : (nokia.mh5.extend(g, a), b[e] = a[e], nokia.mh5.extend(g[e] = new b, f));
        g[e][c] = g;
        d.call(f, i) && nokia.mh5.extend(g, f[i]);
        return g
    }
    var b = function() {},
        c = "constructor",
        e = "prototype",
        i = "statics",
        h = "function",
        d = g.Object[e].hasOwnProperty;
    a[e] = g.Function[e];
    return a
}(this);
nokia.mh5.buildNS("nokia.mh5.i18n_languages");
nokia.mh5.i18n_languages.en = {
    "Error.applicationCredential": "appId or appCode is missing. Please apply for API credentials at http://nka.fi/EvZeT.",
    "Error.controlProperty": "Control property is not defined",
    "Error.prepareBindings": "%value% can't be bound because %snmspa% can't be resolved",
    "Error.propertyCannotBeOverwritten": "Property: '%name%' cannot be overwritten",
    "Error.customContentNotAllowed": "You can't use custom content with the name %name% because it's already in use",
    "Error.unableToRemove": "Removing '%name%' is not possible",
    "Error.routeTooLong": "Walking routes aren't available for routes longer than %maxWalkingDistance%.",
    "Error.tooLongWalkingDistance": "Your destination isn't within walking distance of your current location.",
    "Error.placeRemovedByOwner.header": "Sorry.",
    "Error.placeRemovedByOwner.message": "We don't have any info about this place anymore.",
    "Error.placeError.header": "Couldn't show you this place just now.",
    "Error.placeError.message": "Please try later.",
    "Warning.placeId": "`id` property in place object was changed to `placeId`",
    "Notification.addedToFavourites": "Added to your Favourites",
    "Notification.cantFindLocation": "Can't find your location. Please enter your starting point above.",
    "Notification.connectionError": "Please check your connection and try again",
    "Notification.destInWalkingDistance": "Destination is within walking distance",
    "Notification.error": "There was a problem",
    "Notification.favouritesNoSaved": "Couldn't save Favourite",
    "Notification.goOnline": "Connect to internet to search for places and addresses",
    "Notification.goOnlineForRouting": "Connect to internet to get a route",
    "Notification.goOnlinePlaceHolder": "Connect to internet to search",
    "Notification.lookingForCurrentPosition": "Finding your current location",
    "Notification.noGPSSignal": "Can't find your current location",
    "Notification.noModeAvailable": "%mode% mode is unavailable",
    "Notification.noPublicTransportService": "Public transport routing isn't available here",
    "Notification.noResult": "No results",
    "Notification.noResultFound": "No results found",
    "Notification.noRoutingService": "Sorry. Routes aren't available just now. Please try later.",
    "Notification.offRoute": "You seem to be off route by %value%",
    "Notification.positionNotAvailable": "Can't find your current location",
    "Notification.removedFromFavourites": "Removed from your Favourites",
    "Notification.routeCalculation": "Getting your route",
    "Notification.searchProblem": "There's a problem at the moment. Please try searching again later.",
    "Notification.serverError": "Sorry. There's a problem on our end. Please search again later.",
    "Notification.unableToLoadImage": "Couldn't load the image",
    "Notification.trafficInBeta": "Traffic view is still in beta.",
    eating: "Eating out",
    shopping: "Shopping",
    "going-out": "Going out",
    sights: "Sights",
    maps: "Views",
    layers: "Traffic",
    mapControl: "Map control",
    mapTermsOfUse: "Terms of Use",
    about: "About",
    alert: "Alert",
    beta: "beta",
    basic: "basic",
    businessOwner: "Business owner",
    call: "Call",
    cancel: "Cancel",
    confirm: "Confirm",
    "confirm.message": "Are you sure you want to continue?",
    "delete": "Delete",
    done: "Done",
    favourite: "Favourite",
    favouritesWithName: "%name%'s Favourites",
    favourites: "Favourites",
    feedback: "Feedback",
    from: "From",
    guides: "Guides",
    highest: "highest",
    hr: "hr",
    min: "min",
    km: "km",
    location: "location",
    minApprox: "min approx",
    more: "More",
    nearbyPlaces: "Nearby places",
    ok: "Ok",
    place: "place",
    refresh: "Refresh",
    retry: "Retry",
    reviews: "Reviews",
    route: "Route",
    save: "Save",
    search: "Search",
    searchPlaces: "Search for places",
    searching: "Searching",
    send: "Send",
    sending: "Sending",
    signin: "Sign in",
    signout: "Sign out",
    share: "Share",
    source: "Source",
    start: "Start",
    submit: "Submit",
    take: "Take",
    hi: "Hi %name%!",
    thankYou: "Thank you.",
    to: "To",
    towards: "towards",
    web: "Web",
    welcome: "Welcome to HERE",
    collections: "Collections",
    sms: "SMS",
    tel: "tel",
    email: "Email",
    shareVia: "share via",
    imagesProvidedBy: "Images from ",
    contentProvidedBy: "Content from ",
    openingTimes: "Opening hours",
    placeDescription: "Place description",
    followFor: "Follow for",
    saveMapArea: "Save a map area",
    reportPlace: "Report this place",
    "report.title": "Report a place to Nokia",
    "report.message": 'If you want to report a place, please go to Here.com on a non-mobile browser, search for the place, click "More Details" and then "Report this Place".',
    paymentMethods: "Payment methods",
    PT: "Public transport",
    addingA: "Adding a",
    removingA: "Removing a",
    currentLocation: "Current location",
    messageHere: "Message here",
    shareAPlace: "Share a place",
    "EP.idLikeTo": "Hey, here's something for you to check out on HERE.",
    "SMS.plsEnterNum": "Please enter the recipient's number<br />(including country code, e.g. +441234567890)",
    "SMS.plsCheckNum": "Please check the phone number",
    "SMS.alsoShort": "Add a short message (if you want to):",
    "SMS.enterCaptcha": "Enter here the characters you see below",
    "SMS.wrongCaptcha": "Please try another security code",
    "SMS.enterCode": "Enter the code here",
    "SMS.unableToSend": "Couldn't send your message. Please try again later.",
    "FV.startSaving": "Start saving them now!",
    "FV.startSavingHint": "The places you love are at your fingertips when you add them to your Favourites.",
    "FV.takeAllFavourites": "Sign in and take your Favourites with you.",
    "FV.simplyTap": "Just tap the blue star on the place page.",
    "FV.tapTheHighlighted": "Tap the yellow star, and the place is no longer in your list.",
    "FV.syncing": "Syncing",
    "FV.syncedFavourites": "Everything is synced",
    "FV.addedButUnsyncedFavourites": "Added but not yet synced",
    "FV.addedNotSignedIn": "Added to Favourites",
    "FV.addedSignedIn": "Added to Favourites and syncing",
    "FV.removedNotSignedIn": "Removed from Favourites",
    "FV.removedSignedIn": "Removed from Favourites and syncing",
    "FV.signInToSyncronize": "Sign in to sync",
    "FV.couldNotSync": "Couldn't sync",
    "RA.arriveAt": "Arrive at",
    "RA.departFrom": "Depart from",
    "RA.drive": "drive",
    "RA.walk": "walk",
    "RA.walkTo": "Walk to",
    "RA.disclaimer": "Transport information is provided by local transport agencies and is subject to change. More detailed and up-to-date information on schedules and services may be available on the agency website:",
    "RA.for1Stop": "For 1 stop",
    "RA.forXStops": "For %stops% stops",
    "UI.SettingsDialog.mapView": "Map view",
    "UI.SettingsDialog.satView": "Satellite view",
    "UI.SettingsDialog.PTView": "Public transport view",
    "UI.SettingsDialog.trafficView": "Live traffic view",
    "UI.SettingsDialog.Km": "Kilometres",
    "UI.SettingsDialog.Miles": "Miles",
    "UI.SettingsDialog.Accidents": "Accidents",
    "UI.SettingsDialog.Congestions": "Congestion",
    "UI.SettingsDialog.Constructions": "Construction",
    "UI.SettingsDialog.Others": "Other",
    "UI.SettingsDialog.CommunityMaps": "Community view",
    "UI.SettingsDialog.CommunityMapFootnote": "Community maps are living maps - created and updated by users all over the world",
    "UI.SettingsDialog.Retina": "High resolution map",
    "wrongZoom.title": "Your browser is currently scaling the contents of this page",
    "wrongZoom.message": 'For an optimal view go to "Settings" &gt; "Advanced" and set "Default zoom" to "Medium"',
    "maps.BP.bookmark": "To get the most from HERE, add our app as a bookmark to your home screen.",
    "maps.BP.install": "To install the app, tap the button %dir% and then 'Add to Home Screen'.",
    "maps.CVD.details": "Level of detail you can expect:",
    "maps.CVD.viewDetails": "Level of detail in current view:",
    "maps.CVD.tooLarge": "This area is too large. Move and zoom to centre on the neighbourhood you want to save.",
    "maps.CVD.goOnline": "You need a data connection to save the map.",
    "maps.CVD.rangeOfDetails": "Here's the range of detail you can see in saved map areas. Keep in mind, the more detail you want, the smaller the area of your map.",
    "maps.CVD.world": "Basic details",
    "maps.CVD.country": "Some details",
    "maps.CVD.city": "Average details",
    "maps.CVD.district": "Lots of details",
    "maps.CVD.street": "Maximum details",
    "maps.CVD.worldDesc": "See continents, countries, cities, motorways, road numbers and forests",
    "maps.CVD.countryDesc": "See countries, cities, districts, motorways, main streets, road numbers, airports, forests and lakes",
    "maps.CVD.cityDesc": "See cities, districts, detailed street grids, railways &amp; stations, major public transport, parks and lakes",
    "maps.CVD.districtDesc": "See districts, more detailed street grids, railways, all public transport, buildings, parks and paths",
    "maps.CVD.streetDesc": "See all streets and names, railways, all public transport, all buildings, parks and paths",
    "maps.SPD.startDownload": "Start your download",
    "maps.SPD.savingArea": "Saving your map area",
    "maps.SPD.instructionStart": "Map downloads can be large, so remember to use Wi-Fi.<br><br>Don't close this app while saving your map, and make sure your screensaver doesn't switch on.",
    "maps.SPD.instructionLoad": "Map downloads can be large, so remember to use Wi-Fi.<br><br>Don't close this app while saving your map, and make sure your screensaver doesn't switch on.",
    "maps.SPD.instructionFinished": "Your map's been saved.<br>You can find it now in your springboard.<br><br><span style='font-weight: bold'>Keep in mind that saving a new map area always replaces the last one you saved.</span>",
    "maps.SPD.keepInMind": "Keep in mind that saving a new map area always replaces the last one you saved.",
    "maps.SPD.minZoom": "Your min zoom level",
    "maps.SPD.maxZoom": "Your max zoom level",
    "maps.SPD.waiting": "Waiting for download to start",
    "maps.SPD.smtUnexpected": "There was a problem during the download.",
    "maps.SB.saveMap": "Save a map area",
    "maps.SB.viewMap": "View your saved map",
    "maps.NPS.recommend": "How likely are you to recommend HERE Maps to a friend or colleague?",
    "maps.NPS.notLikely": "Not at all likely",
    "maps.NPS.extremelyLikely": "Extremely likely",
    "maps.NPS.why": "Please tell us why you gave this score",
    "maps.NPS.enterMessage": "Enter message here...",
    "maps.NPS.email": "Enter email address",
    "maps.NPS.NPP": 'Your information will be treated according to the <a href="http://nokia.mobi/privacy/policy" target="_blank">Nokia Privacy Policy</a>.',
    "maps.NPS.noSend": "Unable to send. Please try again.",
    "maps.NPS.contact": "Nokia can contact me for details",
    "maps.Nav.headDirectionforDistance": "Head %direction% for %distance%",
    "maps.Nav.reachedDestination": "You have reached your destination",
    "maps.Nav.speeding": "If you're still walking, you walk very fast! Navigation will start again when you've slowed down.",
    "maps.Nav.tryAgain": "The download didn't work",
    "maps.Nav.disclaimerTitle": "Using audio directions",
    "maps.Nav.disclaimerPoint1": "Be aware of your surroundings and keep an eye open for cars and other urban challenges.",
    "maps.Nav.disclaimerPoint2": "Make sure your phone's display doesn't go dark, or you might not be able to hear the navigation instructions clearly. Also, be sure to download a voice file first (1.9MB).",
    "maps.Nav.disclaimerPoint3": "Using Nokia services may involve large amounts of data moving through your service provider's network. Not all services may be available or 100% accurate all the time. Using this service could also involve sending information about your location.",
    "maps.Nav.disclaimerPoint4": 'By tapping \'Load audio\', you confirm that you have read and agree to the <a href="http://nokia.mobi/privacy/services/terms/nokia-service" onclick="event.stopPropagation();" target="_blank">Nokia Service Terms</a> and <a href="http://nokia.mobi/privacy/policy" onclick="event.stopPropagation();" target="_blank">Privacy Policy</a>. For more information <a href="http://nokia.mobi/privacy/services/map-apps" onclick="event.stopPropagation();" target="_blank">click here</a>.',
    "maps.Nav.success": "Download finished",
    "maps.Nav.load": "Load audio",
    "maps.Nav.start": "Start journey",
    "maps.Traffic.incidentDescription": "on %origin% towards %direction%",
    "maps.Traffic.incidentDescriptionNoDirection": "on %origin%",
    "maps.Traffic.incidentAt": "at %start%",
    "maps.Traffic.incidentUnidir": "from %start% to %end%",
    "maps.Traffic.incidentBidir": "between %start% and %end%",
    "maps.Traffic.incidentStartTime": "Start time",
    "maps.Traffic.incidentEndTime": "Approx end time",
    "maps.Traffic.incidentDateFormat": "%month%/%day%/%year% %hour%:%minute%",
    "maps.Traffic.criticalityTitle": "Severity",
    "maps.Traffic.critical": "Critical",
    "maps.Traffic.major": "Major",
    "maps.Traffic.minor": "Minor",
    "collections.notification.message": "An error has occurred processing your request. Please try again later.",
    "collections.notification.message.syncing": "Syncing ...",
    "collections.notification.message.syncComplete": "Everything is synced.",
    "collections.common.itemsCount": " items",
    "collections.common.button.next": "Next",
    "collections.common.button.save": "Save",
    "collections.common.button.cancel": "Cancel",
    "collections.common.button.create": "Create new collection",
    "collections.common.button.delete": "Delete collection",
    "collections.common.confirmation.delete": "Are you sure you want to delete this collection?",
    "collections.common.confirmation.favourite.delete": "Are you sure you want to delete this item?",
    "collections.common.confirmation.favourite.delete.collections": "This item is saved in more than one collection.\n\nDeleting it here will delete it everywhere.",
    "collections.util.Date.at": " at ",
    "collections.CollectionsBar.myCollections": "My collections",
    "collections.CollectionListPage.organize": "To organize",
    "collections.CollectionListPage.button.label.create": "Create new",
    "collections.CollectionListPage.button.label.collection": "collection",
    "collections.CollectionListPage.collectionCount": " collections",
    "collections.CollectionListPage.ftu.signIn": "Sign in to create collections",
    "collections.CollectionListPage.ftu.intro.signedOut": "<h1 class='mh5_title'>Collect places to remember</h1>Find them again anytime, anywhere, on your phone, tablet or computer.",
    "collections.CollectionListPage.ftu.intro.signedIn.hasUngrouped": "Manage your saved places and put them in collections - so you can find them easier and faster.",
    "collections.CollectionListPage.ftu.intro.signedIn.hasNoUngrouped": "<h1 class='mh5_title'>Welcome to collections</h1>Start collecting all the places you want or need to save for later - and leave the remembering to us!",
    "collections.CollectionListPage.ftu.button.create": "Create your first collection",
    "collections.CollectionListPage.sortedBy": "Sorted by",
    "collections.CollectionListPage.sort.lastUpdated": "last updated",
    "collections.CollectionListPage.sort.name": "name",
    "collections.CollectionListPage.sort.numItems": "number of items",
    "collections.CollectionListPage.unsortedItems": "Unsorted items",
    "collections.CollectionListPage.title": "Collections",
    "collections.CreateCollectionAddItems.pageTitle": "Select items",
    "collections.CreateCollectionAddItems.intro": "Pick your stuff to add to collection",
    "collections.CreateCollectionAddItems.filterBy": "Filter by:",
    "collections.CreateCollectionAddItems.fromLabel": "FROM:",
    "collections.CreateCollectionAddItems.toLabel": "TO:",
    "collections.CreateCollectionAddItems.filter.all": "All",
    "collections.CreateCollectionAddItems.filter.addresses": "Address",
    "collections.CreateCollectionAddItems.filter.restaurants": "Restaurants",
    "collections.CreateCollectionAddItems.filter.routes": "Routes",
    "collections.CreateCollectionAddItems.filter.shoppings": "Shoppings",
    "collections.CreateCollectionAddItems.filter.sights": "Sights",
    "collections.CreateCollection.pageTitle": "Create collection",
    "collections.CreateCollection.image.instruction": "Select a picture to give your collection a special feel",
    "collections.CreateCollection.collectionName.placeholder": "New collection",
    "collections.CreateCollection.personalize.placeholder": "Add a description",
    "collections.CreateCollection.personalize.characterLimit": "max 100 characters",
    "collections.CreateCollection.mandatoryFieldNote": "* Naming your collection is mandatory. And it helps you remember what's inside.",
    "collections.ToOrganize.pageTitle": "To organize",
    "collections.CollectionEdit.pageTitle": "Collection",
    "collections.CollectionEdit.addItemLabel": " Add item",
    "collections.CollectionEdit.addItems": "Add items",
    "collections.CollectionEdit.allCollectedItems": "All collected items",
    "collections.CollectionEdit.noCollectedItems": "No items collected",
    "collections.CollectionEdit.noCollectedItems.intro": "Create your first collection now. You can always add places to it later on.",
    "collections.CollectionEdit.editFavoritesLabel": "Edit",
    "collections.CollectionEdit.itemsTitle": "Items in this collection",
    "collections.CollectionEdit.selectItems": "Select items to add to this collection",
    "collections.CollectionEdit.editDetailsLabel": "Collection details",
    "collections.CollectionEditDetails.pageTitle": "Collection details",
    "collections.details.title": "Collection",
    "collections.details.manage": "Manage",
    "collections.details.create": "Create",
    "collections.favourite.edit.collect": "Collect",
    "collections.favourite.edit.manage": "Manage",
    "collections.favourite.edit.delete": "Delete item",
    "collections.favourite.edit.collectionsListTitle": "Organise in collections",
    "maps.Traffic.Accident": "Accidents",
    "maps.Traffic.Construction": "Constructions",
    "maps.Traffic.Congestion": "Congestion",
    "maps.Traffic.Disabledvehicle": "Disabled Vehicle",
    "maps.Traffic.Roadhazard": "Road Hazard",
    "maps.Traffic.Masstransit": "Mass Transit",
    "maps.Traffic.Othernews": "Other News",
    "maps.Traffic.Weather": "Weather",
    "maps.Traffic.Misc": "Misc",
    "maps.Traffic.Plannedevent": "Planned Event",
    "day.sunday": "Sunday",
    "day.monday": "Monday",
    "day.tuesday": "Tuesday",
    "day.wednesday": "Wednesday",
    "day.thursday": "Thursday",
    "day.friday": "Friday",
    "day.saturday": "Saturday",
    today: "Today",
    now: "Now",
    posted: "Posted %by_part% on %date%",
    by_part: "by %name%",
    "maps.CVD.title": "Offline maps types",
    "UI.SettingsDialog.TrafficIncidents": "Traffic Incidents",
    "UI.SettingsDialog.Language": "Language",
    "SMS.sentSuccessfully": "The SMS was sent successfully!",
    "maps.BP.below": "below",
    "maps.BP.above": "above",
    "RA.Station": "Station",
    North: "N",
    West: "W",
    South: "S",
    East: "E",
    "Ad.adBy": "ad by"
};
nokia.mh5.buildNS("nokia.mh5.i18n_languages");
nokia.mh5.i18n_languages.es = {
    "Error.applicationCredential": "Falta appId o appCode. Por favor, solicite credenciales de API en http://nka.fi/EvZeT.",
    "Error.controlProperty": "Propiedad Control no est\u00e1 definida",
    "Error.prepareBindings": "%value% no se puede enlazar porque %snmspa% no se puede resolver",
    "Error.propertyCannotBeOverwritten": "Propiedad: '%name%' no puede ser sobreescrita",
    "Error.customContentNotAllowed": "Usted no puede usar el contenido personalizado con el nombre %name% debido a que ya est\u00e1 en uso",
    "Error.unableToRemove": "Eliminar '%name%' no es posible",
    "Error.routeTooLong": "Las rutas peatonales no est\u00e1n disponibles para rutas m\u00e1s largas de %maxWalkingDistance%.",
    "Error.tooLongWalkingDistance": "Su destino no se encuentra a corta distancia a pie desde su ubicaci\u00f3n actual.",
    "Error.placeRemovedByOwner.header": "Lo sentimos.",
    "Error.placeRemovedByOwner.message": "Ya no tenemos informaci\u00f3n acerca de este lugar.",
    "Error.placeError.header": "No se puede mostrar el lugar en este momento.",
    "Error.placeError.message": "Por favor, intente m\u00e1s tarde.",
    "Warning.placeId": " Propiedad `id` en objeto lugar fue cambiada a `placeId`",
    "Notification.addedToFavourites": "A\u00f1adido a sus favoritos",
    "Notification.cantFindLocation": "No se puede encontrar su ubicaci\u00f3n. Por favor, introduzca arriba su punto de partida.",
    "Notification.connectionError": "Por favor, pruebe su conexi\u00f3n y trate de nuevo",
    "Notification.destInWalkingDistance": "El destino se encuentra a distancia apropiada a pie",
    "Notification.error": "Ocurri\u00f3 un problema",
    "Notification.favouritesNoSaved": "No se pudo guardar Favorito",
    "Notification.goOnline": "Conectarse a Internet para buscar lugares y direcciones",
    "Notification.goOnlineForRouting": "Conectarse a Internet para obtener ruta",
    "Notification.goOnlinePlaceHolder": "Conectarse a Internet para buscar",
    "Notification.lookingForCurrentPosition": "Buscando su ubicaci\u00f3n actual",
    "Notification.noGPSSignal": "No se encontr\u00f3 su ubicaci\u00f3n actual",
    "Notification.noModeAvailable": "Modo %mode% no est\u00e1 disponible",
    "Notification.noPublicTransportService": "Las rutas de transporte p\u00fablico no est\u00e1n dispobibles aqu\u00ed",
    "Notification.noResult": "No hay resultados",
    "Notification.noResultFound": "No se encontraron resultados",
    "Notification.noRoutingService": "Lo sentimos. En este momento las rutas no est\u00e1n dispobibles. Por favor, intente m\u00e1s tarde.",
    "Notification.offRoute": "Usted parece estar fuera de ruta por %value%",
    "Notification.positionNotAvailable": "No se encontr\u00f3 su ubicaci\u00f3n actual",
    "Notification.removedFromFavourites": "Eliminado de sus favoritos",
    "Notification.routeCalculation": "Calculando su ruta",
    "Notification.searchProblem": "Hay un problema en este momento. Por favor, intente buscar nuevamente m\u00e1s tarde.",
    "Notification.serverError": "Lo sentimos. Hay un problema por nuestra parte. Por favor, buscar de nuevo m\u00e1s tarde.",
    "Notification.unableToLoadImage": "No se pudo descargar la imagen",
    "Notification.trafficInBeta": "La vista del Trafico est\u00e1 todav\u00eda en versi\u00f3n beta.",
    eating: "Salir a comer",
    shopping: "Compras",
    "going-out": "Salir",
    sights: "Sitios de inter\u00e9s",
    maps: "Vista de",
    layers: "Tr\u00e1fico",
    mapControl: "Control mapa",
    mapTermsOfUse: "Condiciones de uso",
    about: "Acerca de",
    alert: "Alerta",
    beta: "beta",
    basic: "b\u00e1sico",
    businessOwner: "Propietario de un negocio",
    call: "Llamar",
    cancel: "Cancelar",
    confirm: "Confirmar",
    "confirm.message": "\u00bfEst\u00e1 seguro/a de que desea continuar?",
    "delete": "Eliminar",
    done: "Hecho",
    favourite: "Favorito",
    favouritesWithName: "Favoritos de %name%",
    favourites: "Favoritos",
    feedback: "Feedback",
    from: "Desde",
    guides: "Gu\u00edas",
    highest: "M\u00e1s alto",
    hr: "hr",
    min: "min",
    km: "km",
    location: "ubicaci\u00f3n",
    minApprox: "aprox. min",
    more: "M\u00e1s",
    nearbyPlaces: "Lugares cercanos",
    ok: "Ok",
    place: "Lugar",
    refresh: "Actualizar",
    retry: "Intentar de nuevo",
    reviews: "Rese\u00f1as",
    route: "Ruta",
    save: "Guardar",
    search: "Buscar",
    searchPlaces: "Buscar lugares",
    searching: "Buscando",
    send: "Enviar",
    sending: "Enviando",
    signin: "Reg\u00edstrese",
    signout: "Salir",
    share: "Compartir",
    source: "Fuente",
    start: "Inicio",
    submit: "Entregar",
    take: "Tomar",
    hi: "\u00a1Hola %name%!",
    thankYou: "Gracias.",
    to: "Para",
    towards: "hacia",
    web: "Web",
    welcome: "Bienvenido HERE",
    collections: "Colecciones",
    sms: "SMS",
    tel: "tel",
    email: "Email",
    shareVia: "compartir v\u00eda",
    imagesProvidedBy: "Im\u00e1genes de ",
    contentProvidedBy: "Contenido de ",
    openingTimes: "Horario de atenci\u00f3n",
    placeDescription: "Descripci\u00f3n del lugar",
    followFor: "Siga por",
    saveMapArea: "Guardar \u00e1rea del mapa",
    reportPlace: "Reportar este lugar",
    "report.title": "Reportar un lugar a Nokia",
    "report.message": 'If you want to report a place, please go to Here.com on a non-mobile browser, search for the place, click "More Details" and then "Report this Place".',
    "report.message": 'Si desea reportar un lugar, por favor vaya a Here.com en un navegador que no sea para tel\u00e9fono m\u00f3vil, busque el lugar deseado, haga click en "M\u00e1s detalles" y despu\u00e9s "Reportar este lugar".',
    paymentMethods: "M\u00e9todos de pago",
    PT: "Transporte p\u00fablico",
    addingA: "Agregando a",
    removingA: "Eliminando a",
    currentLocation: "Ubicaci\u00f3n actual",
    messageHere: "Mensaje aqu\u00ed",
    shareAPlace: "Comparta un lugar",
    "EP.idLikeTo": " \u00a1Hey!, hay algo para ti por ver en HERE.",
    "SMS.plsEnterNum": "Por favor, ingrese el n\u00famero del destinatario <br />(incluya c\u00f3digo de pa\u00eds, por ejemplo:+441234567890)",
    "SMS.plsCheckNum": "Por favor, verifique el n\u00famero de tel\u00e9fono",
    "SMS.alsoShort": "Incluya un mensaje corto (si as\u00ed lo desea):",
    "SMS.enterCaptcha": "Ingrese aqu\u00ed los caracteres que se muestran debajo",
    "SMS.wrongCaptcha": "Por favor, intente otro c\u00f3digo de seguridad",
    "SMS.enterCode": "Ingrese el c\u00f3digo aqu\u00ed",
    "SMS.unableToSend": "No se pudo enviar su mensaje. Por favor, intente de nuevo m\u00e1s tarde.",
    "FV.startSaving": "\u00a1Empiece a guardarlos ahora!",
    "FV.startSavingHint": "Los lugares que ama est\u00e1n a sus manos cuando los agrega a sus Favoritos.",
    "FV.takeAllFavourites": "Reg\u00edstrese y lleve sus Favoritos con usted  Sign in and take your Favourites with you.",
    "FV.simplyTap": "S\u00f3lo d\u00e9 click a la estrella azul que est\u00e1 en la p\u00e1gina del lugar.",
    "FV.tapTheHighlighted": "D\u00e9 click en la estrella amarilla, y el sitio ya no estar\u00e1 m\u00e1s en su lista.",
    "FV.syncing": "Sincronizando",
    "FV.syncedFavourites": "Todo ha sido sincronizado",
    "FV.addedButUnsyncedFavourites": "Agregado, pero todav\u00eda no ha sido sincronizado",
    "FV.addedNotSignedIn": "Agregado a Favoritos",
    "FV.addedSignedIn": "Agregado a Favoritos y sincronizando",
    "FV.removedNotSignedIn": "Eliminado de favoritos",
    "FV.removedSignedIn": "Eliminado de Favoritos y sincronizando",
    "FV.signInToSyncronize": "Reg\u00edstrese para sincronizar",
    "FV.couldNotSync": "No se pudo sincronizar",
    "RA.arriveAt": "Llegada a",
    "RA.departFrom": "Salida de",
    "RA.drive": "Conducir",
    "RA.walk": "Caminar",
    "RA.walkTo": "Caminar a",
    "RA.disclaimer": "La informaci\u00f3n del transporte es prove\u00edda por la agencia local de transporte y est\u00e1 sujeta a cambios. Informaci\u00f3n m\u00e1s detallada y actualizada sobre horarios y servicios, puede ser encontrada en la p\u00e1gina de internet de la agencia:",
    "RA.for1Stop": "Por 1 parado",
    "RA.forXStops": "Por %stops% paradas",
    "UI.SettingsDialog.mapView": "Vista del Mapa",
    "UI.SettingsDialog.satView": "Vista de Sat\u00e9lite",
    "UI.SettingsDialog.PTView": "Vista de Transportes P\u00fablicos",
    "UI.SettingsDialog.trafficView": "Vista de Tr\u00e1fico actual",
    "UI.SettingsDialog.Km": "Kil\u00f3metros",
    "UI.SettingsDialog.Miles": "Millas",
    "UI.SettingsDialog.Accidents": "Accidentes",
    "UI.SettingsDialog.Congestions": "Congesti\u00f3n",
    "UI.SettingsDialog.Constructions": "Construcci\u00f3n",
    "UI.SettingsDialog.Others": "Otros",
    "UI.SettingsDialog.CommunityMaps": "Vista de Comunidad",
    "UI.SettingsDialog.CommunityMapFootnote": "Los mapas de la Comunidad son mapas vivientes \u2013 creados y actualizados por usuarios de todo el mundo",
    "UI.SettingsDialog.Retina": "High resolution map",
    "wrongZoom.title": "Your browser is currently scaling the contents of this page",
    "wrongZoom.message": 'For an optimal view go to "Settings" &gt; "Advanced" and set "Default zoom" to "Medium"',
    "maps.BP.bookmark": "Para obtener lo mejor de HERE, agregue nuestra aplicaci\u00f3n como un marcador o bookmark en su p\u00e1gina de inicio.",
    "maps.BP.install": "Para instalar la aplicaci\u00f3n, d\u00e9 click en el bot\u00f3n %dir% y despu\u00e9s 'Agregar a p\u00e1gina de inicio'.",
    "maps.CVD.details": "Nivel de detalle que puede esperar:",
    "maps.CVD.viewDetails": "Nivel de detalle en la vista actual:",
    "maps.CVD.tooLarge": "El \u00e1rea es muy grande. Mueva y acerque m\u00e1s al centro de la zona que desea guardar.",
    "maps.CVD.goOnline": "Necesita conexi\u00f3n de datos para guardar el mapa.",
    "maps.CVD.rangeOfDetails": "\u00c9ste es el rango de detalles que puede ver en \u00e1reas guardadas del mapa. Considere, que entre m\u00e1s detalles desee, el \u00e1rea de su mapa ser\u00e1 menor.",
    "maps.CVD.world": "Detalles b\u00e1sicos",
    "maps.CVD.country": "Algunos detalles",
    "maps.CVD.city": "Detalles promedio",
    "maps.CVD.district": "Muchos detalles",
    "maps.CVD.street": "M\u00e1ximo en detalles",
    "maps.CVD.worldDesc": "Ver continentes, pa\u00edses, ciudades, autopistas, n\u00fameros de carreteras y bosques",
    "maps.CVD.countryDesc": "Ver pa\u00edses, ciudades, distritos, autopistas, calles principales, n\u00fameros de carretera, aeropuertos, bosques y lagos",
    "maps.CVD.cityDesc": "Ver ciudades, distritos, red de calles detallada, v\u00edas de tren &amp; estaciones, principales transportes p\u00fablicos, parques y lagos",
    "maps.CVD.districtDesc": "Ver distritos, red de calles m\u00e1s detallada, v\u00edas de tren, todo el transporte p\u00fablico, edificios, parques y caminos",
    "maps.CVD.streetDesc": "Ver todas las calles y nombres, v\u00edas de tren, todo el transporte p\u00fablico, todos los edificios, parques y caminos",
    "maps.SPD.startDownload": "Empezar la descarga",
    "maps.SPD.savingArea": "Guardando su \u00e1rea del mapa",
    "maps.SPD.instructionStart": "La descarga de mapas puede ser grande; recuerde usar Wi-Fi.<br><br>No cierre esta aplicaci\u00f3n mientras se guarda su mapa, y aseg\u00farese que el protector de pantalla no se active.",
    "maps.SPD.instructionLoad": "La descarga de mapas puede ser grande; recuerde usar Wi-Fi.<br><br>No cierre esta aplicaci\u00f3n mientras se guarda su mapa, y aseg\u00farese que el protector de pantalla no se active.",
    "maps.SPD.instructionFinished": "Su mapa ha sido guardado.<br> Puede encontrarlo ahora en su plataforma de inicio.<br><br><span style='font-weight: bold'>Considere que al guardar \u00e1reas nuevas de mapa remplaza las antiguas que haya guardado.</span>",
    "maps.SPD.keepInMind": "Considere que al guardar \u00e1reas nuevas del mapa siempre remplaza la \u00faltima que haya sido guardada.",
    "maps.SPD.minZoom": "Su nivel m\u00ednimo de zoom",
    "maps.SPD.maxZoom": "Su nivel m\u00e1ximo de zoom",
    "maps.SPD.waiting": "Esperando que la descarga empiece",
    "maps.SPD.smtUnexpected": "Hubo un problema durante la descarga.",
    "maps.SB.saveMap": "Guarde un \u00e1rea del mapa",
    "maps.SB.viewMap": "Ver el mapa que ha guardado",
    "maps.NPS.recommend": "\u00bfQu\u00e9 tan probable es que recomiende HERE Maps a sus amigos o colegas de trabajo?",
    "maps.NPS.notLikely": "Para nada probable",
    "maps.NPS.extremelyLikely": "Altamente probable",
    "maps.NPS.why": "Por favor, d\u00edganos por qu\u00e9 nos dio este puntaje",
    "maps.NPS.enterMessage": "Ingrese mensaje aqu\u00ed...",
    "maps.NPS.email": "Ingresar cuenta de correo electr\u00f3nico",
    "maps.NPS.NPP": 'Su informaci\u00f3n ser\u00e1 tratada de acuerdo a <a href="http://nokia.mobi/privacy/policy" target="_blank">Nokia Privacy Policy</a>.',
    "maps.NPS.noSend": "No se ha podido enviar. Por favor intente de nuevo.",
    "maps.NPS.contact": "Nokia puede contactarme para m\u00e1s detalles",
    "maps.Nav.headDirectionforDistance": "Siga %direction% por %distance%",
    "maps.Nav.reachedDestination": "Usted ha llegado a su destino",
    "maps.Nav.speeding": "Si usted todav\u00eda sigue caminando, \u00a1Usted camina muy deprisa! La navegaci\u00f3n empezar\u00e1 de nuevo cuando usted haya disminuido la velocidad.",
    "maps.Nav.tryAgain": "La descarga no ha funcionado",
    "maps.Nav.disclaimerTitle": "Usando direcci\u00f3n audio",
    "maps.Nav.disclaimerPoint1": "Est\u00e9 al tanto de su entorno y mantenga un ojo en coches ydistracciones urbanas.",
    "maps.Nav.disclaimerPoint2": "Aseg\u00farese que la pantalla de su m\u00f3vil no se apague o no podr\u00e1 escuchar las instrucciones. Aseg\u00farese de descargarlos archivos audio (1.9MB).",
    "maps.Nav.disclaimerPoint3": "Usar los serviciosNokia puede involucrar grandes descargas de datos a trav\u00e9s de la red de su proveedor. No todos los servicios podr\u00edan estar disponibles, o ser 100% precisos. Usar este servicio puede involucrar env\u00edo de informaci\u00f3n sobre su ubicaci\u00f3n.",
    "maps.Nav.disclaimerPoint4": 'Al hacer click en \'Cargar audio\',confirma que ya ha le\u00eddo y aceptado los<a href="http://nokia.mobi/privacy/services/terms/nokia-service" onclick="event.stopPropagation();" target="_blank">T\u00e9rminos de servicio</a> y <a href="http://nokia.mobi/privacy/policy" onclick="event.stopPropagation();" target="_blank">Datos de Privacidad</a>. Para m\u00e1s informaci\u00f3n <a href="http://nokia.mobi/privacy/services/map-apps" onclick="event.stopPropagation();" target="_blank">click aqu\u00ed</a>.',
    "maps.Nav.success": "Descarga completa",
    "maps.Nav.load": "Cargar audio",
    "maps.Nav.start": "Empezar ruta",
    "maps.Traffic.incidentDescription": "en %origin% hacia %direction%",
    "maps.Traffic.incidentDescriptionNoDirection": "en %origin%",
    "maps.Traffic.incidentAt": "en %start%",
    "maps.Traffic.incidentUnidir": "desde %start% a %end%",
    "maps.Traffic.incidentBidir": "entre %start% a %end%",
    "maps.Traffic.incidentStartTime": "Hora de inicio",
    "maps.Traffic.incidentEndTime": "Tiempo final aproximado",
    "maps.Traffic.incidentDateFormat": "%month%/%day%/%year% %hour%:%minute%",
    "maps.Traffic.criticalityTitle": "Gravedad",
    "maps.Traffic.critical": "Cr\u00edtico",
    "maps.Traffic.major": "Mayor",
    "maps.Traffic.minor": "Menor",
    "collections.notification.message": "Ha ocurrido un error mientras se procesaba su solicitud. Por favor vuelva a intentar m\u00e1s tarde.",
    "collections.notification.message.syncing": "Sincronizando...",
    "collections.notification.message.syncComplete": "Todo ha sido sincronizado.",
    "collections.common.itemsCount": " objetos",
    "collections.common.button.next": "Siguiente",
    "collections.common.button.save": "Guardar",
    "collections.common.button.cancel": "Cancelar",
    "collections.common.button.create": "Crear colecci\u00f3n nueva",
    "collections.common.button.delete": "Eliminar colecci\u00f3n",
    "collections.common.confirmation.delete": "\u00bfEst\u00e1 seguro de que desea eliminar esta colecci\u00f3n?",
    "collections.common.confirmation.favourite.delete": "\u00bfEst\u00e1 seguro de que desea eliminar este objeto?",
    "collections.common.confirmation.favourite.delete.collections": "Este objeto est\u00e1 guardado en m\u00e1s de una colecci\u00f3n.\n\nElimin\u00e1ndolo aqu\u00ed causar\u00e1 su eliminaci\u00f3n en todos lados.",
    "collections.util.Date.at": " en ",
    "collections.CollectionsBar.myCollections": "Mis colecciones",
    "collections.CollectionListPage.organize": "Organizar",
    "collections.CollectionListPage.button.label.create": "Crear nuevo",
    "collections.CollectionListPage.button.label.collection": "colecci\u00f3n",
    "collections.CollectionListPage.collectionCount": " colecciones",
    "collections.CollectionListPage.ftu.signIn": "Ingrese para crear colecciones",
    "collections.CollectionListPage.ftu.intro.signedOut": "<h1 class='mh5_title'>Coleccione lugares para recordar y lugares donde ir</h1>Encu\u00e9ntrelos de nuevo en cualquier momento o lugar, en su tel\u00e9fono, tablet o computadora.",
    "collections.CollectionListPage.ftu.intro.signedIn.hasUngrouped": "Organice sus lugares guardados y p\u00f3ngalos en colecciones - para encontrarlos m\u00e1s f\u00e1cil y r\u00e1pidamente.",
    "collections.CollectionListPage.ftu.intro.signedIn.hasNoUngrouped": "<h1 class='mh5_title'>Bienvenido a colecciones</h1>Empiece a coleccionar todos los lugares que desee o que necesite guardar para despu\u00e9s - \u00a1y deje que nosotros los recordemos!",
    "collections.CollectionListPage.ftu.button.create": "Cree su primera colecci\u00f3n",
    "collections.CollectionListPage.sortedBy": "Organizar por",
    "collections.CollectionListPage.sort.lastUpdated": "\u00faltima actualizaci\u00f3n",
    "collections.CollectionListPage.sort.name": "nombre",
    "collections.CollectionListPage.sort.numItems": "n\u00famero de objetos",
    "collections.CollectionListPage.unsortedItems": "Objetos no organizados",
    "collections.CollectionListPage.title": "Colecciones",
    "collections.CreateCollectionAddItems.pageTitle": "Seleccionar objetos",
    "collections.CreateCollectionAddItems.intro": "Elija lo que quiera agregar a su colecci\u00f3n",
    "collections.CreateCollectionAddItems.filterBy": "Filtrar por:",
    "collections.CreateCollectionAddItems.fromLabel": "DE:",
    "collections.CreateCollectionAddItems.toLabel": "PARA:",
    "collections.CreateCollectionAddItems.filter.all": "Todo",
    "collections.CreateCollectionAddItems.filter.addresses": "Direcci\u00f3n",
    "collections.CreateCollectionAddItems.filter.restaurants": "Restaurantes",
    "collections.CreateCollectionAddItems.filter.routes": "Rutas",
    "collections.CreateCollectionAddItems.filter.shoppings": "Compras",
    "collections.CreateCollectionAddItems.filter.sights": "Atracciones",
    "collections.CreateCollection.pageTitle": "Crear colecci\u00f3n",
    "collections.CreateCollection.image.instruction": "Seleccione una imagen para dar un toque personal a su colecci\u00f3n",
    "collections.CreateCollection.collectionName.placeholder": "Nueva colecci\u00f3n",
    "collections.CreateCollection.personalize.placeholder": "Ingrese una descripci\u00f3n",
    "collections.CreateCollection.personalize.characterLimit": "m\u00e1x. 100 caracteres",
    "collections.CreateCollection.mandatoryFieldNote": "* Es necesario dar un nombre a su colecci\u00f3n. Esto le recordar\u00e1 lo que contiene.",
    "collections.ToOrganize.pageTitle": "Organizar",
    "collections.CollectionEdit.pageTitle": "Colecci\u00f3n",
    "collections.CollectionEdit.addItemLabel": " Agregar objeto",
    "collections.CollectionEdit.addItems": "Agregar objetos",
    "collections.CollectionEdit.allCollectedItems": "Todos los objetos coleccionados",
    "collections.CollectionEdit.noCollectedItems": "Ning\u00fan objeto coleccionado",
    "collections.CollectionEdit.noCollectedItems.intro": "Cree su primera colecci\u00f3n ahora. Puede agregar otros objetos m\u00e1s adelante.",
    "collections.CollectionEdit.editFavoritesLabel": "Editar",
    "collections.CollectionEdit.itemsTitle": "Objetos en esta colecci\u00f3n",
    "collections.CollectionEdit.selectItems": "Seleccione objetos para agregar a esta colecci\u00f3n",
    "collections.CollectionEdit.editDetailsLabel": "Detalles de la colecci\u00f3n",
    "collections.CollectionEditDetails.pageTitle": "Detalles de la colecci\u00f3n",
    "collections.details.title": "Colecci\u00f3n",
    "collections.details.manage": "Administrar",
    "collections.details.create": "Crear",
    "collections.favourite.edit.collect": "Coleccionar",
    "collections.favourite.edit.manage": "Administrar",
    "collections.favourite.edit.delete": "Eliminar objeto",
    "collections.favourite.edit.collectionsListTitle": "Organizar en colecciones",
    "maps.Traffic.Accident": "Accidentes",
    "maps.Traffic.Construction": "Construcciones",
    "maps.Traffic.Congestion": "Congesti\u00f3n",
    "maps.Traffic.Disabledvehicle": "Veh\u00edculo Inhabilitado",
    "maps.Traffic.Roadhazard": "Peligro en la carretera",
    "maps.Traffic.Masstransit": "Tr\u00e1nsito de masa",
    "maps.Traffic.Othernews": "Otras noticias",
    "maps.Traffic.Weather": "Clima",
    "maps.Traffic.Misc": "Misc.",
    "maps.Traffic.Plannedevent": "Evento planificado",
    "day.sunday": "Domingo",
    "day.monday": "Lunes",
    "day.tuesday": "Martes",
    "day.wednesday": "Mi\u00e9rcoles",
    "day.thursday": "Jueves",
    "day.friday": "Viernes",
    "day.saturday": "S\u00e1bado",
    today: "Hoy",
    now: "Ahora",
    posted: "Publicado %by_part% el %date%",
    by_part: "por %name%",
    "maps.CVD.title": "Tipos de mapas fuera de l\u00ednea",
    "UI.SettingsDialog.TrafficIncidents": "Incidentes de tr\u00e1fico",
    "UI.SettingsDialog.Language": "Idioma",
    "SMS.sentSuccessfully": "\u00a1El SMS ha sido enviado exitosamente!",
    "maps.BP.below": "debajo",
    "maps.BP.above": "arriba",
    "RA.Station": "Estaci\u00f3n",
    North: "N",
    West: "O",
    South: "S",
    East: "E",
    "maps.Nav.englishOnlyAudio": "Audio s\u00f3lo en ingl\u00e9s"
};
nokia.mh5.buildNS("nokia.mh5.i18n_languages");
nokia.mh5.i18n_languages["pt-br"] = {
    "Error.applicationCredential": " a appID ou o appCode est\u00e3o faltando. Por favor inscreva-se para as credenciais da API em http://nka.fi/EvZeT.",
    "Error.controlProperty": "A propriedade de Controle n\u00e3o foi definida",
    "Error.prepareBindings": "%value% n\u00e3o pode ser associada porque %snmspa% n\u00e3o pode ser resolvida",
    "Error.propertyCannotBeOverwritten": "A propriedade: '%name%' n\u00e3o pode ser sobrescrita",
    "Error.customContentNotAllowed": "Voc\u00ea n\u00e3o pose user conte\u00fado customizado com chamado %name% porque j\u00e1 est\u00e1 sendo usado",
    "Error.unableToRemove": "N\u00e3o \u00e9 poss\u00edvel remover '%name%' ",
    "Error.routeTooLong": "Rotas para pedestres n\u00e3o est\u00e3o dispon\u00edveis para rotas com mais de %maxWalkingDistance%.",
    "Error.tooLongWalkingDistance": "Seu destino n\u00e3o est\u00e1 a uma curta dist\u00e2ncia da sua localiza\u00e7\u00e3o atual.",
    "Error.placeRemovedByOwner.header": "Desculpe.",
    "Error.placeRemovedByOwner.message": "N\u00f3s n\u00e3o temos mais qualquer informa\u00e7\u00e3o sobre este lugar.",
    "Error.placeError.header": "N\u00e3o foi poss\u00edvel mostrar esse lugar agora.",
    "Error.placeError.message": "Por favor tente mais tarde.",
    "Warning.placeId": "A propriedade `id` no objeto local foi renomeada para `placeId`",
    "Notification.addedToFavourites": "Adicionado aos seus favoritos",
    "Notification.cantFindLocation": "Sua localiza\u00e7\u00e3o n\u00e3o pode ser encontrada. Por favor inserir seu ponto de partida acima.",
    "Notification.connectionError": "Por favor cheque sue conex\u00e3o e tent novamente",
    "Notification.destInWalkingDistance": "Destino est\u00e1 a uma curta dist\u00e2ncia",
    "Notification.error": "Houve um problema",
    "Notification.favouritesNoSaved": "N\u00e3o foi poss\u00edvel salvar favoritos",
    "Notification.goOnline": "Conecte-se \u00e0 internet para pesquisar locais e endere\u00e7os",
    "Notification.goOnlineForRouting": "Conecte-se \u00e0 internet para tra\u00e7ar rotas",
    "Notification.goOnlinePlaceHolder": "Conecte-se \u00e0 internet para pesquisar",
    "Notification.lookingForCurrentPosition": "Encontrando sua localiza\u00e7\u00e3o atual",
    "Notification.noGPSSignal": "Sua localiza\u00e7\u00e3o n\u00e3o pode ser encontrada",
    "Notification.noModeAvailable": "O modo %mode% n\u00e3o est\u00e1 dispon\u00edvel",
    "Notification.noPublicTransportService": "Rotas em transporte p\u00fablico n\u00e3o est\u00e3o dispon\u00edveis neste local",
    "Notification.noResult": "Nenhum resultado",
    "Notification.noResultFound": "Nenhum resultado encontrado",
    "Notification.noRoutingService": "Desculpe. Rotas n\u00e3o est\u00e3o dispon\u00edveis no momento. Por favor tente mais tarde.",
    "Notification.offRoute": "Voc\u00ea parece estar fora da rota por %value%",
    "Notification.positionNotAvailable": "Sua localiza\u00e7\u00e3o n\u00e3o pode ser encontrada",
    "Notification.removedFromFavourites": "Removido dos seus favoritos",
    "Notification.routeCalculation": "Tra\u00e7ando sua rota",
    "Notification.searchProblem": "H\u00e1 um problema no momento. Por favor, tente pesquisar novamente mais tarde.",
    "Notification.serverError": "Desculpe. H\u00e1 um problema do nosso lado. Por favor, procure novamente mais tarde.",
    "Notification.unableToLoadImage": "N\u00e3o foi poss\u00edvel carregar a imagem",
    "Notification.trafficInBeta": "A visualiza\u00e7\u00e3o de tr\u00e1fego ainda est\u00e1 em beta.",
    eating: "Comer fora",
    shopping: "Compras",
    "going-out": "Sair",
    sights: "Atra\u00e7\u00f5es",
    maps: "Visualiza\u00e7\u00f5es",
    layers: "Tr\u00e1fego",
    mapControl: "Controle do mapa",
    mapTermsOfUse: "Termos de Uso",
    about: "Sobre",
    alert: "Aviso",
    beta: "beta",
    basic: "b\u00e1sico",
    businessOwner: "Propriet\u00e1rio do Neg\u00f3cio",
    call: "Discar",
    cancel: "Cancelar",
    confirm: "Confirmar",
    "confirm.message": "Confirma que quer continuar?",
    "delete": "Apagar",
    done: "Pronto",
    favourite: "Favorito",
    favouritesWithName: "Favoritos de %name%",
    favourites: "Favoritos",
    feedback: "Coment\u00e1rios",
    from: "De",
    guides: "Guias",
    highest: "O mais alto",
    hr: "hr",
    min: "min",
    km: "km",
    location: "localiza\u00e7\u00e3o",
    minApprox: "min aprox",
    more: "Mais",
    nearbyPlaces: "Lugares pr\u00f3ximos",
    ok: "Ok",
    place: "local",
    refresh: "Atualizar",
    retry: "Tente novamente",
    reviews: "Coment\u00e1rios",
    route: "Rota",
    save: "Salvar",
    search: "Pesquisar",
    searchPlaces: "Pesquisar locais",
    searching: "Pesquisando",
    send: "Enviar",
    sending: "Enviando",
    signin: "Entre",
    signout: "Sair",
    share: "Compartilhar",
    source: "Fonte",
    start: "Iniciar",
    submit: "Enviar",
    take: "Pegue",
    hi: "Oi %name%!",
    thankYou: "Obrigado.",
    to: "Para",
    towards: "em dire\u00e7\u00e3o a",
    web: "Web",
    welcome: "Bem vindo HERE",
    collections: "Cole\u00e7\u00f5es",
    sms: "SMS",
    tel: "tel",
    email: "Email",
    shareVia: "compartilhar via",
    imagesProvidedBy: "Imagens de ",
    contentProvidedBy: "Conte\u00fado de ",
    openingTimes: "Hor\u00e1rio de funcionamento",
    placeDescription: "Descri\u00e7\u00e3o do local",
    followFor: "Siga por",
    saveMapArea: "Salvar \u00e1rea do mapa",
    reportPlace: "Relatar este local",
    "report.title": "Relatar um local \u00e0 Nokia",
    "report.message": 'Se voc\u00ea quiser relatar um local, por favor v\u00e1 a Here.com em um computador, busque pelo local, clique em "Mais detalhes" e depois em "Relatar este local".',
    paymentMethods: "Modos de pagamento",
    PT: "Transporte p\u00fablico",
    addingA: "Adicionando",
    removingA: "Removendo",
    currentLocation: "Localiza\u00e7\u00e3o atual",
    messageHere: "Mensagem aqui",
    shareAPlace: "Compartilhe um local",
    "EP.idLikeTo": "Ol\u00e1, est\u00e1 aqui uma coisa para voc\u00ea dar uma olhada no HERE.",
    "SMS.plsEnterNum": "Por favor insira o n\u00famero do destinat\u00e1rio<br />(incluindo o c\u00f3digo de pa\u00eds, ex. +441234567890)",
    "SMS.plsCheckNum": "Por favor confira o n\u00famero do telefone",
    "SMS.alsoShort": "Adicione uma nota (se voc\u00ea quiser):",
    "SMS.enterCaptcha": "Digite aqui os caracteres que voc\u00ea v\u00ea abaixo",
    "SMS.wrongCaptcha": "Por favor, tente outro c\u00f3digo de seguran\u00e7a",
    "SMS.enterCode": "Digite o c\u00f3digo aqui",
    "SMS.unableToSend": "N\u00e3o foi poss\u00edvel enviar a sua mensagem. Por favor, tente novamente mais tarde.",
    "FV.startSaving": "Comece a salv\u00e1-los agora!",
    "FV.startSavingHint": "Os lugares que voc\u00ea ama est\u00e3o ao seu alcance, quando voc\u00ea adicion\u00e1-los aos seus Favoritos.",
    "FV.takeAllFavourites": "Registre-se e leve seus Favoritos com voc\u00ea.",
    "FV.simplyTap": "Basta tocar a estrela azul na p\u00e1gina de lugar.",
    "FV.tapTheHighlighted": "Toque a estrela amarela, e o lugar n\u00e3o est\u00e1 mais em sua lista.",
    "FV.syncing": "Sincronizando",
    "FV.syncedFavourites": "Tudo est\u00e1 sincronizado",
    "FV.addedButUnsyncedFavourites": "Adicionado mas ainda n\u00e3o sincronizado",
    "FV.addedNotSignedIn": "Adicionado aos Favoritos",
    "FV.addedSignedIn": "Adicionado aos Favoritos e sincronizando",
    "FV.removedNotSignedIn": "Removido dos Favoritos",
    "FV.removedSignedIn": "Removido dos Favoritos e sincronizando",
    "FV.signInToSyncronize": "Registre-se para sincronizar",
    "FV.couldNotSync": "N\u00e3o foi poss\u00edvel sincronizar",
    "RA.arriveAt": "Chegar a",
    "RA.departFrom": "Partir de",
    "RA.drive": "dirigir",
    "RA.walk": "caminhar",
    "RA.walkTo": "Caminhar para",
    "RA.disclaimer": "As informa\u00e7\u00f5es de transporte s\u00e3o fornecidas pelas ag\u00eancias de transportes locais e est\u00e3o sujeitas a altera\u00e7\u00f5es. Informa\u00e7\u00f5es mais detalhadas e atualizadas sobre hor\u00e1rios e servi\u00e7os podem estar dispon\u00edveis no site da ag\u00eancia:",
    "RA.for1Stop": "Por 1 parado",
    "RA.forXStops": "Por %stops% paradas",
    "UI.SettingsDialog.mapView": "Exibi\u00e7\u00e3o do Mapa",
    "UI.SettingsDialog.satView": "Sat\u00e9lite",
    "UI.SettingsDialog.PTView": "Transporte p\u00fablico",
    "UI.SettingsDialog.trafficView": "Tr\u00e1fego em tempo real",
    "UI.SettingsDialog.Km": "Quil\u00f4metros",
    "UI.SettingsDialog.Miles": "Milhas",
    "UI.SettingsDialog.Accidents": "Acidente",
    "UI.SettingsDialog.Congestions": "Congestionamento",
    "UI.SettingsDialog.Constructions": "Constru\u00e7\u00e3o",
    "UI.SettingsDialog.Others": "Outro",
    "UI.SettingsDialog.CommunityMaps": "Vis\u00e3o de Comunidade",
    "UI.SettingsDialog.CommunityMapFootnote": "Mapas comunit\u00e1rios s\u00e3o mapas vivos \u2013 criados e atualizados por usu\u00e1rios ao redor do mundo",
    "wrongZoom.title": "Your browser is currently scaling the contents of this page",
    "wrongZoom.message": 'For an optimal view go to "Settings" &gt; "Advanced" and set "Default zoom" to "Medium"',
    "maps.BP.bookmark": "Para aproveitar ao m\u00e1ximo o HERE, adicione o nosso aplicativo como um \u00edcone na sua tela inicial.",
    "maps.BP.install": "Para instalar o aplicativo, clique no bot\u00e3o %dir% e depois em 'Adicionar \u00e0 Tela Inicial'.",
    "maps.CVD.details": "N\u00edvel de detalhe que voc\u00ea pode esperar:",
    "maps.CVD.viewDetails": "N\u00edvel de detalhe na visualiza\u00e7\u00e3o atual:",
    "maps.CVD.tooLarge": "Esta \u00e1rea \u00e9 muito grande. Mova e aproxime para centralizar o bairro que voc\u00ea deseja salvar.",
    "maps.CVD.goOnline": "Voc\u00ea precisa de uma conex\u00e3o de dados para salvar o mapa.",
    "maps.CVD.rangeOfDetails": "Aqui est\u00e1 a gama de detalhes voc\u00ea pode ver nos mapas de \u00e1reas salvos. Note que quanto mais detalhes voc\u00ea quiser, menor ser\u00e1 a \u00e1rea de seu mapa.",
    "maps.CVD.world": "Detalhes b\u00e1sicos",
    "maps.CVD.country": "Alguns detalhes",
    "maps.CVD.city": "Detalhes medianos",
    "maps.CVD.district": "Muitos detalhes",
    "maps.CVD.street": "Detalhes m\u00e1ximos",
    "maps.CVD.worldDesc": "Veja continentes, pa\u00edses, cidades, auto-estradas, os n\u00fameros de estradas e florestas",
    "maps.CVD.countryDesc": "Veja pa\u00edses, cidades, distritos, auto-estradas, ruas principais, n\u00fameros de estradas, aeroportos, florestas e lagos",
    "maps.CVD.cityDesc": "Veja cidades, distritos, grades detalhadas rua, ferrovias e esta\u00e7\u00f5es, transporte p\u00fablico grande, parques e lagos",
    "maps.CVD.districtDesc": "Veja distritos, grades de rua mais detalhados, ferrovias, todos os transportes p\u00fablicos, edif\u00edcios, parques e caminhos",
    "maps.CVD.streetDesc": "Ver todas as ruas e nomes, ferrovias, todos os transportes p\u00fablicos, todos os edif\u00edcios, parques e caminhos",
    "maps.SPD.startDownload": "Inicie seu download",
    "maps.SPD.savingArea": "Salvando seu mapa de \u00e1rea",
    "maps.SPD.instructionStart": "O download de mapas pode ser longo, por isso lembre-se de usar conex\u00e3o Wi-Fi. <br><br> N\u00e3o feche este aplicativo ao salvar seu mapa, e certifique-se de que o protetor de tela n\u00e3o se ative.",
    "maps.SPD.instructionLoad": "O download de mapas pode ser longo, por isso lembre-se de usar conex\u00e3o Wi-Fi. <br><br> N\u00e3o feche este aplicativo ao salvar seu mapa, e certifique-se de que o protetor de tela n\u00e3o se ative.",
    "maps.SPD.instructionFinished": "Seu mapa foi salvo. <br> Voc\u00ea pode encontr\u00e1-lo agora, em seu trampolim. <br><br> <span Style='font-weight: bold'> Note que salvar um mapa de \u00e1rea novo sempre substitui o \u00faltimo que voc\u00ea salvou. </ span>",
    "maps.SPD.keepInMind": "Note que salvar um mapa de \u00e1rea novo sempre substitui o \u00faltimo que voc\u00ea salvou.",
    "maps.SPD.minZoom": "Seu n\u00edvel de zoom m\u00ednimo",
    "maps.SPD.maxZoom": "Seu n\u00edvel de zoom m\u00e1ximo",
    "maps.SPD.waiting": "Aguardando o download come\u00e7ar",
    "maps.SPD.smtUnexpected": "Houve um problema durante o download",
    "maps.SB.saveMap": "Salvar um mapa de \u00e1rea",
    "maps.SB.viewMap": "Ver seu mapa salvo",
    "maps.NPS.recommend": "Qual a probabilidade de voc\u00ea recomendar o HERE Maps para um amigo ou colega?",
    "maps.NPS.notLikely": "Nem um pouco prov\u00e1vel",
    "maps.NPS.extremelyLikely": "Extremamente prov\u00e1vel",
    "maps.NPS.why": "Por favor nos diga por que voc\u00ea deu essa nota",
    "maps.NPS.enterMessage": "Digite a mensagem aqui...",
    "maps.NPS.email": "Digite o seu endere\u00e7o de email",
    "maps.NPS.NPP": 'Suas informa\u00e7\u00f5es ser\u00e3o tratadas de acordo com a <a href="http://nokia.mobi/privacy/policy" target="blank">Pol\u00edtica de Privacidade da Nokia </ a>.',
    "maps.NPS.noSend": "N\u00e3o foi poss\u00edvel enviar. Por favor, tente novamente.",
    "maps.NPS.contact": "A Nokia pode me contactar para mais detalhes",
    "maps.Nav.headDirectionforDistance": "Siga %direction% por %distance%",
    "maps.Nav.reachedDestination": "Voc\u00ea chegou ao seu destino",
    "maps.Nav.speeding": "Se voc\u00ea ainda est\u00e1 andando, voc\u00ea anda muito r\u00e1pido! A navega\u00e7\u00e3o vai recome\u00e7ar quando voc\u00ea for mais devagar.",
    "maps.Nav.tryAgain": "O download n\u00e3o funcionou",
    "maps.Nav.disclaimerTitle": "Usando navega\u00e7\u00e3o com audio",
    "maps.Nav.disclaimerPoint1": "Fique atento ao seu entorno e de olhos abertos para carros e outros desafios urbanos.",
    "maps.Nav.disclaimerPoint2": "A tela do telefone n\u00e3o deve ficar escura, ou voc\u00ea pode n\u00e3o ser capaz de ouvir as instru\u00e7\u00f5es corretamente. Al\u00e9m disso, certifique-se de baixar o arquivo de voz antes (1.9MB).",
    "maps.Nav.disclaimerPoint3": "Usar os servi\u00e7os da Nokia pode envolver grandes volumes de dados movimentados atrav\u00e9s da rede do seu provedor. Nem todos os servi\u00e7os podem estar dispon\u00edveis ou 100% precisos o tempo todo. Al\u00e9m disso, pode envolver o envio de dados sobre a sua localiza\u00e7\u00e3o.",
    "maps.Nav.disclaimerPoint4": 'Ao tocar \'Carregar audio\', voc\u00ea confirma que leu e concorda com os <a href="http://nokia.mobi/privacy/services/terms/nokia-service" onclick="event.stopPropagation();" target="blank">Termos do Servi\u00e7o</ a> e <a href="http://nokia.mobi/privacy/policy" onclick="event.stopPropagation();" target="blank">Pol\u00edtica de Privacidade Nokia</a>. Para saber mais <a href="http://nokia.mobi/privacy/services/map-apps" onclick="event.stopPropagation();" target="blank"> clique aqui</ a>.',
    "maps.Nav.success": "Download terminado",
    "maps.Nav.load": "Carregar audio",
    "maps.Nav.start": "Iniciar jornada",
    "maps.Traffic.incidentDescription": "em %origin% em dire\u00e7\u00e3o a %direction%",
    "maps.Traffic.incidentDescriptionNoDirection": "em %origin%",
    "maps.Traffic.incidentAt": "em %start%",
    "maps.Traffic.incidentUnidir": "de %start% at\u00e9 %end%",
    "maps.Traffic.incidentBidir": "entre %start% e %end%",
    "maps.Traffic.incidentStartTime": "Hora de in\u00edcio",
    "maps.Traffic.incidentEndTime": "Hora aproximada de t\u00e9rmino",
    "maps.Traffic.incidentDateFormat": "%day%/%month%/%year% %hour%:%minute%",
    "maps.Traffic.criticalityTitle": "Gravidade",
    "maps.Traffic.critical": "Cr\u00edtica",
    "maps.Traffic.major": "Maior",
    "maps.Traffic.minor": "Menor",
    "collections.notification.message": "An error has occurred processing your request.  Please try again later.",
    "collections.notification.message.syncing": "Sincronizando ...",
    "collections.notification.message.syncComplete": "Tudo est\u00e1 sincronizado.",
    "collections.common.itemsCount": " itens",
    "collections.common.button.next": "Pr\u00f3ximo",
    "collections.common.button.save": "Salvar",
    "collections.common.button.cancel": "Cancelar",
    "collections.common.button.create": "Criar nova cole\u00e7\u00e3o",
    "collections.common.button.delete": "Excluir cole\u00e7\u00e3o",
    "collections.common.confirmation.delete": "Voc\u00ea tem certeza que deseja excluir esta cole\u00e7\u00e3o?",
    "collections.common.confirmation.favourite.delete": "Voc\u00ea tem certeza que deseja excluir este item?",
    "collections.common.confirmation.favourite.delete.collections": "Este item est\u00e1 salvo em mais de uma cole\u00e7\u00e3o.\n\nExclu\u00ed-lo aqui vai exclu\u00ed-lo em todos os lugares.",
    "collections.util.Date.at": " em ",
    "collections.CollectionsBar.myCollections": "Minhas cole\u00e7\u00f5es",
    "collections.CollectionListPage.organize": "A organizar",
    "collections.CollectionListPage.button.label.create": "Criar nova",
    "collections.CollectionListPage.button.label.collection": "cole\u00e7\u00e3o",
    "collections.CollectionListPage.collectionCount": " cole\u00e7\u00f5es",
    "collections.CollectionListPage.ftu.signIn": "Entre para criar cole\u00e7\u00f5es",
    "collections.CollectionListPage.ftu.intro.signedOut": "<h1 class='mh5_title'>Colecione lugares para se lembrar e lugares para ir</h1>Encontre-os novamente a qualquer momento, em qualquer lugar, no seu celular, tablet ou computador.",
    "collections.CollectionListPage.ftu.intro.signedIn.hasUngrouped": "Gerencie locais e coloque-os em cole\u00e7\u00f5es - para encontr\u00e1-los com mais facilidade e rapidez.",
    "collections.CollectionListPage.ftu.intro.signedIn.hasNoUngrouped": "<h1 class='mh5_title'>Bem vindo \u00e0s cole\u00e7\u00f5es</h1>Comece a colecionar todos os locais que voc\u00ea queira ou precise salvar para mais tarde - e deixe a memoriza\u00e7\u00e3o por nossa conta!",
    "collections.CollectionListPage.ftu.button.create": "Crie sua primeira cole\u00e7\u00e3o",
    "collections.CollectionListPage.sortedBy": "Organizado por",
    "collections.CollectionListPage.sort.lastUpdated": "\u00faltima atualiza\u00e7\u00e3o em",
    "collections.CollectionListPage.sort.name": "nome",
    "collections.CollectionListPage.sort.numItems": "quantidade de itens",
    "collections.CollectionListPage.unsortedItems": "Itens n\u00e3o organizados",
    "collections.CollectionListPage.title": "Cole\u00e7\u00f5es",
    "collections.CreateCollectionAddItems.pageTitle": "Selecione itens",
    "collections.CreateCollectionAddItems.intro": "Escolha o que adicionar \u00e0 cole\u00e7\u00e3o",
    "collections.CreateCollectionAddItems.filterBy": "Filtrar por:",
    "collections.CreateCollectionAddItems.fromLabel": "DE:",
    "collections.CreateCollectionAddItems.toLabel": "PARA:",
    "collections.CreateCollectionAddItems.filter.all": "Todos",
    "collections.CreateCollectionAddItems.filter.addresses": "Endere\u00e7o",
    "collections.CreateCollectionAddItems.filter.restaurants": "Restaurantes",
    "collections.CreateCollectionAddItems.filter.routes": "Rotas",
    "collections.CreateCollectionAddItems.filter.shoppings": "Shoppings",
    "collections.CreateCollectionAddItems.filter.sights": "Atra\u00e7\u00f5es",
    "collections.CreateCollection.pageTitle": "Criar cole\u00e7\u00e3o",
    "collections.CreateCollection.image.instruction": "Selecione uma imagem para dar um toque especial \u00e0 sua cole\u00e7\u00e3o",
    "collections.CreateCollection.collectionName.placeholder": "Nova cole\u00e7\u00e3o",
    "collections.CreateCollection.personalize.placeholder": "Adicionar descri\u00e7\u00e3o",
    "collections.CreateCollection.personalize.characterLimit": "max. 100 caracteres",
    "collections.CreateCollection.mandatoryFieldNote": "* Nomear sua cole\u00e7\u00e3o \u00e9 obrigat\u00f3rio. E ajuda voc\u00ea a se lembrar o que ela cont\u00e9m.",
    "collections.ToOrganize.pageTitle": "A organizar",
    "collections.CollectionEdit.pageTitle": "Cole\u00e7\u00e3o",
    "collections.CollectionEdit.addItemLabel": " Adicionar item",
    "collections.CollectionEdit.addItems": "Adicionar itens",
    "collections.CollectionEdit.allCollectedItems": "Todos os itens colecionados",
    "collections.CollectionEdit.noCollectedItems": "Nenhum item colecionado",
    "collections.CollectionEdit.noCollectedItems.intro": "Crie sua primeira cole\u00e7\u00e3o agora. Voc\u00ea poder\u00e1 sempre adicionar outros locais.",
    "collections.CollectionEdit.editFavoritesLabel": "Editar",
    "collections.CollectionEdit.itemsTitle": "Itens nessa cole\u00e7\u00e3o",
    "collections.CollectionEdit.selectItems": "Selecione items para adicionar a essa cole\u00e7\u00e3o",
    "collections.CollectionEdit.editDetailsLabel": "Detalhes da cole\u00e7\u00e3o",
    "collections.CollectionEditDetails.pageTitle": "Detalhes da cole\u00e7\u00e3o",
    "collections.details.title": "Cole\u00e7\u00e3o",
    "collections.details.manage": "Gerenciar",
    "collections.details.create": "Criar",
    "collections.favourite.edit.collect": "Colecionar",
    "collections.favourite.edit.manage": "Gerenciar",
    "collections.favourite.edit.delete": "Excluir item",
    "collections.favourite.edit.collectionsListTitle": "Organizar em cole\u00e7\u00f5es",
    "maps.Traffic.Accident": "Acidentes",
    "maps.Traffic.Construction": "Constru\u00e7\u00e3o",
    "maps.Traffic.Congestion": "Congest\u00e3o",
    "maps.Traffic.Disabledvehicle": "Ve\u00edculo Incapacitado",
    "maps.Traffic.Roadhazard": "Perigo na Estrada",
    "maps.Traffic.Masstransit": "Transportes P\u00fablicos",
    "maps.Traffic.Othernews": "Outras Not\u00edcias",
    "maps.Traffic.Weather": "Tempo",
    "maps.Traffic.Misc": "Diversos",
    "maps.Traffic.Plannedevent": "Evento Planejado",
    "day.sunday": "Domingo",
    "day.monday": "Segunda-feira",
    "day.tuesday": "Ter\u00e7a-feira",
    "day.wednesday": "Quarta-feira",
    "day.thursday": "Quinta-feira",
    "day.friday": "Sexta-feira",
    "day.saturday": "S\u00e1bado",
    today: "Hoje",
    now: "Agora",
    posted: "Enviado %by_part% em %date%",
    by_part: "por %name%",
    "maps.CVD.title": "Tipos de mapas offline",
    "UI.SettingsDialog.TrafficIncidents": "Incidentes de tr\u00e2nsito",
    "UI.SettingsDialog.Language": "Idioma",
    "SMS.sentSuccessfully": "A mensagem de texto foi enviada com sucesso!",
    "maps.BP.below": "abaixo",
    "maps.BP.above": "acima",
    "RA.Station": "Esta\u00e7\u00e3o",
    North: "N",
    West: "O",
    South: "S",
    East: "E",
    "maps.Nav.englishOnlyAudio": "Audio apenas dispon\u00edvel em Ingl\u00eas"
};
nokia.mh5.provide("nokia.mh5.platform");
(function(g) {
    var a = g.navigator,
        b = a.userAgent.toLowerCase(),
        c = nokia.mh5.win.location.href,
        e = g.devicePixelRatio || 1,
        i = g.document.documentElement,
        i = g.outerHeight ? g.outerHeight * g.outerWidth / e : i.clientHeight ? i.clientHeight * i.clientWidth / e : 0,
        i = /lo=tablet/.test(c) || !/lo=phone/.test(c) && !/ip(?:hone|od)/.test(b) && (/gt-p1000/.test(b) || 614400 < i || /iPad/.test(a.platform));
    nokia.mh5.platform = {
        iphone: /iPhone/.test(a.platform),
        iphone5: /iPhone/.test(a.platform) && 568 === g.screen.height,
        ipod: /iPod/.test(a.platform),
        ipad: /iPad/.test(a.platform),
        ios: /(iPhone)|(iPod)|(iPad)/.test(a.platform),
        android: /android/.test(b) && !/firefox/.test(b),
        playbook: /playbook/.test(b),
        blackberry: /blackberry/.test(b),
        tablet: i,
        phone: !i,
        android_webview: !! nokia.mh5.win.android_js_interface,
        n9: /nokian9/.test(b),
        ios_webview: /(iPhone)|(iPod)|(iPad)/.test(a.platform) && (/phonegap/.test(b) || window.cordova || window.Cordova),
        ie: /msie/.test(b),
        wphone: /Windows Phone/i.test(b),
        firefox: /firefox/.test(b),
        firefox_mobile: /firefox/.test(b) && /mobile/.test(b),
        language: (b.match(/\w{2}-\w{2}/) && RegExp.lastMatch || a.language || a.browserLanguage).toLowerCase(),
        vendorPrefix: function() {
            for (var a = "t,webkitT,MozT,msT".split(","), d = 0; d < a.length; d++) if (a[d] + "ransform" in nokia.mh5.doc.documentElement.style) return a[d].substr(0, a[d].length - 1);
            return !1
        }(),
        backButton: /back=true/.test(c),
        retina: 1.5 <= e || /Windows Phone/i.test(b),
        cssTransform3dSupported: function() {
            var a = nokia.mh5.doc.createElement("div"),
                d = ["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"],
                b = !1,
                f;
            for (f in d) if (d[f] in a.style) {
                b = !0;
                break
            }
            a.className = "mh5_cssTransform3dTest";
            nokia.mh5.doc.body.appendChild(a);
            b = b && "relative" === nokia.mh5.win.getComputedStyle(a, null).position;
            a.parentNode && a.parentNode.removeChild(a);
            return b
        }(),
        hideAddressBar: function(a) {
            var d = "undefined" == typeof g.orientation || 0 === g.orientation || 180 == g.orientation,
                b;
            if (nokia.mh5.platform.iphone || nokia.mh5.platform.ipod) g.document.body.style.minHeight = nokia.mh5.platform.iphone5 ? (d ? 504 : 268) + "px" : (d ? 416 : 268) + "px", b = setTimeout(function() {
                clearTimeout(b);
                g.scrollTo(0, 0)
            }, 0);
            else if (nokia.mh5.platform.android) var f = setTimeout(function() {
                clearTimeout(f);
                a && "orientationchange" === a.type && g.scrollTo(0, 0);
                var d = g.devicePixelRatio;
                if (!d || 1 > d) d = 0.9;
                g.document.body.style.minHeight = g.outerHeight / d + "px";
                b = setTimeout(function() {
                    clearTimeout(b);
                    g.scrollTo(0, 1)
                }, 1)
            }, nokia.mh5.platform.hideAddressBar.DELAY)
        },
        webview: !1
    };
    nokia.mh5.platform.hideAddressBar.DELAY = 200;
    if (nokia.mh5.platform.ios) nokia.mh5.platform.ios = {
        io4: -1 !== b.indexOf("os 4_"),
        io5: -1 !== b.indexOf("os 5_")
    };
    if (nokia.mh5.platform.android) a = /android ([0-9].[0-9])/.exec(b), b = /(chrome)/.exec(b), nokia.mh5.platform.android = {
        version: a && 0 < a.length && a[1],
        browser: b ? "chrome" : "default"
    };
    nokia.mh5.platform.webview = nokia.mh5.platform.ios_webview || nokia.mh5.platform.android_webview;
    nokia.mh5.platform.undetectable = !(nokia.mh5.platform.ios || nokia.mh5.platform.android || nokia.mh5.platform.firefox || nokia.mh5.platform.firefox_mobile || nokia.mh5.platform.blackberry || nokia.mh5.platform.playbook);
    nokia.mh5.platform.backButton = nokia.mh5.platform.backButton || nokia.mh5.platform.ios_webview
})(this);
nokia.mh5.provide("nokia.mh5.utils");
(function(g) {
    function a(a, b) {
        return void 0 !== this[b] ? this[b] : ""
    }
    var b = {},
        c = g.localStorage || {
            getItem: function(a) {
                return c["_" + a]
            },
            setItem: function(a, b) {
                c["_" + a] = b
            }
        },
        e = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };
    nokia.mh5.utils = {
        place: {
            getCategoryIconForFav: function(a) {
                var b = {
                    accommodation: "01",
                    hotel: "01",
                    motel: "01",
                    hostel: "01",
                    camping: "14",
                    "business-services": "02",
                    "atm-bank-exchange": "15",
                    "police-emergency": "19",
                    "post-office": "20",
                    "tourist-information": "21",
                    "petrol-station": "18",
                    "car-rental": "17",
                    "car-dealer-repair": "16",
                    "travel-agency": "02",
                    "communication-media": "02",
                    "business-industry": "02",
                    service: "02",
                    "eat-drink": "03",
                    restaurant: "03",
                    "snacks-fast-food": "03",
                    "bar-pub": "22",
                    "coffee-tea": "23",
                    facilities: "04",
                    "hospital-health-care-facility": "26",
                    "government-community-facility": "25",
                    "education-facility": "04",
                    library: "27",
                    "fair-convention-facility": "24",
                    "parking-facility": "28",
                    "toilet-rest-area": "29",
                    "sports-facility-venue": "30",
                    facility: "04",
                    "going-out": "05",
                    "dance-night-club": "33",
                    cinema: "32",
                    "theatre-music-culture": "05",
                    casino: "31",
                    "administrative-areas-buildings": "06",
                    "administrative-region": "06",
                    "city-town-village": "35",
                    "street-square": "06",
                    "outdoor-area-complex": "06",
                    building: "06",
                    "leisure-outdoor": "07",
                    recreation: "07",
                    "amusement-holiday-park": "34",
                    "natural-geographical": "08",
                    "body-of-water": "36",
                    "mountain-hill": "08",
                    "undersea-feature": "08",
                    "forest-heath-vegetation": "08",
                    shopping: "09",
                    "kiosk-convenience-store": "09",
                    mall: "09",
                    "department-store": "09",
                    "food-drink": "09",
                    bookshop: "09",
                    pharmacy: "37",
                    "electronics-shop": "09",
                    "hardware-house-garden-shop": "09",
                    "clothing-accessories-shop": "09",
                    "sport-outdoor-shop": "09",
                    shop: "09",
                    "sights-museums": "10",
                    "landmark-attraction": "38",
                    museum: "10",
                    "religious-place": "39",
                    transport: "11",
                    airport: "40",
                    "railway-station": "43",
                    "public-transport": "11",
                    "ferry-terminal": "41",
                    "taxi-stand": "42"
                };
                return (b[a] ? b[a] : "06") + "_04.icon.mh5.basic.200.png"
            },
            getCategoryIcon: function(a) {
                var b = nokia.mh5.assetsPath + "img/categories/",
                    d;
                if (a.categoryIcon) return a.categoryIcon;
                if (!a.icon) a.icon = "06.icon";
                d = a.icon.match(/((\d+)(_\d{2})?\.icon)/);
                b += a.favourite && !d[4] ? d[2] + "_04.icon" : d[1];
                return b + ".mh5.basic.200.png"
            },
            categoryIdentifier: function() {
                for (var a = ["business-services", ["service", 215, 207, 258, "business-services", 269, "atm-bank-exchange", 47, "car-rental", 20, "car-dealer-repair", 2, 46, 51, 56, "travel-agency", 277, "communication-media", 278, "business-industry", 5], "transport", ["transport", 272, 218, 53, "airport", 43, "railway-station", 41, "public-transport", 58, "ferry-terminal", 35, "taxi-stand", 216], "shopping", ["food-drink", 143, "shop", 23, "shopping", 270, 142, 23, "clothing-accessories", 205, "clothing-accessories-shop", 205, "mall", 24, "department-store", 189, "electronics", 196, "electronics-shop", 196, "hardware-house-garden", 194, "hardware-house-garden-shop", 194, "bookshop", 276, "sport-outdoor-shop", 191, "kiosk-24-7-convenience-store", 197, "kiosk-convenience-store", 197], "accommodation", ["accommodation", 271, "hostel", 173, "hotel", 38, "motel", 174, "camping", 32], "going-out", ["going-out", 274, "dance-or-night-club", 203, "dance-night-club", 203, "casino", 3, "cinema", 4, "theatre-music-culture", 181], "facilities", ["facilities", 261, 212, 268, "facility", 261, 212, "fair-convention-facility", 7, "government-or-community-facility", 12, "government-community-facility", 12, "library", 31, "parking-facility", 39], "natural-geographical", ["natural-geographical", 265, "body-of-water", 262, "mountain-or-hill", 45, "undersea-feature", 260, "forest-heat-or-other-vegetation", 259, "forest-heath-vegetation", 259], "administrative-areas-buildings", ["administrative-region", 279, "city-town-or-village", 283, "city-town-village", 283, "outdoor-area-complex", 263, "building", 280, "administrative-areas-buildings", 266], "eat-drink", ["bar-pub", 33, "eat-drink", 275, "restaurant", 22, "coffee-tea", 63, "snacks-fast-food", 64], "leisure-outdoor", ["amusement-or-holiday-park", 1, "amusement-holiday-park", 1, "leisure-outdoor", 267, "recreation", 48], "sights-museums", ["sights-museums", 273, 213, "landmark-attraction", 27, 211, 213, 163, 153, 150, 147, 148, 149, 184, "museum", 14], "address", ["address", 284], "religious-place", ["religious-place", 158], "pharmacy", ["pharmacy", 49], "education-facility", ["education-facility", 106], "hospital-health-care-facility", ["hospital-or-health-care-facility", 200, 209, "hospital-health-care-facility", 200, 209], "sport-facility-venue", ["sport-outdoor", 220, "sports-outdoor", 220, "sport-facility-venue", 220, "sports-facility-venue", 220], "police-emergency", ["police-emergency", 40], "post-office", ["post-office", 19], "tourist-information", ["tourist-information", 28], "petrol-station", ["petrol-station", 17]], b = {}, d = {}, e = [].indexOf, f = [].forEach, c = function(a) {
                        var f = "" + this;
                        "number" == typeof a && 9E6 > a && (d[a + 9E6] = f, b.hasOwnProperty(f) || (b[f] = []), 0 > e.call(b[f], a + 9E6) && b[f].push(a + 9E6));
                        d[a] = f
                    }, g = 0, n = a.length; g < n; g += 2) f.call(a[g + 1], c, a[g]);
                return function(a, f) {
                    var e = d[a];
                    return f ? b[e].join(",") : e
                }
            }()
        },
        getLocalStorageValue: function(a) {
            return c.getItem(a)
        },
        setLocalStorageValue: function(a, b) {
            try {
                c.setItem(a, b)
            } catch (d) {
                return !1
            }
            return !0
        },
        removeLocalStorageValue: function(a) {
            c.removeItem(a)
        },
        formatString: function(b, e) {
            return b.replace(/%([^%]+)%/g, a.bind(e))
        },
        escapeHTML: function(a) {
            return ("" + a).replace(/&(?!\w+;)|[<>"']/g, function(a) {
                return e[a] || a
            })
        },
        cacheObject: function(a, e) {
            if (void 0 === e) return b[a];
            b[a] = e
        },
        purify: function(a) {
            if (!(a instanceof Object)) return a;
            var b = {},
                d;
            for (d in a) if (a.hasOwnProperty(d) && !("_bindings" === d || a[d] instanceof HTMLElement)) b[d] = a[d];
            return b
        },
        formatDistance: function(a, b) {
            return "mi" == b ? 161 >= a ? 10 * Math.round(3.281 * a / 10) + "ft" : (160900 > a ? (a / 1609).toFixed(1) : Math.round(a / 1609)) + "mi" : 1E3 > a ? Math.round(a) + "m" : (1E5 > a ? (a / 1E3).toFixed(1) : Math.round(a / 1E3)) + "km"
        },
        formatTime: function(a) {
            var b = Math.round(a / 60);
            return 20 < b && 55 > b ? 5 * Math.ceil(b / 5) + "min" : 55 <= b ? 0.5 * Math.ceil(a / 1800) + "hr" : b + "min"
        },
        formatURLParams: function(a) {
            return Object.keys(a).map(function(b) {
                return encodeURIComponent(b) + "=" + encodeURIComponent(a[b] + "")
            }).join("&")
        },
        uuid4: function() {
            var a = Math.random,
                b = ("0000000" + ((4294967296 * a() & 4294922239 | 16384) >>> 0).toString(16)).slice(-8),
                d = ("0000000" + ((4294967296 * a() & 3221225471 | 2147483648) >>> 0).toString(16)).slice(-8);
            return [("0000000" + (4294967296 * a() >>> 0).toString(16)).slice(-8), b.slice(0, 4), b.slice(4), d.slice(0, 4), d.slice(4) + ("0000000" + (4294967296 * a() >>> 0).toString(16)).slice(-8)].join("-")
        },
        isPlace: function(a) {
            return !(!a.placeId || !a.placeId.match(/([\w\d]{8}-[\w\d]{32})/))
        }
    }
})(this);
nokia.mh5.provide("nokia.mh5.i18n");
nokia.mh5.i18n = function() {
    function g(a, e) {
        if (a in c) return a = c[a], e ? b(a, e) : a
    }
    var a = /\/(combined\.js|mh5\.js|src\/).*$/,
        b = nokia.mh5.utils.formatString,
        c = {},
        e = this,
        i, h;
    [].forEach.call(document.querySelectorAll("script"), function(d) {
        !h && a.test(d.src) && (h = d.src.replace(a, "") + "/lang/")
    });
    Object.defineProperty(g, "language", {
        get: function() {
            return i
        },
        set: function(a) {
            nokia.mh5.i18n_languages[a] || (a = a.substr(0, 2), nokia.mh5.i18n_languages[a] || (a = "en"));
            i = a;
            e.nokia_mh5_i18n = nokia.mh5.i18n_languages[a];
            c = e.nokia_mh5_i18n;
            delete e.nokia_mh5_i18n;
            nokia.mh5.utils.setLocalStorageValue("nokia.mh5.i18n", i)
        }
    });
    g.getIsoLanguage = function() {
        return i.replace(/-/, "_")
    };
    "nokia_mh5_i18n" in e ? (c = e.nokia_mh5_i18n, delete e.nokia_mh5_i18n) : g.language = nokia.mh5.platform.android || nokia.mh5.platform.android_webview ? "en" : nokia.mh5.utils.getLocalStorageValue("nokia.mh5.i18n") || nokia.mh5.platform.language;
    return g
}.call(this);
nokia.mh5.provide("nokia.mh5.jsonp");
nokia.mh5.jsonp = function() {
    var g = 0,
        a = window.document,
        b;
    return function(c, e, i, h) {
        var d = h || "MH5_" + g++,
            j = a.createElement("script"),
            f = function() {
                try {
                    delete window[d]
                } catch (a) {
                    window[d] = null
                }
                j.parentNode.removeChild(j)
            },
            k = setTimeout(function() {
                window[d].call(this, {
                    error: "timeout"
                })
            }, ~~i || 15E3);
        nokia.mh5.event.add(j, "error", function() {
            window[d].call(this, {
                error: "offline"
            })
        });
        b || (b = a.head || a.getElementsByTagName("head")[0] || a.documentElement);
        window[d] = function() {
            f();
            clearTimeout(k);
            e.apply(this, arguments)
        };
        b.insertBefore(j, b.lastChild).src = c + (h ? "" : "=" + d);
        return {
            uri: c,
            timeout: i,
            cancel: function() {
                clearTimeout(k);
                return j && j.parentNode ? (window[d] = f, !0) : !1
            }
        }
    }
}();
nokia.mh5.provide("nokia.mh5.connectors.story.StoryAdapter");
(function() {
    var g = nokia.mh5.i18n,
        a = "",
        b = "initializing";
    nokia.mh5.connectors.story.StoryAdapter = {
        msgList: {
            "000": g("Notification.connectionError"),
            "010": g("Notification.connectionError"),
            "020": g("Notification.serverError"),
            207: g("Notification.serverError"),
            400: g("Notification.serverError"),
            403: g("Notification.connectionError"),
            404: g("Notification.connectionError"),
            412: g("Notification.connectionError"),
            500: g("Notification.serverError")
        },
        createShareLink: function(a) {
            return a.placeId ? "http://here.com/services/place/" + a.placeId : "http://here.com/map=" + a.latitude + "," + a.longitude + ",16/title=" + encodeURIComponent(a.name)
        },
        shortLink: function(a, b) {
            nokia.mh5.jsonp("http://m.here.com/releases/1.8.44/server/ushare/short.php?longUrl=" + encodeURIComponent(a) + "&jsonp", function(a) {
                b(a ? a.shortUrl : "")
            })
        },
        init: function(c) {
            if ("initialized" != b) {
                var e = function(e) {
                        var h = e || {};
                        !e || h.error || !h.sectoken ? (h.success = !1, h.errorMessage = this.msgList["000"]) : (h.success = !! (200 == h.retCode || 403 == h.retCode), h.success ? (a = h.sectoken, b = "initialized") : h.errorMessage = this.msgList[h.retCode + ""]);
                        c(h)
                    }.bind(this);
                nokia.mh5.jsonp("http://m.here.com/releases/1.8.44/server/ushare/auth.php?jsonp", e)
            } else c({
                success: !0
            })
        },
        _getState: function() {
            return b
        },
        getCaptcha: function(c) {
            if ("initialized" == b) {
                var e = function(a) {
                        var b = a || {};
                        if (a.error) b.success = !1, b.errorMessage = this.msgList["000"];
                        else if (b.success = 200 == b.result.retCode, !b.success) b.errorMessage = this.msgList[b.result.retCode + ""];
                        c(b)
                    }.bind(this);
                nokia.mh5.jsonp("http://m.here.com/releases/1.8.44/server/ushare/captcha.php?sectoken=" + a + "&jsonp", e)
            } else c({
                success: !1,
                errorMessage: this.msgList["010"]
            })
        },
        share: function(c, e) {
            e.url = nokia.mh5.connectors.story.StoryAdapter.createShareLink(e.place);
            var i = "";
            if ("initialized" == b) {
                var h;
                h = function(a) {
                    var b = a || {};
                    if (!a || a.error) b.success = !1, b.errorMessage = this.msgList["000"], c(b);
                    else if (b.success = 200 == b.result.retCode, !b.success) b.errorMessage = this.msgList[b.result.retCode + ""];
                    c(b)
                }.bind(this);
                switch (e.targets) {
                case "default@sm":
                    i = "http://m.here.com/releases/1.8.44/server/ushare/share.php?sectoken=" + a + "&version=1.1&captchaId=" + encodeURIComponent(e.captcha.captchaId) + "&captchaVerifyText=" + encodeURIComponent(e.captcha.captchaVerifyText) + "&targets=default@sm&type=" + encodeURIComponent(e.type) + "&msg=" + encodeURIComponent(e.msg) + "&participantSMSPhone=" + encodeURIComponent(e.participantSMSPhone) + "&phoneNumber=&title=" + encodeURIComponent(e.title) + "&url=" + encodeURIComponent(e.url) + (e.place.placeId ? "&shareDataObj=" + this.encodeShareData(e.place) : "");
                    break;
                case "default@vk":
                case "default@fb":
                case "default@tw":
                case "default@gb":
                case "default@me":
                    i = "http://m.here.com/releases/1.8.44/server/ushare/share.php?sectoken=" + a + "&version=1.1&targets=" + e.targets + "&type=" + encodeURIComponent(e.type) + "&title=" + encodeURIComponent(e.title) + "&url=" + encodeURIComponent(e.url) + "&shareDataObj=" + this.encodeShareData(e.place);
                    break;
                default:
                    c({
                        success: !1,
                        errorMessage: this.msgList["020"]
                    })
                }
                nokia.mh5.jsonp(i + "&jsonp", h)
            } else c({
                success: !1,
                errorMessage: this.msgList["010"]
            })
        },
        encodeShareData: function(a) {
            return encodeURIComponent(JSON.stringify(a.placeId ? {
                serviceName: "Nokia Maps",
                serviceURL: "http://here.com",
                descriptions: {
                    shareString1: a.name,
                    shareString2: a.address,
                    shareString3: a.categoryGroup + " / " + a.category,
                    shareString4: "",
                    shareString5: a.phone
                },
                location: {
                    placesId: a.placeId,
                    latitude: "" + a.latitude,
                    longitude: "" + a.longitude,
                    streetName: a.address,
                    houseNumber: "",
                    cityName: "",
                    stateOrProvince: "",
                    postalCode: "",
                    districtName: "",
                    countryCode: "",
                    countryName: ""
                }
            } : {
                serviceName: "Nokia Maps",
                serviceURL: "http://here.com",
                descriptions: {
                    shareString1: a.name
                },
                location: {
                    placesId: "",
                    latitude: "" + a.latitude,
                    longitude: "" + a.longitude,
                    streetName: a.address,
                    houseNumber: "",
                    cityName: "",
                    stateOrProvince: "",
                    postalCode: "",
                    districtName: "",
                    countryCode: "",
                    countryName: ""
                }
            }))
        }
    }
})();
nokia.mh5.provide("nokia.mh5.event");
nokia.mh5.event && nokia.mh5.event.fire ||
function(g) {
    function a(a) {
        var b = a.replace(t, "");
        return function(d, f, e, c) {
            if (!u.call(o, "on" + f) || !1 !== o["on" + f](b, d, f, e, c)) d[a](u.call(z, f) ? z[f] : f, e, c)
        }
    }
    function b(a, b, d, f) {
        a == w ? J(a, b, d, f) : x.push("add", a, b, d, f)
    }
    function c(a, b, d, f) {
        a == w ? F(a, b, d, f) : x.push("remove", a, b, d, f)
    }
    function e(a) {
        g[this](a, h, !0);
        g.documentElement[this](a, h, !0)
    }
    function i(a, b, d, f, e) {
        var c = g.createEvent("Event");
        c.initEvent(u.call(z, b) ? z[b] : b, u.call(d, "bubbles") ? !! d.bubbles : f, u.call(d, "cancelable") ? !! d.cancelable : e);
        c.data = d;
        c.name = b;
        a.dispatchEvent(c);
        return c
    }
    function h(f) {
        var k = (f.touches || [f])[0].target,
            f = /^touch/.test(f.type);
        if (x) {
            if (!f && (/input/i.test(k.nodeName) || nokia.mh5.platform.android)) f = "ontouchend" in g;
            y.forEach(e, s);
            Object.defineProperty(o, "isTouch", {
                value: f
            });
            z = o.isTouch ? {
                down: "touchstart",
                move: "touchmove",
                up: "touchend"
            } : {
                down: "mousedown",
                move: "mousemove",
                up: "mouseup"
            };
            z.press = z.down;
            z.release = z.up;
            H = J;
            B = F;
            D = i;
            d(r);
            k = 0;
            for (f = x.length; k < f; k += 5) if ("string" == typeof x[k]) o[x[k]](x[k + 1], x[k + 2], x[k + 3], x[k + 4]);
            else D(x[k], x[k + 1], x[k + 2], x[k + 3], x[k + 4]);
            a = y = b = c = e = x = null
        }
    }
    function d(a) {
        var b = o.isTouch,
            b = {
                type: l,
                mouse: !b,
                touch: b
            };
        for (r = null; a.length;) a.shift()(b)
    }
    function j(a, b, d) {
        "function" == typeof a.handleEvent ? a.handleEvent(this) : a.call(this.target, this);
        this.stopped && d.splice(0, d.length)
    }
    function f() {
        this.stopped = !0
    }
    function k() {
        this.defaultPrevented = !0
    }
    var m = ["insertedintodocument"],
        n = "__evt__" + Math.random(),
        l = "pointerdetect",
        o = {
            one: function(a, b, d, f) {
                [].concat(b).forEach(function(b) {
                    o.add(a, b, function W(e) {
                        o.remove(a, b, W, f);
                        j.call(e, d)
                    }, f)
                });
                return o
            },
            add: function(a, b, f, e) {
                [].concat(b).forEach(function(b) {
                    if (!a || a === w || a instanceof v) if (b === l) r ? r.push(f) : d([f]);
                    else if (~m.indexOf(b)) o["on" + b]("add", a, b, f, e);
                    else H(a, b, f, !! e);
                    else {
                        var c = a[n] || (a[n] = {}),
                            c = c[b] || (c[b] = []);
                        0 > c.indexOf(f) && c.push(f)
                    }
                });
                return o
            },
            remove: function(a, b, d, f) {
                [].concat(b).forEach(function(b) {
                    if (!a || a === w || a instanceof v) if (b === l) r && (b = r.indexOf(d), ~b && r.splice(b, 1));
                    else if (~m.indexOf(b)) o["on" + b]("remove", a, b, d, f);
                    else B(a, b, d, !! f);
                    else {
                        var e = a[n] || (a[n] = {}),
                            e = e[b] || (e[b] = []),
                            b = e.indexOf(d);~b && e.splice(b, 1)
                    }
                });
                return o
            },
            fire: function(a, b, d, e, c) {
                var h;
                [].concat(b).forEach(function(b) {
                    !a || a === w || a instanceof v ? h = D(a || w, b, d || {}, null == e ? !0 : !! e, null == c ? !0 : !! c) : ((a[n] || {})[b] || []).slice(0).forEach(j, h = {
                        target: a,
                        currentTarget: a,
                        type: b,
                        data: d,
                        stopPropagation: d && d.stopPropagation || f,
                        preventDefault: d && d.preventDefault || k
                    })
                });
                return h
            }
        },
        u = o.hasOwnProperty,
        w = g.defaultView,
        v = w.Node || w.HTMLElement,
        y = "touchstart,touchmove,touchend,mousedown,mousemove,mouseup,mousewheel,DOMMouseScroll".split(","),
        t = "EventListener",
        q = "add" + t,
        s = "remove" + t,
        x = [],
        r = [],
        J = a(q),
        F = a(s),
        H = b,
        B = c,
        D = function(a, b, d, f, e) {
            a == w ? i(a, b, d, f, e) : x.push(a, b, d, f, e)
        },
        z = {};
    y.forEach(e, q);
    Object.defineProperty(nokia.mh5, "event", {
        writable: !1,
        configurable: !1,
        enumerable: !0,
        value: Object.defineProperties(o, {
            add: {
                value: o.add
            },
            remove: {
                value: o.remove
            },
            fire: {
                value: o.fire
            }
        })
    })
}(nokia.mh5.doc);
nokia.mh5.provide("nokia.mh5.dom");
(function(g) {
    function a(a) {
        if (!g.jstestdriver) return a.stopPropagation(), !1
    }
    function b(a) {
        a = i.defaultView.getComputedStyle(a, null);
        return 1E3 * (parseFloat(a.getPropertyValue("-webkit-transition-duration") || a.getPropertyValue("-moz-transition-duration") || a.getPropertyValue("transition-duration")) || 0)
    }
    var c = g.RegExp,
        e = nokia.mh5.doc.body,
        i = g.document;
    i.addEventListener("touchstart", function() {}, !0);
    var h = nokia.mh5.dom = {
        touchStart: "down",
        touchMove: "move",
        touchEnd: "up",
        contains: function(a, b) {
            return a.contains ? a.contains(b) : !! (a.compareDocumentPosition(b) & 16)
        },
        isNativeScrollingSupported: function() {
            return !1
        },
        transformProperty: "" === nokia.mh5.platform.vendorPrefix ? "transform" : nokia.mh5.platform.vendorPrefix + "Transform",
        dimensions: function(a) {
            return "scrollTo" in a && a.document ? (a = a.document.documentElement, {
                width: a.clientWidth,
                height: a.clientHeight
            }) : {
                width: a.offsetWidth,
                height: a.offsetHeight
            }
        },
        addClass: function(a, b) {
            h.hasClass(a, b) || (a.className += (a.className ? " " : "") + b)
        },
        hasClass: function(a, b) {
            return (new c("(?:^|\\s+)" + b + "(?:\\s+|$)", "g")).test(a.className)
        },
        removeClass: function() {
            for (var a = 1, b = arguments.length, f = arguments[0]; a < b; a++) f.className = f.className.replace(new c("(?:^|\\s+)" + arguments[a] + "(\\s+|$)", "g"), "$1").trim()
        },
        addEvent: nokia.mh5.event.add,
        removeEvent: nokia.mh5.event.remove,
        fireEvent: nokia.mh5.event.fire,
        query: function(a, b) {
            return Array.prototype.slice.call((b || i).querySelectorAll(a))
        },
        byId: function(a, b) {
            return (b || i).getElementById(a)
        },
        createHyperlinkHTML: function(a, b) {
            for (var f = "", e = Object.keys(a), c = 0; c < e.length; c++) var h = e[c],
                f = f + (h + "='" + a[h] + "' ");
            a.target || (f += "target='_blank' ");
            return "<a " + (f + 'onclick="if(event._fake) {event.preventDefault();event.stopPropagation();}"') + ">" + (b ? b : "") + "</a>"
        },
        transition: function() {
            var d, c = arguments.length,
                f, k;
            "function" === typeof arguments[c - 1] && (d = arguments[c - 1], c--);
            var h = Array.prototype.slice.call(arguments, 0, c),
                i = function() {
                    f && (clearTimeout(f), f = 0, nokia.mh5.dom.removeEvent(e, "tap", a, !0), nokia.mh5.dom.removeEvent(h[0].node, "webkitTransitionEnd", i, !1), nokia.mh5.dom.removeEvent(h[0].node, "transitionend", i, !1), d && setTimeout(d, 0))
                };
            nokia.mh5.dom.addEvent(e, "tap", a, !0);
            h.forEach(function(a) {
                a.fromTransformClass && nokia.mh5.dom.addClass(a.node, a.fromTransformClass)
            });
            setTimeout(function() {
                h.forEach(function(a) {
                    a.fromTransformClass && nokia.mh5.dom.removeClass(a.node, a.fromTransformClass);
                    nokia.mh5.dom.addClass(a.node, a.transitionClass);
                    nokia.mh5.dom.addClass(a.node, a.toTransformClass)
                });
                k = b(h[0].node) + 2E3;
                f = setTimeout(i, k)
            }, 0);
            nokia.mh5.dom.addEvent(h[0].node, "webkitTransitionEnd", i, !1);
            nokia.mh5.dom.addEvent(h[0].node, "transitionend", i, !1)
        },
        doTransition: function(b) {
            var c = b.node,
                f = b.parentNode || c.parentNode || e,
                k = b.previousNode || !1,
                h = b.type + "Transition";
            b.transition = !0;
            if (!c) return !1;
            h = nokia.mh5.dom[h];
            nokia.mh5.dom.addEvent(e, "tap", a, !0);
            b.isHistory && !b.persistance ? f.insertBefore(c, k) : (k && nokia.mh5.dom.addClass(k, "mh5_transition_center"), "fade" === b.type && nokia.mh5.dom.addClass(b.fadeNode ? b.fadeNode : c, "in" === b.mode ? "mh5_transition_hide" : "mh5_transition_show"), "out" !== b.mode && !b.persistence && f.appendChild(c));
            if (b.onNodeAttached) b.onNodeAttached();
            h(b)
        },
        slideTransition: function(b) {
            var c = b.previousNode,
                f = b.node,
                h = 0,
                g = "mh5_transition_" + (b.isHistory ? "right" : "left"),
                n = "mh5_transition_" + (b.isHistory ? "left" : "right"),
                l;
            b.transition ? (nokia.mh5.dom.removeClass(f, "[A-Za-z0-9_]*transition[A-Za-z0-9_]*"), nokia.mh5.dom.addClass(f, n), setTimeout(function() {
                nokia.mh5.dom.addClass(c, "mh5_transition_slide");
                nokia.mh5.dom.addClass(f, "mh5_transition_slide");
                var a = i.defaultView.getComputedStyle(b.node, null);
                b.duration = 1E3 * (parseFloat(a.getPropertyValue("-webkit-transition-duration") || a.getPropertyValue("-moz-transition-duration") || a.getPropertyValue("transition-duration")) || 0);
                h = setTimeout(l, b.duration + 2E3);
                setTimeout(function() {
                    nokia.mh5.dom.removeClass(f, n);
                    nokia.mh5.dom.removeClass(c, "mh5_transition_center");
                    nokia.mh5.dom.addClass(c, g)
                }, 0)
            }, 0)) : h = setTimeout(l, 1);
            l = function() {
                h && (clearTimeout(h), h = 0, nokia.mh5.dom.removeEvent(e, "tap", a, !0), nokia.mh5.dom.removeEvent(f, "webkitTransitionEnd", l, !1), nokia.mh5.dom.removeEvent(f, "transitionend", l, !1), nokia.mh5.dom.removeClass(c, "mh5_transition_slide"), nokia.mh5.dom.removeClass(f, "mh5_transition_slide"), nokia.mh5.dom.removeClass(c, g), c.parentNode && c.parentNode.removeChild(c), b.callback && b.callback())
            };
            nokia.mh5.dom.addEvent(f, "webkitTransitionEnd", l, !1);
            nokia.mh5.dom.addEvent(f, "transitionend", l, !1)
        },
        fadeTransition: function(b) {
            b.fadeNode = b.fadeNode || b.node;
            if (!b.transition) return !1;
            var c = 0,
                f = b.isHistory,
                h;
            setTimeout(function() {
                nokia.mh5.dom.addClass(b.fadeNode, "mh5_transition_fade");
                var a = i.defaultView.getComputedStyle(b.node, null);
                b.duration = 1E3 * (parseFloat(a.getPropertyValue("-webkit-transition-duration") || a.getPropertyValue("-moz-transition-duration") || a.getPropertyValue("-ms-transition-duration") || a.getPropertyValue("transition-duration")) || 0);
                c = setTimeout(h, b.duration + 2E3);
                f || (nokia.mh5.dom.addClass(b.fadeNode, "mh5_transition_" + ("in" === b.mode ? "show" : "hide")), nokia.mh5.dom.removeClass(b.fadeNode, "mh5_transition_" + ("in" === b.mode ? "hide" : "show")))
            }, 0);
            h = function() {
                c && (clearTimeout(c), c = 0, "out" === b.mode && !b.persistence && b.node.parentNode && b.node.parentNode.removeChild(b.node), nokia.mh5.dom.removeEvent(e, "tap", a, !0), nokia.mh5.dom.removeEvent(b.node, "webkitTransitionEnd", h, !1), nokia.mh5.dom.removeEvent(b.node, "transitionend", h, !1), nokia.mh5.dom.removeEvent(b.node, "tap", h), nokia.mh5.dom.removeClass(b.node, "mh5_transition_fade"), nokia.mh5.dom.removeClass(b.fadeNode, "in" === b.mode ? "mh5_transition_show" : "mh5_transition_hide"), b.callback && b.callback())
            };
            nokia.mh5.dom.addEvent(b.node, "webkitTransitionEnd", h, !1);
            nokia.mh5.dom.addEvent(b.node, "transitionend", h, !1)
        }
    }
})(this);
nokia.mh5.provide("nokia.mh5.history");
(function() {
    var g = [],
        a = nokia.mh5.win.history,
        b = -1;
    nokia.mh5.history = {
        back: function() {
            a.back()
        },
        go: function(b) {
            a.go(b)
        },
        pushState: function(c, e, i) {
            g[++b] = c;
            a.pushState({
                index: b
            }, e, i);
            nokia.mh5.event.fire(nokia.mh5.history, "historypositionchange", {
                state: c,
                position: b,
                historyLength: g.length
            })
        },
        replaceState: function(c, e, i) {
            -1 === b && (b = 0);
            g[b] = c;
            a.replaceState({
                index: b
            }, e, i)
        },
        reset: function() {
            g = [];
            b = -1
        }
    };
    Object.defineProperty(nokia.mh5.history, "length", {
        get: function() {
            return g.length
        }
    });
    Object.defineProperty(nokia.mh5.history, "position", {
        get: function() {
            return b
        }
    });
    nokia.mh5.win.onpopstate = function(c) {
        if (nokia.mh5.history.catchNextOnPopState) {
            nokia.mh5.history.catchNextOnPopState(c.state ? g[c.state.index] : null);
            delete nokia.mh5.history.catchNextOnPopState;
            var e = nokia.mh5.win.onpopstate;
            nokia.mh5.win.onpopstate = function() {
                nokia.mh5.win.onpopstate = e
            };
            a.forward()
        } else if (c.state) {
            var i = c.state.index > b;
            b = c.state.index;
            c = i ? b : b + 1;
            if (g[c])(c = g[c].onPopState) && c(g[b], i), nokia.mh5.event.fire(nokia.mh5.history, "historypositionchange", {
                state: g[b],
                position: b,
                historyLength: g.length
            })
        }
    }
})();
nokia.mh5.provide("nokia.mh5.event.ontap");
(function() {
    function g() {
        nokia.mh5.dom.addClass(this, "mh5_active")
    }
    function a() {
        nokia.mh5.dom.removeClass(this, "mh5_active")
    }
    function b(a) {
        a.stopPropagation();
        a = a.touches[0];
        d = this._tap_ = {
            x: a.screenX,
            y: a.screenY,
            c: !0,
            e: a
        };
        g.call(this)
    }
    function c(a) {
        if ((d = this._tap_) && d.c) a = a.touches[0], d.c = 10 > i(d.x - a.screenX) && 10 > i(d.y - a.screenY)
    }
    function e(b) {
        b.stopPropagation();
        if (d = this._tap_) delete this._tap_, a.call(this), d.c && (this.noPreventDefault || b.preventDefault(), h.fire(this, "tap", d.e))
    }
    var i = Math.abs,
        h = nokia.mh5.event,
        d;
    h.ontap = function(d, f, k, i, n) {
        h.isTouch ? (h[d](f, "down", b, n), h[d](f, "move", c, n), h[d](f, "up", e, n), f[d + "EventListener"]("tap", i, n)) : (h[d](f, "down", g, n), h[d](f, "mouseout", a, n), h[d](f, "up", a, n), h[d](f, "click", i, n))
    }
})();
nokia.mh5.provide("nokia.mh5.event.onviewportchange");
(function(g, a, b, c, e, i, h) {
    function d(a) {
        g.event.fire(a, "viewportchange", this)
    }
    function j(b) {
        e = 0;
        a.forEach(d, b)
    }
    function f(a) {
        clearTimeout(e);
        e = setTimeout(j, g.platform.hideAddressBar.DELAY + 50, a)
    }
    g.win.addEventListener("orientationchange", f, !0);
    g.win.addEventListener("resize", f, !0);
    g.win.addEventListener("focus", f, !0);
    g.event.onviewportchange = function(f, e, d, l, o) {
        i = a.indexOf(e);
        h = b[i] && b[i].indexOf(l);
        0 > i ? (i = a.push(e) - 1, b[i] = [l], c[i] = [h = 0]) : 0 > h && (h = b[i].push(l) - 1, c[i].push(h));
        c[i][h] += "add" == f ? 1 : -1;
        1 > c[i][h] && (c[i].splice(h, 1), b[i].splice(h, 1), b[i].length || a.splice(i, 1));
        e[f + "EventListener"]("viewportchange", l, o)
    }
})(nokia.mh5, [], [], [], 0);
nokia.mh5.provide("nokia.mh5.ui.Control");
nokia.mh5.ui.Control = new nokia.mh5.Class(function() {
    function g(a, b, c, d) {
        if (!a._bindings || !a._bindings[b]) return -1;
        a = a._bindings[b];
        for (b = a.length - 1; 0 <= b; --b) if (a[b].object === c && a[b].property === d) return b;
        return -1
    }
    var a = function(a, b) {
            var c = a.indexOf(b);
            return -1 !== c && c === a.length - b.length
        },
        b = function(a, b, c, d) {
            a._bindings = a._bindings || {};
            a._bindings[b] = a._bindings[b] || [];
            a._bindings[b].push({
                object: c,
                property: d
            });
            var g = Object.getOwnPropertyDescriptor(a, b) || Object.getOwnPropertyDescriptor(a.constructor.prototype, b);
            if (!g || !g.set) {
                var f = a[b];
                Object.defineProperty(a, b, {
                    get: function() {
                        return f
                    },
                    set: function(d) {
                        if (!(f === d && "object" !== typeof f && !Array.isArray(f))) {
                            var c = f;
                            f = d;
                            var h, l;
                            if (a._bindings[b]) for (var o = a._bindings[b].length - 1; 0 <= o; --o) h = a._bindings[b][o].object, l = a._bindings[b][o].property, "function" === typeof l ? l.call(h, d, c) : h[l] = d
                        }
                    }
                })
            }
            "function" === typeof d ? d.call(c, a[b]) : c[d] = a[b]
        },
        c = function(a, b, c, d) {
            a._bindings = a._bindings || {};
            a._bindings[b] = a._bindings[b] || [];
            a._bindings[b].push({
                object: c,
                property: d
            });
            "function" !== nokia.mh5.type(d) && (c[d] = a[b]);
            var g = "change";
            if ((a instanceof HTMLInputElement || a instanceof HTMLTextAreaElement) && "value" === b) g = "keyup";
            nokia.mh5.dom.addEvent(a, g, function() {
                "function" === nokia.mh5.type(d) ? d.call(c, a[b]) : c[d] = a[b]
            })
        };
    return {
        statics: {
            watch: function(a, i, h, d) {
                a instanceof HTMLElement ? c(a, i, h, d) : b(a, i, h, d)
            },
            bindingExists: function(a, b, c, d) {
                return -1 < g(a, b, c, d)
            },
            removeBinding: function(a, b, c, d) {
                c = g(a, b, c, d); - 1 < c && (d = a._bindings[b], d.splice(c, 1), 0 === d.length && delete a._bindings[b])
            }
        },
        constructor: function(a, b) {
            this._attachTouchHandler = this._attachTouchHandler.bind(this);
            nokia.mh5.extend(this, a);
            this.parent = b;
            this.root = nokia.mh5.doc.createElement(this.rootHtmlElementName || "div");
            if (this.secondLevel) this.innerRoot = nokia.mh5.doc.createElement("div"), nokia.mh5.dom.addClass(this.innerRoot, "mh5_InnerRoot"), this.root.appendChild(this.innerRoot);
            (this.hScroll || this.vScroll) && this._setupScrolling();
            if (this.innerHTML) this.getContentRoot().innerHTML = this.innerHTML;
            !this.dontBind && !b && (this.prepareBindings(), this.prepareDidChangeNotifications());
            this.cssClass && 0 < this.cssClass.length && nokia.mh5.dom.addClass(this.root, this.cssClass);
            if (this.id) this.root.id = this.id;
            this.onClick && this._attachTouchHandler();
            if (void 0 === this.visible) this.visible = !0;
            nokia.mh5.each(this.listeners, function(a, b) {
                nokia.mh5.event.add(this, b, a)
            }, this)
        },
        getRootOwnerByClass: function(a) {
            for (var b = this;
            "parent" in b && !(b instanceof a);) b = b.parent;
            return b
        },
        _setupScrolling: function() {
            var a = this,
                b = this.innerRoot ? this.innerRoot : this.root;
            a.scrollContainer = nokia.mh5.doc.createElement("div");
            b.appendChild(a.scrollContainer);
            a.scrollContainer.style.display = "inline-block";
            var c = nokia.mh5.doc.createElement(a.scrollContainerElementName || "div");
            a.scrollContainer.appendChild(c);
            if (nokia.mh5.dom.isNativeScrollingSupported()) a.root.style["overflow-x"] = a.hScroll ? "scroll" : "hidden", a.root.style["overflow-y"] = a.vScroll ? "scroll" : "hidden";
            else {
                var d, g, f, k, m;
                a._scroll = new iScroll(b, {
                    hScroll: a.hScroll,
                    hScrollbar: !1 === a.hScrollbar ? !1 : !0,
                    vScroll: a.vScroll,
                    vScrollbar: !1 === a.vScrollbar ? !1 : !0,
                    hideScrollbar: !0,
                    bounce: !1 === a.bounce ? !1 : !0,
                    scrollbarClass: "mh5_scrollbar" + (a.scrollbarClass ? " " + a.scrollbarClass : ""),
                    onBeforeScrollStart: function(b) {
                        d = b.touches ? b.touches[0] : b;
                        g = d.pageX;
                        f = d.pageY;
                        a._scrolled = !1
                    },
                    onBeforeScrollMove: function(b) {
                        d = b.touches ? b.touches[0] : b;
                        k = Math.abs(d.pageX - g);
                        m = Math.abs(d.pageY - f);
			console.log('here_map a:' + a.vScroll + ', ' + a.hScroll);
			console.log('here_map deltaX:' + k + ', deltaY: ' + m);

			if (!a.vScroll && k > m || !a.hScroll && m > k) {
			    b.preventDefault();
			}
                        a._scrolled = !0
                    },
                    checkDOMChanges: !0
                });
                a._scroll.refresh = a._scroll.refresh.bind(a._scroll)
            }
            a.hScroll && nokia.mh5.dom.addClass(a.scrollContainer, "mh5_hScroll");
            a.vScroll && nokia.mh5.dom.addClass(a.scrollContainer, "mh5_vScroll")
        },
        _attachTouchHandler: function() {
            nokia.mh5.dom.addEvent(this.root, "tap", function(a) {
                if (!this._isScrolled()) this.onClick(a)
            }.bind(this), !1)
        },
        _isScrolled: function() {
            return !this._scrolled || 400 >= (new Date).getTime() - this._scroll.startTime ? !1 : !0
        },
        visibleDidChange: function(a) {
            nokia.mh5.dom[a ? "removeClass" : "addClass"](this.root, "mh5_hidden")
        },
        prepareBindings: function() {
            var b = nokia.mh5.ui.Control,
                c;
            for (c in this) if (a(c, "Binding")) {
                var h = this[c],
                    d = c.slice(0, -7),
                    g = h.split("#"),
                    f = 2 === g.length ? g[0] : null,
                    k = 2 === g.length ? g[1] : g[0],
                    m = null,
                    g = k.split("."),
                    g = g[g.length - 1],
                    k = k.substring(0, k.indexOf("." + g)),
                    m = null,
                    m = "this" === f ? this : f ? nokia.mh5.require(f) : nokia.mh5.win;
                if (!m) throw Error(nokia.mh5.i18n("Error.prepareBindings", {
                    value: h,
                    snmspa: f
                }));
                m = nokia.mh5.resolve(k, m);
                b.watch(m, g, this, d)
            }
        },
        prepareDidChangeNotifications: function() {
            var b = nokia.mh5.ui.Control,
                c, h, d;
            for (d in this) a(d, "DidChange") && (c = this[d], h = d.slice(0, -9), b.watch(this, h, this, c))
        },
        getContentRoot: function() {
            return this.scrollContainer ? this.scrollContainer.children[0] : this.innerRoot ? this.innerRoot : this.root
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.AutoLayout");
nokia.mh5.ui.AutoLayout = new nokia.mh5.Class({
    constructor: function(g) {
        this.setProperties(g)
    },
    setProperties: function(g) {
        nokia.mh5.extend(this, g)
    },
    reset: function() {}
});
nokia.mh5.provide("nokia.mh5.ui.Container");
nokia.mh5.ui.Container = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    var a = nokia.mh5.i18n;
    return {
        constructor: function(b, c) {
            nokia.mh5.extendDeep(this, b);
            for (var e = this.children = this.children || [], i = nokia.mh5.doc.createDocumentFragment(), h, d, j = 0, f = e.length; j < f; j++) if (b = h = this[e[j]]) {
                d = b.control;
                if (!d) throw Error(a("Error.controlProperty"), h);
                this[e[j]] = h = new d(b, this);
                h.root && i.appendChild(h.root)
            }
            e = this.dontBind;
            if (!c) this.dontBind = !0;
            g.constructor.call(this, {}, c);
            this.dontBind = e;
            this.getContentRoot().appendChild(i);
            b = this.layout || {};
            d = b.type || nokia.mh5.ui.AutoLayout;
            this.layout = new d(b);
            this.layout.setProperties({
                container: this
            });
            this.parent || (this.build(), this.dontBind || (this.prepareBindings(), this.prepareDidChangeNotifications()))
        },
        build: function() {
            for (var a, c = 0, e = this.children.length; c < e; c++) a = this.children[c], this[a] && this[a].build && this[a].build()
        },
        prepareDidChangeNotifications: function() {
            for (var a, c = 0, e = this.children.length; c < e; c++) a = this.children[c], (a = this[a]) && a.prepareDidChangeNotifications && !a.dontBind && a.prepareDidChangeNotifications();
            g.constructor.prototype.prepareDidChangeNotifications.call(this)
        },
        prepareBindings: function() {
            for (var a, c = 0, e = this.children.length; c < e; c++) a = this.children[c], (a = this[a]) && a.prepareBindings && !a.dontBind && a.prepareBindings();
            g.constructor.prototype.prepareBindings.call(this)
        },
        add: function(a, c) {
            this.children = this.children.concat(c);
            this[c] = a;
            a.parent = this;
            a.root && this.getContentRoot().appendChild(a.root)
        },
        insertBefore: function(a, c, e) {
            var i = this.children.indexOf(e);
            if (-1 !== i) e = this[e], this.children = this.children.concat([]), this.children.splice(i, 0, c), this[c] = a, a.parent = this, a.root && e.root && this.getContentRoot().insertBefore(a.root, e.root)
        },
        remove: function(a) {
            var c = this.children.indexOf(a);
            if (-1 !== c) {
                var e = this[a];
                delete this[a];
                this.children = this.children.concat([]);
                this.children.splice(c, 1);
                e.root && this.getContentRoot().removeChild(e.root)
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.ColumnLayout");
nokia.mh5.ui.ColumnLayout = new nokia.mh5.Class(nokia.mh5.ui.AutoLayout, function(g) {
    return {
        setProperties: function(a) {
            g.setProperties.call(this, a);
            if (a = this.container) a = a.getContentRoot(), "stretch" === this.align && nokia.mh5.dom.addClass(a, "stretch"), nokia.mh5.dom.addClass(a, "mh5_ColumnLayout")
        },
        reset: function() {
            g.reset.call(this);
            var a = this.container.getContentRoot();
            nokia.mh5.dom.removeClass(a, "mh5_ColumnLayout");
            nokia.mh5.dom.removeClass(a, "stretch")
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.RowLayout");
nokia.mh5.ui.RowLayout = new nokia.mh5.Class(nokia.mh5.ui.AutoLayout, function(g) {
    return {
        setProperties: function(a) {
            g.setProperties.call(this, a);
            if (a = this.container) a = a.getContentRoot(), "stretch" === this.align && nokia.mh5.dom.addClass(a, "stretch"), nokia.mh5.dom.addClass(a, "mh5_RowLayout")
        },
        reset: function() {
            g.reset.call(this);
            var a = this.container.getContentRoot();
            nokia.mh5.dom.removeClass(a, "mh5_RowLayout");
            nokia.mh5.dom.removeClass(a, "stretch")
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.List");
nokia.mh5.ui.List = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    return {
        cssClass: "mh5_List",
        rootHtmlElementName: "ul",
        scrollContainerElementName: "ul",
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        itemClass: new nokia.mh5.Class(nokia.mh5.ui.Control, function(a) {
            return {
                rootHtmlElementName: "li",
                cssClass: "mh5_DefaultListItem",
                constructor: function(b, c) {
                    a.constructor.call(this, b, c);
                    this.update()
                },
                update: function() {
                    var a = "";
                    this.icon && (a += "<img src='" + this.icon + "'></img>");
                    this.text && (a += "<div>" + this.text + "</div>");
                    this.root.innerHTML = a
                }
            }
        }),
        constructor: function(a, b) {
            this.items = [];
            this.renderedItems = [];
            var a = a || {},
                c = a.onClick;
            delete a.onClick;
            if (a.hScroll || a.vScroll) this.rootHtmlElementName = "div";
            g.constructor.call(this, a, b);
            this.onClick = c;
            var e = this.getContentRoot();
            e.noPreventDefault = !! a.noPreventDefault;
            nokia.mh5.dom.addEvent(e, !nokia.mh5.platform.firefox_mobile ? "tap" : "click", function(a) {
                if (!a._fake && e.hasChildNodes()) {
                    var b;
                    b = (a.hasOwnProperty("data") ? a.data : a).target;
                    b = 1 != b.nodeType ? b.parentNode : b;
                    for (var d = 0, c = e.childNodes.length; d < c; d++) if (nokia.mh5.dom.contains(e.children[d], b)) {
                        if (this.onClick) this.onClick(d, e.children[d]);
                        nokia.mh5.event.fire(this, "tap", {
                            originalEvent: a.hasOwnProperty("data") ? a.data : a,
                            index: d,
                            item: this.items[d]
                        });
                        break
                    }
                }
            }.bind(this), !0);
            a.onClick = c
        },
        add: function(a, b, c) {
            if (void 0 === b) b = this.items.length;
            var e = [b, 0],
                i = nokia.mh5.doc.createDocumentFragment(),
                h, d, g = [],
                f = this.getContentRoot();
            Array.isArray(a) || (a = [a]);
            c || (e = e.concat(a), this.items.splice.apply(this.items, e));
            for (c = 0, d = a.length; c < d; c++) h = this._createItem(a[c]), g.push(h), i.appendChild(h.root);
            f.children[b] ? f.insertBefore(i, f.children[b]) : f.appendChild(i);
            e.length = 2;
            e = e.concat(g);
            this.renderedItems.splice.apply(this.renderedItems, e);
            this._scroll && setTimeout(this._scroll.refresh, 0)
        },
        remove: function(a) {
            if (a === this.items) this.items = [];
            else {
                Array.isArray(a) || (a = [a]);
                for (var b, c = a.length, e = 0, i = this.getContentRoot(); e < c; e++) b = this.items.indexOf(a[e]), -1 < b && (this.items.splice(b, 1), this.renderedItems.splice(b, 1), i.removeChild(i.children[b]))
            }
        },
        _createItem: function(a) {
            var b = {},
                c;
            if (this.itemMapping) for (c in this.itemMapping) b[c] = a[this.itemMapping[c]];
            else for (c in a) a.hasOwnProperty(c) && (b[c] = a[c]);
            a = b.itemClass ? new b.itemClass(b, this) : new this.itemClass(b, this);
            a.prepareBindings();
            a.prepareDidChangeNotifications();
            return a
        },
        itemsDidChange: function(a) {
            for (var b = this.getContentRoot(), c = this.renderedItems.length - 1; 0 <= c; c--) b.removeChild(this.renderedItems[c].root);
            this.renderedItems = [];
            this.add(a, 0, !0)
        },
        update: function(a, b) {
            if (a && void 0 != b) {
                var c = this.getContentRoot();
                if (this.items[b]) {
                    var e = this._createItem(a);
                    this.items[b] = a;
                    this.renderedItems[b] = e;
                    c.replaceChild(e.root, c.children[b])
                }
            } else this.itemsDidChange(this.items)
        },
        scrollTo: function(a, b) {
            this._scroll && this._scroll.scrollTo(a, b, 300)
        },
        scrollToElement: function(a) {
            this._scroll && this.renderedItems[a] && this._scroll.scrollToElement(this.renderedItems[a].root, 300)
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Button");
nokia.mh5.ui.Button = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        rootHtmlElementName: "a",
        cssClass: "mh5_Button",
        constructor: function(a, b) {
            a = a || {};
            this._userOnClick = a.onClick;
            delete a.onClick;
            g.constructor.call(this, a, b);
            a.onClick = this._userOnClick;
            this.update()
        },
        onClick: function(a) {
            a && a.stopPropagation();
            if (!this.disabled) {
                var b = this.root;
                this.link ? (b.href = this.link, setTimeout(function() {
                    b.removeAttribute("href")
                }, 1E3)) : a && a.preventDefault();
                this._userOnClick && this._userOnClick.apply(this, arguments)
            }
        },
        textDidChange: function() {
            this.update()
        },
        iconDidChange: function() {
            this.update()
        },
        disabledDidChange: function(a) {
            nokia.mh5.dom[a ? "addClass" : "removeClass"](this.root, "mh5_disabled")
        },
        update: function() {
            var a = this.icon,
                b = this.iconClass,
                c = this.text || "",
                e = this.root,
                i = this.disabled,
                h = "";
            if (this.target) e.target = this.target;
            nokia.mh5.dom[c ? "addClass" : "removeClass"](e, "mh5_textButton");
            nokia.mh5.dom[i ? "addClass" : "removeClass"](e, "mh5_disabled");
            a && (h += "<img src='" + a + "'/>");
            b && (h += "<div class='" + b + "'></div>");
            c && (h += "<div class='mh5_ButtonText'>" + c + "</div>");
            e.innerHTML = h
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Notification");
nokia.mh5.ui.Notification = new nokia.mh5.Class(nokia.mh5.ui.Button, function(g) {
    return {
        statics: {
            TIMEOUT_DEFAULT: 3E3,
            TIMEOUT_INFINITY: 0
        },
        cssClass: "mh5_Notification",
        innerHTML: '<div class="mh5_NotificationText"></div>',
        timeout: 3E3,
        textDidChange: function() {
            this.update()
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.call(this, a);
            if (void 0 !== this._timeoutId) clearTimeout(this._timeoutId), this._timeoutId = void 0;
            if (this.visible && 0 < this.timeout) this._timeoutId = setTimeout(function() {
                this.visible = !1
            }.bind(this), this.timeout)
        },
        update: function() {
            this.root.children[0].innerHTML != this.text && this.visibleDidChange(this.visible);
            this.root.children[0].innerHTML = this.text ? this.text : ""
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Rating");
nokia.mh5.ui.Rating = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        value: 0,
        count: 0,
        cssClass: "mh5_Rating",
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            this.update()
        },
        update: function() {
            var a = "",
                b = 0,
                c = Math.min(5, Math.round(2 * this.value) / 2);
            if (0 === c) this.root.innerHTML = "";
            else {
                for (; ++b <= c;) a += '<div class="star"></div>';
                0 != Math.round(c) - c && (b++, a += '<div class="halfstar"></div>');
                for (; 5 >= b++;) a += '<div class="nostar"></div>';
                0 < this.count && (a += '<div class="count">(' + this.count + ")</div>");
                this.root.innerHTML = a
            }
        },
        countDidChange: function() {
            this.update()
        },
        valueDidChange: function() {
            this.update()
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.PlaceSummary");
nokia.mh5.components.PlaceSummary = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = nokia.mh5.i18n,
        b = nokia.mh5.dom;
    return {
        cssClass: "mh5_PlaceSummary mh5_standardBackgroundColorDark",
        layout: {
            type: nokia.mh5.ui.ColumnLayout
        },
        children: ["details"],
        details: {
            control: nokia.mh5.ui.Container,
            cssClass: "details"
        },
        constructor: function(a) {
            g.constructor.call(this, a);
            this.update()
        },
        update: function(c) {
            var e = "",
                i;
            if (c) {
                c.name && (e += '<h1 class="mh5_name">' + c.name + "</h1>");
                c.categoryTitle && (e += '<h3 class="mh5_category">' + c.categoryTitle + "</h3>");
                c.address && c.address !== c.name && (e += '<h2 class="address">' + c.address.replace(/\n/g, ", ") + "</h2>");
                if (c.ratingValue) {
                    if (!this.ratingComponent) this.ratingComponent = new nokia.mh5.ui.Rating;
                    this.ratingComponent.value = c.ratingValue;
                    this.ratingComponent.count = c.ratingCount;
                    e += this.ratingComponent.root.outerHTML
                }
                c.providerName && (i = a("source") + ": " + c.providerName, e = c.providerUrl ? e + b.createHyperlinkHTML({
                    href: c.providerUrl,
                    "class": "mh5_source mh5_link",
                    target: "_blank"
                }, i) : e + ('<div class="mh5_source">' + i + "</div>"));
                if (this.details) this.details.root.innerHTML = e
            } else this.clear()
        },
        clear: function() {
            this.details.root.innerHTML = ""
        }
    }
});
nokia.mh5.provide("nokia.mh5.connectors.story.StoryListItem");
nokia.mh5.connectors.story.StoryListItem = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        rootHtmlElementName: "li",
        cssClass: "mh5_ListItem",
        constructor: function(a) {
            g.constructor.call(this, a);
            this.update()
        },
        update: function() {
            var a, b;
            a = '<div><div class="mh5_icon"></div>' + ('<div class="name">' + this.text + "</div>");
            a += '<div class="status"></div></div>';
            this.href ? (b = this.root.appendChild(nokia.mh5.doc.createElement("a")), b.href = this.href, b.target = "_blank") : b = this.root;
            b.innerHTML = a
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.TextInput");
nokia.mh5.ui.TextInput = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    var a = function(a) {
            var c = nokia.mh5.doc.createElement("input");
            c.setAttribute("type", a);
            return "text" !== c.type || "datetime" === a
        };
    return {
        cssClass: "mh5_TextInput",
        placeholder: "",
        value: "",
        constructor: function(b, c) {
            var e = nokia.mh5.event.add,
                b = b || {};
            b.clear = void 0 !== b.clear ? b.clear : !0;
            this.innerHTML = "<form  class='mh5_ColumnLayout stretch'><input type='" + (b.type ? a(b.type) ? b.type : "text" : "text") + "' autocomplete='off'>" + (!nokia.mh5.platform.android && b.clear ? "<div class='mh5_TextInputClear mh5_hidden'></div>" : "") + "</form>";
            g.constructor.call(this, b, c);
            var i = this.root.children[0],
                h = i.children[0],
                d = i.children[1];
            this.input = h;
            this.placeholderDidChange();
            if (this.value) h.value = this.value;
            nokia.mh5.ui.Control.watch(this, "placeholder", this, this.placeholderDidChange);
            nokia.mh5.ui.Control.watch(h, "value", this, "value");
            var j = this;
            e(h, "focus", function(a) {
                if (nokia.mh5.platform.android && nokia.mh5.dom.hasClass(nokia.mh5.doc.body, "mh5_hwacc_body")) j._restoreHWAcceleration = !0, nokia.mh5.dom.removeClass(nokia.mh5.doc.body, "mh5_hwacc_body");
                nokia.mh5.platform.ios && nokia.mh5.event.fire(nokia.mh5.win, "hideAddressBar", {}, !0, !0);
                nokia.mh5.dom.addClass(j.root, "focus");
                0 < j.value.length && d && nokia.mh5.dom.removeClass(d, "mh5_hidden");
                if (j.onFocus) j.onFocus(a);
                nokia.mh5.event.fire(j, "focus", a)
            });
            e(h, "blur", function(a) {
                if (j._restoreHWAcceleration) nokia.mh5.dom.addClass(nokia.mh5.doc.body, "mh5_hwacc_body"), j._restoreHWAcceleration = !1;
                nokia.mh5.dom.removeClass(j.root, "focus");
                d && nokia.mh5.dom.addClass(d, "mh5_hidden");
                if (j.onBlur) j.onBlur(a);
                nokia.mh5.event.fire(j, "blur", a)
            });
            d && nokia.mh5.dom.addEvent(d, "down", function(a) {
                a.stopPropagation();
                a.preventDefault();
                j.value = "";
                h.value = ""
            }, !0);
            e(i, "submit", function(a) {
                j.value = h.value;
                h.blur();
                a.preventDefault();
                a.stopPropagation();
                nokia.mh5.event.fire(this, "submit", a);
                return !1
            }.bind(this), !0)
        },
        isFocused: function() {
            return nokia.mh5.dom.hasClass(this.root, "focus")
        },
        blur: function() {
            this.root.children[0].children[0].blur()
        },
        focus: function() {
            this.root.children[0].children[0].focus()
        },
        valueDidChange: function() {
            var a = this.root.children[0].children[1],
                c = this.root.children[0].children[0];
            if (c.value !== this.value) c.value = this.value || "";
            if (a && this.isFocused()) nokia.mh5.dom[0 < this.value.length ? "removeClass" : "addClass"](a, "mh5_hidden")
        },
        placeholderDidChange: function(a) {
            if (a && this.input && "placeholder" in this.input) this.input.placeholder = a
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.TextArea");
nokia.mh5.ui.TextArea = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        cssClass: "mh5_ColumnLayout stretch",
        rootHtmlElementName: "div",
        constructor: function(a, b) {
            this.innerHTML = '<textarea class="mh5_TextArea"></textarea>';
            g.constructor.call(this, a, b);
            var c = this.root.children[0],
                e = this;
            nokia.mh5.ui.Control.watch(c, "value", this, "value");
            nokia.mh5.dom.addEvent(c, "focus", function(a) {
                if (nokia.mh5.platform.android && nokia.mh5.dom.hasClass(nokia.mh5.doc.body, "mh5_hwacc_body")) e._restoreHWAcceleration = !0, nokia.mh5.dom.removeClass(nokia.mh5.doc.body, "mh5_hwacc_body");
                nokia.mh5.event.fire(e, "focus", a)
            });
            nokia.mh5.dom.addEvent(c, "blur", function(a) {
                if (e._restoreHWAcceleration) nokia.mh5.dom.addClass(nokia.mh5.doc.body, "mh5_hwacc_body"), e._restoreHWAcceleration = !1;
                nokia.mh5.event.fire(e, "blur", a)
            });
            if (this.placeholder && "placeholder" in c) c.placeholder = this.placeholder;
            this.rows && (c.rows = this.rows);
            this.maxlength && (c.maxLength = this.maxlength)
        },
        valueDidChange: function(a) {
            var b = this.root.children[0];
            if (a !== b.value) b.value = a || ""
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Page");
nokia.mh5.ui.Page = new nokia.mh5.Class(nokia.mh5.ui.Container, function() {
    return {
        cssClass: "mh5_Page",
        visible: !1,
        model: null,
        secondLevel: !0,
        getHash: function() {
            return "{}"
        },
        getNavigationState: function() {
            return this.model ? nokia.mh5.utils.purify(this.model) : {}
        },
        intoView: function(g) {
            var a = nokia.mh5.dom.query(g)[0];
            a && setTimeout(function() {
                window.scroll && window.scroll(0, a.offsetTop)
            }, 1E3)
        },
        setModel: function(g) {
            this.model = g
        }
    }
});
nokia.mh5.provide("nokia.mh5.connectors.story.BasePlugin");
nokia.mh5.connectors.story.BasePlugin = new nokia.mh5.Class(nokia.mh5.ui.Page, function(g) {
    return {
        constructor: function(a, b) {
            g.constructor.call(this);
            this.story = b;
            this.prevView = a;
            this.callSequenceIndex = -1;
            this.callSequence = [];
            this.genericCB = this.genericCB.bind(this)
        },
        showView: function(a) {
            this.originOnpopstate = nokia.mh5.win.onpopstate;
            nokia.mh5.win.onpopstate = function() {
                this.hideView(a)
            }.bind(this);
            this.prevView.parentElement.replaceChild(a, this.prevView)
        },
        hideView: function(a) {
            nokia.mh5.win.onpopstate = this.originOnpopstate;
            nokia.mh5.win.history.forward();
            this.root.parentNode && a.parentElement.replaceChild(this.prevView, a)
        },
        _nextStep: function(a) {
            this.callSequenceIndex += a || 1;
            if (this.callSequenceIndex < this.callSequence.length) if (a = this.callSequence[this.callSequenceIndex], "adapter" == a.target) nokia.mh5.connectors.story.StoryAdapter[a.asyncMethod](this.genericCB, a.arg);
            else {
                if ("plugin" == a.target) this[a.asyncMethod](this.genericCB, a.arg)
            } else this.callback({
                success: !0
            })
        },
        genericCB: function(a) {
            this.callSequence[this.callSequenceIndex].cb.call(this, a)
        },
        processSequence: function() {
            this.callSequence && this.callSequenceIndex && this.callback && this._nextStep()
        }
    }
});
nokia.mh5.provide("nokia.mh5.connectors.story.SmsPlugin");
nokia.mh5.connectors.story.SmsPlugin = new nokia.mh5.Class(nokia.mh5.connectors.story.BasePlugin, function(g) {
    var a = nokia.mh5.i18n;
    return {
        cssClass: "mh5_smsShare",
        children: "header,notification,phoneNumberLabel,phoneNumberLabel_error,phoneNumberInput,messageLabel,messageInput,securityCodeLabel,securityCodeLabel_error,image,text,actions".split(","),
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        header: {
            control: nokia.mh5.ui.Container,
            rootHtmlElementName: "header",
            cssClass: "mh5_header mh5_standardBackgroundColorDark",
            children: ["headline", "placeSummary"],
            headline: {
                control: nokia.mh5.ui.Control,
                rootHtmlElementName: "h1",
                cssClass: "mh5_headline",
                innerHTML: a("shareVia") + " " + a("sms")
            },
            placeSummary: {
                control: nokia.mh5.components.PlaceSummary
            }
        },
        notification: {
            control: nokia.mh5.ui.Notification,
            visible: !1
        },
        phoneNumberLabel: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_Label",
            rootHtmlElementName: "label",
            innerHTML: a("SMS.plsEnterNum")
        },
        phoneNumberLabel_error: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_Label error",
            visible: !1,
            rootHtmlElementName: "label",
            innerHTML: a("SMS.plsCheckNum")
        },
        phoneNumberInput: {
            control: nokia.mh5.ui.TextInput,
            type: a("tel"),
            clear: !1,
            value: "+"
        },
        messageLabel: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_Label",
            rootHtmlElementName: "label",
            innerHTML: a("SMS.alsoShort")
        },
        messageInput: {
            control: nokia.mh5.ui.TextArea,
            rows: 3,
            maxlength: 140,
            placeholder: a("messageHere") + "..."
        },
        securityCodeLabel: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_Label",
            rootHtmlElementName: "label",
            innerHTML: a("SMS.enterCaptcha")
        },
        securityCodeLabel_error: {
            control: nokia.mh5.ui.Control,
            rootHtmlElementName: "label",
            cssClass: "mh5_Label error",
            innerHTML: a("SMS.wrongCaptcha"),
            visible: !1
        },
        image: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_captchaImage",
            srcDidChange: function(a) {
                this.root.style.backgroundImage = "url(" + a + ")"
            }
        },
        text: {
            control: nokia.mh5.ui.TextInput,
            clear: !1,
            placeholder: a("SMS.enterCode") + "...",
            valueDidChange: function(a) {
                if (0 === a.length) this.parent.actions.submitButton.disabled = !0;
                else if (this.parent.actions.submitButton.disabled) this.parent.actions.submitButton.disabled = !1
            }
        },
        actions: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_right",
            children: ["cancelButton", "submitButton"],
            cancelButton: {
                control: nokia.mh5.ui.Button,
                cssClass: "mh5_Button mh5_textButton",
                text: a("cancel"),
                build: function() {
                    this.root.addEventListener("touchstart", function(a) {
                        a.stopPropagation();
                        a.preventDefault()
                    })
                },
                onClick: nokia.mh5.history.back
            },
            submitButton: {
                control: nokia.mh5.ui.Button,
                cssClass: "mh5_Button mh5_textButton",
                disabled: !0,
                text: a("submit")
            }
        },
        constructor: function(a, c) {
            g.constructor.call(this, a, c);
            this.header.placeSummary.update(this.story.data);
            this.actions.submitButton.update();
            this.callSequence = [{
                target: "adapter",
                asyncMethod: "getCaptcha",
                cb: this._getCaptchaCallback,
                arg: null
            }, {
                target: "plugin",
                asyncMethod: "_displayForm",
                cb: this._displayFormCallback,
                arg: {}
            }, {
                target: "adapter",
                asyncMethod: "share",
                cb: this._shareCallback,
                arg: {}
            }];
            this.metadata = {}
        },
        performShare: function(b) {
            this.callback = function(c) {
                this.actions.submitButton.disabled = !1;
                c.success ? (this.notification.text = a("SMS.sentSuccessfully"), this.notification.timeout = nokia.mh5.ui.Notification.TIMEOUT_DEFAULT, this.notification.visible = !0, nokia.mh5.win.scrollTo(0, 0), setTimeout(function() {
                    this.notification.visible = !1;
                    this.hideView(this.root);
                    b(c)
                }.bind(this), nokia.mh5.ui.Notification.TIMEOUT_DEFAULT)) : b(c)
            }.bind(this);
            this.processSequence()
        },
        _getCaptchaCallback: function(b) {
            if (b.success && b.result) this.metadata.captcha = b.result.captcha, this.callSequence[1].arg.url = this.metadata.captcha.captchaUrl, this.callSequence[1].arg.captchaWidth = this.metadata.captcha.captchaWidth, this.callSequence[1].arg.captchaHeight = this.metadata.captcha.captchaHeight, this._nextStep();
            else {
                var c = a("Notification.connectionError");
                this.root.parentNode ? (this.notification.text = c, this.notification.timeout = nokia.mh5.ui.Notification.TIMEOUT_DEFAULT, this.notification.visible = !0, nokia.mh5.win.scrollTo(0, 0)) : (b.errorMessage = c, this.callback(b))
            }
        },
        _shareCallback: function(b) {
            this.notification.visible = !1;
            b.success ? this._nextStep() : b.result && 409 === b.result.targets[0].retCode ? (this.securityCodeLabel_error.visible = !0, this.text.value = "", this.text.root.children[0].children[0].focus(), this._nextStep(-2)) : b.result && 400 === b.result.targets[0].retCode ? (this.phoneNumberLabel_error.visible = !0, this._nextStep(-2)) : (this.notification.text = a("SMS.unableToSend"), this.notification.timeout = nokia.mh5.ui.Notification.TIMEOUT_DEFAULT, this.notification.visible = !0, nokia.mh5.win.scrollTo(0, 0), this._nextStep(-1))
        },
        _displayForm: function(a, c) {
            this.image.src = c.url;
            this.image.root.style.width = (c.captchaWidth || 200) + "px";
            this.image.root.style.height = (c.captchaHeight || 50) + "px";
            this.actions.submitButton.disabled = !this._formInitialized;
            if (!this._formInitialized) this._formInitialized = !0, this._initializeFormControls(a, c)
        },
        _initializeFormControls: function(b) {
            var c = this;
            this.actions.submitButton.onClick = function() {
                var e = {
                    success: !0,
                    placeTitle: this.story.data.name,
                    phoneNumber: c.phoneNumberInput.value.replace(/[^+0-9]/gi, ""),
                    message: c.messageInput.value,
                    captchaVerifyText: this.text.value
                };
                this.phoneNumberLabel_error.visible = !1;
                this.securityCodeLabel_error.visible = !1;
                this.notification.text = a("sending");
                this.notification.timeout = nokia.mh5.ui.Notification.TIMEOUT_INFINITY;
                this.notification.visible = !0;
                this.actions.submitButton.disabled = !0;
                nokia.mh5.win.scrollTo(0, 0);
                b(e)
            }.bind(this);
            this.showView(this.root)
        },
        _displayFormCallback: function(a) {
            this.metadata.captcha.captchaVerifyText = a.captchaVerifyText;
            this.metadata.participantSMSPhone = a.phoneNumber;
            this.metadata.msg = a.message;
            this.metadata.title = a.placeTitle;
            this.metadata.place = this.story.data;
            this.metadata.targets = "default@sm";
            this.metadata.type = "place";
            this.callSequence[2].arg = this.metadata;
            a.success ? this._nextStep() : this.callback(a)
        },
        visibleDidChange: function(a) {
            if (!a) this.notification.visible = !1
        }
    }
});
nokia.mh5.provide("nokia.mh5.connectors.story.EmailPlugin");
nokia.mh5.connectors.story.EmailPlugin = new nokia.mh5.Class(nokia.mh5.ui.Page, function() {
    var g = nokia.mh5.i18n;
    return {
        constructor: function(a, b) {
            this.story = b
        },
        performShare: function(a) {
            var b = this.story.data,
                c = (b.name + "").replace(/\s+/g, " "),
                e = nokia.mh5.connectors.story.StoryAdapter.createShareLink(b),
                i;
            nokia.mh5.connectors.story.StoryAdapter.shortLink(e, function(e) {
                if (e) i = g("EP.idLikeTo") + ": " + e + "\n\n" + (b.placeId ? b.name + "\n" : "") + b.address, i = i.replace(/\r/g, ""), nokia.mh5.win.location.href = "mailto:?subject=" + encodeURIComponent(c) + "&body=" + encodeURIComponent(i);
                setTimeout(function() {
                    a({
                        success: !! e
                    })
                }, 500)
            })
        }
    }
});
nokia.mh5.provide("nokia.mh5.connectors.story.StoryCreator");
nokia.mh5.connectors.story.StoryCreator = new nokia.mh5.Class(nokia.mh5.ui.Container, function() {
    var g = nokia.mh5.i18n,
        a = g("Notification.connectionError"),
        b = [{
            name: "facebookCreator",
            text: "Facebook",
            cssClass: "mh5_ListItem mh5_share Facebook",
            symbol: "fb"
        }, {
            name: "twitterCreator",
            text: "Twitter",
            cssClass: "mh5_ListItem mh5_share Twitter",
            symbol: "tw"
        }, {
            name: "emailCreator",
            klass: nokia.mh5.connectors.story.EmailPlugin,
            text: g("email"),
            cssClass: "mh5_ListItem mh5_share Email"
        }, {
            name: "smsCreator",
            klass: nokia.mh5.connectors.story.SmsPlugin,
            text: g("sms"),
            cssClass: "mh5_ListItem mh5_share SMS"
        }, {
            name: "gbookmarkCreator",
            text: "Google Bookmarks",
            cssClass: "mh5_ListItem mh5_share GBookmark",
            symbol: "gb"
        }, {
            name: "meneameCreator",
            text: "Meneame",
            cssClass: "mh5_ListItem mh5_share Meneame",
            symbol: "me"
        }, {
            name: "vKontakteCreator",
            text: "VKontakte",
            cssClass: "mh5_ListItem mh5_share VKontakte",
            symbol: "vk"
        }];
    return {
        cssClass: "mh5_StoryCreator",
        children: ["header", "notification", "container"],
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        header: {
            control: nokia.mh5.ui.Container,
            layout: {
                type: nokia.mh5.ui.ColumnLayout
            },
            rootHtmlElementName: "header",
            cssClass: "mh5_header mh5_standardBackgroundColorDark",
            children: ["backButton", "headerData"],
            backButton: {
                control: nokia.mh5.ui.Button,
                cssClass: "mh5_Button mh5_back",
                build: function() {
                    this.root.addEventListener("touchstart", function(a) {
                        a.stopPropagation();
                        a.preventDefault()
                    })
                },
                onClick: nokia.mh5.history.back
            },
            headerData: {
                control: nokia.mh5.ui.Container,
                layout: {
                    type: nokia.mh5.ui.RowLayout
                },
                children: ["headline", "placeSummary"],
                headline: {
                    control: nokia.mh5.ui.Control,
                    rootHtmlElementName: "h1",
                    cssClass: "mh5_headline",
                    innerHTML: g("shareAPlace")
                },
                placeSummary: {
                    control: nokia.mh5.components.PlaceSummary
                }
            }
        },
        notification: {
            control: nokia.mh5.ui.Notification,
            visible: !1
        },
        container: {
            control: nokia.mh5.ui.List,
            itemClass: nokia.mh5.connectors.story.StoryListItem,
            items: b,
            onClick: function(a) {
                this.parent.launchShare(a, this.root.children[a])
            },
            noPreventDefault: !0
        },
        visibleDidChange: function(a) {
            if (!a) this.notification.visible = !1
        },
        launchShare: function(c, e) {
            function i(b) {
                d._hideSpinner(e);
                !b || b.success ? nokia.mh5.app.controller.back() : (d.notification.text = b.errorMessage || a, d.notification.visible = !0)
            }
            var h = b[c],
                d = this;
            this._showSpinner(e);
            "emailCreator" === h.name ? (new h.klass(this.root, this.story)).performShare(i) : "smsCreator" === h.name ? nokia.mh5.platform.ios_webview && nokia.mh5.platform.iphone ? window.shareNative(this.story, i) : nokia.mh5.connectors.story.StoryAdapter.init(function(a) {
                d._hideSpinner(e);
                a.success ? (new h.klass(d.root, d.story)).performShare(i) : i(a)
            }) : setTimeout(i, 100)
        },
        _showSpinner: function(a) {
            a && nokia.mh5.dom.addClass(a, "loading")
        },
        _hideSpinner: function(a) {
            a && nokia.mh5.dom.removeClass(a, "loading")
        },
        update: function(a) {
            var e, i;
            this.story = a;
            e = a.data.name;
            a = a.data;
            i = nokia.mh5.connectors.story.StoryAdapter.createShareLink(a);
            this.header.headerData.placeSummary.update(a);
            for (var h = 0; h < b.length; h++) {
                var d = b[h];
                if (void 0 !== d.symbol) d.href = "http://m.here.com/releases/1.8.44/server/ushare/ushare.php?sectoken=&version=1.1&targets=default@" + d.symbol + "&type=" + encodeURIComponent("place") + "&title=" + encodeURIComponent(e) + "&url=" + encodeURIComponent(i) + "&shareDataObj=" + nokia.mh5.connectors.story.StoryAdapter.encodeShareData(a)
            }
            this.container.items = b
        }
    }
});
nokia.mh5.provide("nokia.mh5.l10n");
nokia.mh5.l10n = {
    imperial: {
        us: 1,
        gb: 1,
        lr: 1,
        mm: 1
    },
    tileLanguageMap: {
        ar: "ARA",
        zh: "CHI",
        es: "SPA",
        fr: "FRE",
        it: "ITA",
        de: "GER",
        ru: "RUS"
    }
};
nokia.mh5.provide("nokia.mh5.components.settings");
(function() {
    var g = nokia.mh5.utils,
        a = {
            mapSchema: "normal.day",
            cartoPois: !1,
            unitSystem: "km",
            analyticsEnabled: !0,
            trafficIncidentsEnabled: !1,
            trafficAccidentsEnabled: !0,
            trafficCongestionsEnabled: !0,
            trafficConstructionsEnabled: !0,
            trafficOthersEnabled: !0,
            retinaTiles: !1
        },
        b = JSON.parse(g.getLocalStorageValue("settings") || "{}");
    nokia.mh5.components.settings = {
        current: g.getLocalStorageValue("settings") ?
        function() {
            for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
            return a
        }() : a,
        get: function(a) {
            return nokia.mh5.components.settings.current[a]
        },
        set: function(a, e) {
            b[a] = e;
            g.setLocalStorageValue("settings", JSON.stringify(b));
            nokia.mh5.components.settings.current[a] = e
        }
    };
    "userId" in b || nokia.mh5.components.settings.set("userId", g.uuid4())
})();
nokia.mh5.provide("nokia.mh5.components.Traffic");
(function() {
    var g = {
        Accidents: "Accident",
        Constructions: "Construction",
        Congestions: "Congestion",
        Others: "DisabledVehicle,RoadHazard,MassTransit,OtherNews,Weather,Misc,PlannedEvent"
    },
        a = function(a) {
            return this == "routeInfo" in a.data
        },
        b = function(a) {
            return a.data.incident
        },
        c = "http://traffic.nlp.nokia.com/traffic/6.0/",
        e = nokia.mh5.event,
        i = nokia.mh5.i18n,
        h = nokia.mh5.components.settings,
        d = nokia.mh5.utils;
    nokia.mh5.components.Traffic = new nokia.mh5.Class(nokia.mh5.ui.Container, function(j) {
        function f(a, b) {
            return a.location.latitude - b.location.latitude || a.location.longitude - b.location.longitude
        }
        function k(a, b) {
            return a.incident.criticality - b.incident.criticality || b.incident.id - a.incident.id
        }
        function m(a, b) {
            return nokia.mh5.assetsPath + "img/mapsymbols/tmc_" + a + "_" + b + "_pole.png"
        }
        function n(a) {
            var b = [];
            if (0 < a.length) {
                b.push(a[0]);
                for (var d = 1; d < a.length; ++d) {
                    var c = b[b.length - 1],
                        e = a[d];
                    0 === f(c, e) ? b[b.length - 1] = 0 < k(c, e) ? e : c : b.push(e)
                }
            }
            return b
        }
        function l(a) {
            var b = 60 * (60 * (24 * a.getDay() + a.getHours()) + a.getMinutes()) + a.getSeconds();
            return function(a, f, e, h) {
                a = c + "tiles/" + h + "/" + a + "/" + f + "/256/png32";
                f = {
                    app_id: nokia.mh5.appId,
                    token: nokia.mh5.appCode
                };
                f.pattern_time = b;
                return a + "?" + d.formatURLParams(f)
            }
        }
        function o(a) {
            return a.TYPE && a.content && a.TYPE == this
        }
        function u(a) {
            var b, f, d, c, e;
            if (a.LOCATION && a.LOCATION.GEOLOC && a.LOCATION.GEOLOC.ORIGIN) {
                c = a.LOCATION.GEOLOC.ORIGIN;
                f = {
                    id: "" + a.TRAFFICITEMID,
                    startTime: new Date(Date.parse(a.STARTTIME)),
                    endTime: new Date(Date.parse(a.ENDTIME))
                };
                b = {
                    location: {
                        latitude: c.LATITUDE,
                        longitude: c.LONGITUDE
                    }
                };
                d = "high";
                if (a.CRITICALITY && a.CRITICALITY.ID) f.criticality = a.CRITICALITY.ID | 0, "0" === a.CRITICALITY.ID ? d = "blocking" : "1" === a.CRITICALITY.ID && (d = "veryhigh");
                switch (a.TRAFFICITEMTYPEDESC) {
                case "CONSTRUCTION":
                    b.icon = m(d, "roadworks");
                    break;
                case "ACCIDENT":
                    b.icon = m(d, "accident");
                    break;
                case "CONGESTION":
                    b.icon = m(d, "congestion");
                    break;
                default:
                    b.icon = m(d, "other")
                }
                if (a.TRAFFICITEMDETAIL && a.TRAFFICITEMDETAIL.ROADCLOSED) f.criticality = 0, b.icon = m("blocking", "closure");
                f.type = a.TRAFFICITEMTYPEDESC[0].toUpperCase() + a.TRAFFICITEMTYPEDESC.slice(1).toLowerCase();
                if (a.LOCATION.DEFINED && a.LOCATION.DEFINED.ORIGIN) {
                    c = a.LOCATION.DEFINED.ORIGIN;
                    e = c.POINT.DESCRIPTION;
                    d = c.DIRECTION.DESCRIPTION;
                    if (e) c = e.filter(o, "LOCAL")[0], f.origin = c && c.content;
                    if (d) c = d.filter(o, "LOCAL")[0], f.direction = c && c.content
                } else if (a.LOCATION.INTERSECTION && a.LOCATION.INTERSECTION.ORIGIN) c = a.LOCATION.INTERSECTION.ORIGIN, e = a.LOCATION.INTERSECTION.TO, f.origin = c.STREET1 && c.STREET1.ADDRESS1, f.start = c.STREET2 && c.STREET2.ADDRESS1, f.end = e && e.STREET2 && e.STREET2.ADDRESS1;
                if (a.RDSTMCLOCATIONS && a.RDSTMCLOCATIONS.RDSTMC && 0 < a.RDSTMCLOCATIONS.RDSTMC.length) {
                    d = a.RDSTMCLOCATIONS.RDSTMC;
                    e = d[0];
                    var h = 1;
                    for (c = e.ALERTC; h < d.length;) {
                        if (d[h].DIRECTION && d[h].DIRECTION !== e.DIRECTION) {
                            f.bidirectional = !0;
                            break
                        }
                        h += 1
                    }
                    f.start = e.ORIGIN && e.ORIGIN.LOCATIONDESC;
                    f.end = e.TO && e.TO.LOCATIONDESC;
                    f.description = c && c.DESCRIPTION && c.DESCRIPTION.replace(/\s*\(Q\)\s*/g, " ").replace(/\s*\(([^\/]*)\/\/[^\)]*\)\s*/g, " $1 ").replace(/\s*--\s*/, " ").replace(/^\s*/, "").replace(/\s*$/, "")
                }
                c = a.TRAFFICITEMDESCRIPTION && a.TRAFFICITEMDESCRIPTION.filter(o, "desc")[0];
                f.description = f.description || c && c.content;
                b.incident = f
            }
            return b
        }
        return {
            _map: null,
            _mapReady: !1,
            _currentRequest: null,
            displayIncidents: !1,
            statics: {
                getTrafficTypes: function() {
                    return Object.keys(g)
                },
                removeNonTrafficPois: function(a) {
                    var b = a.getPois();
                    a.removePoi(b.filter(function(a) {
                        return !a.data.incident
                    }))
                }
            },
            _clearIncidentsFromMap: function() {
                this._map.removePoi(this._map.getPois().filter(function(a) {
                    return a.data.incident && !a.originalImage
                }))
            },
            _resetPois: function(a) {
                this._clearIncidentsFromMap();
                for (var f = this._map.infoBubbles.filter(b)[0], d = 0, c = a.length; d < c; d++) if (!f || !(a[d].location.latitude == f.data.latitude && a[d].location.longitude == f.data.longitude)) {
                    var e = this._map.createPoi(a[d].icon, a[d].location),
                        h = a[d].incident,
                        k = h.origin,
                        l = h.direction;
                    e.retina = !0;
                    e.data.name = i("maps.Traffic." + h.type.replace(/\s/g, "")) || i("maps.Traffic.Othernews");
                    if (k) e.data.description = i("maps.Traffic.incidentDescription" + (l ? "" : "NoDirection"), {
                        origin: k,
                        direction: l
                    });
                    e.data.icon = a[d].icon;
                    e.data.incident = h
                }
            },
            _processIncidentsResponse: function(a) {
                var b = [],
                    d = this._timeTravelDate || new Date;
                a.TRAFFICITEMS && a.TRAFFICITEMS.TRAFFICITEM && (b = a.TRAFFICITEMS.TRAFFICITEM.map(u).filter(function(a) {
                    return a && a.incident.startTime <= d && a.incident.endTime >= d
                }));
                b.sort(f);
                b = n(b);
                b.sort(k);
                40 < b.length && b.splice(39, b.length - 40);
                this._currentRequest = null;
                this._incidentPois = b;
                this._resetPois(b)
            },
            _types: function(a) {
                return g[a]
            },
            _getType: function() {
                var a = [],
                    b = this;
                nokia.mh5.each(nokia.mh5.components.Traffic.getTrafficTypes(), function(f) {
                    h.get("traffic" + f + "Enabled") && a.push(b._types(f))
                });
                return a.join(",")
            },
            _reloadIncidents: function(a, b) {
                if ("undefined" !== typeof a && "undefined" !== typeof b && "undefined" !== typeof b[0] && !isNaN(b[0].latitude)) {
                    var f = this._map.geoToPoint(this._map.center),
                        e = this._getType(),
                        k = h.get("trafficIncidentsEnabled"),
                        l = this;
                    f.x = f.x / 256 | 0;
                    f.y = f.y / 256 | 0;
                    if (this.displayIncidents && e && k && 8 < a) {
                        var i = c + "incidents.json?" + d.formatURLParams({
                            app_id: nokia.mh5.appId,
                            token: nokia.mh5.appCode,
                            bbox: b[0].latitude + "," + b[0].longitude + ";" + b[1].latitude + "," + b[1].longitude,
                            status: "active",
                            type: e,
                            criticality: "critical,major,minor"
                        }) + "&jsoncallback";
                        if (i + l._timeTravelDate !== l._incidentsUri) {
                            if (l._currentRequest) l._currentRequest.cancel(), l._currentRequest = null;
                            l._timeoutId && nokia.mh5.win.clearTimeout(l._timeoutId);
                            l._timeoutId = nokia.mh5.win.setTimeout(function() {
                                delete l._timeoutId;
                                e = l._getType();
                                if (l.displayIncidents && e) l._currentRequest = nokia.mh5.jsonp(i, l._processIncidentsResponse)
                            }, 1E3);
                            l._incidentsUri = i + l._timeTravelDate
                        } else l._resetPois(l._incidentPois)
                    } else l._clearIncidentsFromMap()
                }
            },
            _showInfoBubble: function(b) {
                var f = {
                    content: ["title", "description"],
                    left: b.data.icon,
                    listeners: this._map.infoBubbleParams && this._map.infoBubbleParams.listeners
                };
                this._map.hideInfoBubble(this._map.infoBubbles.filter(a, !1));
                this._map.showInfoBubble(b, f)
            },
            constructor: function(a, b) {
                this._onReady = this._onReady.bind(this);
                this._onZoom = this._onZoom.bind(this);
                this._onMove = this._onMove.bind(this);
                this._onPoiClick = this._onPoiClick.bind(this);
                this._processIncidentsResponse = this._processIncidentsResponse.bind(this);
                this._incidentPois = [];
                Object.defineProperty(this, "map", {
                    get: function() {
                        return this._map
                    },
                    set: function(a) {
                        this._map && (e.remove(this._map, "ready", this._onReady), e.remove(this._map._map, "mapzoomchange", this._onZoom), e.remove(this._map._map, "mapmoveend", this._onMove), e.remove(this._map._map, "poiclick", this._onPoiClick));
                        if (this._map = a) e.add(this._map, "ready", this._onReady), e.add(this._map._map, "mapzoomchange", this._onZoom), e.add(this._map._map, "mapmoveend", this._onMove), e.add(this._map._map, "poiclick", this._onPoiClick)
                    }
                });
                j.constructor.call(this, a, b)
            },
            mapSchemaBinding: "nokia.mh5.components.settings#current.mapSchema",
            mapSchemaDidChange: function(a) {
                if (a && "normal.day.traffic" == a) {
                    var a = nokia.mh5.app.controller.current,
                        b = this._map,
                        f;
                    if (a && a.page.timeTraveling) f = a.page.header.route.mode.timetravel, f.day.backToDefault(), f.time.backToDefault(), a.page.resetNotification();
                    b && b.hasLayer("timeTravelTraffic") && b.removeLayer("timeTravelTraffic")
                }
            },
            _onReady: function() {
                this._mapReady = !0;
                if (h.get("trafficIncidentsEnabled")) this.displayIncidents = !0, this._reloadIncidents(this._map.zoom, this._map.box)
            },
            _onZoom: function(a) {
                if (8 >= a.data.newValue) {
                    var f = this._map.infoBubbles.filter(b)[0];
                    f && this._map.hideInfoBubble(f)
                }
                a.data.oldValue !== a.data.newValue && this._reloadIncidents(a.data.newValue, this._map.box)
            },
            _onMove: function() {
                this._reloadIncidents(this._map.zoom, this._map.box)
            },
            _onPoiClick: function(a) {
                var b = a.data[0];
                b.data && b.data.incident && !b.infoBubble && (this._showInfoBubble(b), a.preventDefault())
            },
            enableTraffic: function() {
                this.displayIncidents = !0;
                h.set("mapSchema", "normal.day.traffic");
                h.set("trafficIncidentsEnabled", !0);
                nokia.mh5.components.Traffic.getTrafficTypes().forEach(function(a) {
                    h.set("traffic" + a + "Enabled", !0)
                })
            },
            enableTimeTravelTraffic: function(a) {
                var f = this._map;
                this._timeTravelDate = a = a || new Date;
                var d = this._map.infoBubbles.filter(b)[0];
                d && d.data.incident.endTime < this._timeTravelDate && f.hideInfoBubble(d);
                this._reloadIncidents(f.zoom, f.box);
                "normal.day.traffic" == h.get("mapSchema") && !f.hasLayer("timeTravelTraffic") && (h.set("mapSchema", "normal.day"), f.addLayer(l(a), "timeTravelTraffic"))
            },
            disableTimeTravelTraffic: function() {
                this._timeTravelDate = null;
                this._map.hasLayer("timeTravelTraffic") && (h.set("mapSchema", "normal.day.traffic"), this._map.removeLayer("timeTravelTraffic"));
                this._reloadIncidents(this._map.zoom, this._map.box)
            },
            reloadIncidents: function() {
                this._reloadIncidents(this._map.zoom, this._map.box)
            },
            showIncidents: function() {
                if (!this.displayIncidents) this.displayIncidents = !0, this._reloadIncidents(this._map.zoom, this._map.box)
            },
            hideIncidents: function() {
                if (this.displayIncidents) {
                    this.displayIncidents = !1;
                    if (this._currentRequest) this._currentRequest.cancel(), this._currentRequest = null;
                    this._clearIncidentsFromMap()
                }
            },
            checkInfoBubbleOnIncidentsChange: function() {
                var a = this._map.infoBubbles.filter(b)[0];
                a && (!h.get("trafficIncidentsEnabled") || !h.get("traffic" + a.data.incident.type + "sEnabled")) && this._map.hideInfoBubble(a)
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.ui.Dialog");
nokia.mh5.ui.Dialog = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = function(a) {
            a.preventDefault && a.stopPropagation && (a.preventDefault(), a.stopPropagation())
        },
        b = nokia.mh5.dom.addEvent,
        c = nokia.mh5.dom.removeEvent;
    return {
        cssClass: "mh5_modal",
        animationName: "fading",
        children: ["content"],
        content: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_Dialog"
        },
        allowScrolling: !1,
        closeOnTap: !1,
        disableUpdatePosition: !1,
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            this.update && this.update();
            this._updatePosition()
        },
        build: function() {
            ["_closeDialog", "_updatePosition", "_delayedUpdatePosition", "_onPointerDetect"].forEach(function(a) {
                this[a] = this[a].bind(this)
            }, this);
            g.build.call(this);
            this._scroll && nokia.mh5.win.setTimeout(this._scroll.refresh, 0)
        },
        _closeDialog: function(b) {
            b && a(b);
            if (this.visible) this.visible = !1
        },
        _onPointerDetect: function(c) {
            this.closeOnTap && b(this.root, c.touch ? "down" : "tap", this._closeDialog);
            this.allowScrolling || (c.touch ? b(this.root, "move", a) : b(nokia.mh5.win, "scroll", this._closeDialog))
        },
        _addHandlers: function() {
            b(nokia.mh5.win, "pointerdetect", this._onPointerDetect, !1);
            b(nokia.mh5.win, "viewportchange", this._delayedUpdatePosition, !1)
        },
        _removeHandlers: function() {
            c(nokia.mh5.win, "pointerdetect", this._onPointerDetect, !1);
            c(nokia.mh5.win, "viewportchange", this._delayedUpdatePosition, !1)
        },
        visibleDidChange: function(a) {
            var b = {
                type: "fade",
                mode: "in",
                node: this.root
            };
            if (a) this._addHandlers(), nokia.mh5.history.catchNextOnPopState = this._closeDialog;
            else if (this.root.parentNode) {
                this._removeHandlers();
                delete nokia.mh5.history.catchNextOnPopState;
                if (this.withoutAnimation) {
                    var c = this.root,
                        d = c.parentNode;
                    if (this.onClose) this.onClose();
                    setTimeout(function() {
                        d && d.removeChild(c)
                    }, 0);
                    return
                }
                b.mode = "out";
                if (this.onClose) b.callback = this.onClose.bind(this)
            }
            if (nokia.mh5.platform.android && 4 > nokia.mh5.platform.android.version) b.fadeNode = this.root.firstChild;
            nokia.mh5.dom.doTransition(b)
        },
        _delayedUpdatePosition: function() {
            nokia.mh5.win.setTimeout(this._updatePosition, 400)
        },
        _updatePosition: function() {
            if (!this.disableUpdatePosition) if (this.allowScrolling) {
                if (this.content && this.content.root) this.root.style.cssText = "min-height: 100%;height: " + Math.max(nokia.mh5.win.innerHeight, this.content.root.offsetHeight) + "px;overflow-x: hidden"
            } else this.root.style.cssText = "height: " + (nokia.mh5.win.innerHeight + 1) + "px;overflow: hidden;margin-top: " + nokia.mh5.win.pageYOffset + "px;"
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Select");
nokia.mh5.ui.Select = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    return {
        control: nokia.mh5.ui.Container,
        children: ["button", "bg", "select"],
        cssClass: "mh5_Select",
        button: {
            control: nokia.mh5.ui.Button
        },
        bg: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_bg"
        },
        select: {
            control: nokia.mh5.ui.Control,
            rootHtmlElementName: "select"
        },
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            if (this.items) {
                for (var c = "", e = 0; e < this.items.length; e++) {
                    var i = this.items[e],
                        c = c + nokia.mh5.utils.formatString('<option value="%val%" %sel%>%desc%</option>', {
                            desc: i.name,
                            val: i.value || i.name,
                            sel: i.sel ? "selected" : ""
                        });
                    if (i.sel) this.button.text = i.name
                }
                this.select.root.innerHTML = c
            }
            this.select.root.onchange = function() {
                var a = this.select.root.selectedIndex,
                    b = this.select.root.options[a].value;
                this.button.text = this.items[a].name;
                if (this.onChange) this.onChange(a, b)
            }.bind(this)
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.SegmentedButton");
nokia.mh5.ui.SegmentedButton = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        cssClass: "mh5_SegmentedButton mh5_ColumnLayout",
        _selectedIndex: void 0,
        constructor: function(a, b) {
            a.items = a.items || [];
            g.constructor.call(this, a, b);
            this.update()
        },
        _clickHandler: function(a) {
            if (!(this._selectedIndex === a || this.items[a].disabled)) if (void 0 !== this._selectedIndex && nokia.mh5.dom.removeClass(this.root.children[this._selectedIndex], "mh5_selected"), nokia.mh5.dom.addClass(this.root.children[a], "mh5_selected"), this._selectedIndex = a, this.onValueChange) this.onValueChange(this.items[a].value || a)
        },
        select: function(a) {
            if (null == a) this._selectedIndex = void 0;
            else {
                for (var b = 0, c = this.items.length; b < c; b++) if (this.items[b].value === a) {
                    this._clickHandler(b);
                    return
                }
                this.items[a] && this._clickHandler(a)
            }
        },
        update: function() {
            var a = nokia.mh5.doc.createDocumentFragment(),
                b, c;
            for (c in this.items) this.items.hasOwnProperty(c) && (b = this._createItem(this, parseInt(c, 10)), a.appendChild(b.root));
            this.root.innerHTML = "";
            this.root.appendChild(a)
        },
        _createItem: function(a, b) {
            var c = this,
                e = a.items[b],
                i = b === a._selectedIndex ? ["mh5_selected"] : [],
                h = !e.name && e.iconClass ? "" : e.name || "Item " + (b + 1);
            e.cssClass && i.push(e.cssClass);
            e.disabled && i.push("mh5_disabled");
            return new nokia.mh5.ui.Control({
                cssClass: i.join(" "),
                onClick: function(a) {
                    c._clickHandler(b);
                    a.stopPropagation()
                },
                innerHTML: e.iconClass ? "<div class='" + e.iconClass + "'/>" : "<div>" + h + "</div>"
            })
        },
        add: function(a) {
            this.items.push(a);
            this.update()
        },
        remove: function(a) {
            for (var b = null, c = [], e = 0, i = this.items.length; e < i; e++) c.push(this.items[e]), this.items[e].value === a && (b = e);
            !b && this.items[a] && (b = a);
            if (b) {
                this.items = [];
                this.items = c.slice(0, b).concat(c.slice(b + 1));
                if (b <= this._selectedIndex) this._selectedIndex = b === this._selectedIndex ? void 0 : this._selectedIndex - 1;
                this.update()
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.RadioItem");
nokia.mh5.ui.RadioItem = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        rootHtmlElementName: "li",
        cssClass: "mh5_ListItem",
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            this.update()
        },
        update: function() {
            this.root.innerHTML = "<div><div class='mh5_name'>" + this.title + "</div>" + (this.description ? "<div class='mh5_description'>" + this.description + "</div>" : "") + "</div><div class='mh5_status'></div>";
            nokia.mh5.dom[this.disabled ? "addClass" : "removeClass"](this.root, "mh5_disabled")
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.analytics");
(function() {
    var g = Math.round(1E4 * Math.random()),
        a = !1,
        b = !1,
        c = nokia.mh5.components.settings,
        e = !0;
    nokia.mh5.ui.Control.watch(c.current, "analyticsEnabled", c.current, function() {
        e = this.analyticsEnabled
    });
    nokia.mh5.maps.analytics.log = function(c) {
        if (e) {
            var h = ["http://metrics.nokia.com/b/ss/nokiaglobalmwg0prod".concat("/5/", g, "?D=~&ch=ovi:maps:mw&c6=ovimapsmwg0")],
                d;
            !b && /[?&]cid=([^&#?]+)/.test(window.location.href) && (h.push("&v0=" + RegExp.$1), b = !0);
            for (d in c) c.hasOwnProperty(d) && h.push("&" + d + "=" + c[d]);
            !a && document.referrer && (h.push("&r=" + document.referrer + "&c30=~r&v30=~r"), a = !0);
            nokia.mh5.platform.webview && h.push("&c50=" + (nokia.mh5.platform.android_webview ? "android native" : "ios native") + "&v50=~c50");
            (new Image).src = encodeURI(h.join(""))
        }
    };
    nokia.mh5.maps.analytics.getPlaceId = function(a) {
        return a.placeId || a.latitude + "," + a.longitude
    };
    nokia.mh5.maps.analytics.getContext = function(a) {
        var b = "";
        a && a.href && (a = a.href.match(/context=([^?]+)/)) && a[1] && (b = a[1]);
        return b
    };
    nokia.mh5.maps.analytics.logIfVisible = function(a, b) {
        a.visible && !a._wasLogged && nokia.mh5.maps.analytics.log(b);
        a._wasLogged = a.visible
    }
})();
nokia.mh5.provide("nokia.mh5.ui.SettingsDialog");
(function() {
    var g = nokia.mh5.components.settings,
        a = nokia.mh5.dom,
        b = nokia.mh5.event,
        c = nokia.mh5.ui,
        e = c.Container,
        i = c.Control,
        h = c.List,
        d = c.RadioItem;
    nokia.mh5.ui.SettingsDialog = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(j) {
        var f = nokia.mh5.i18n,
            k, m;
        return {
            cssClass: "mh5_SettingsDialog",
            allowScrolling: !0,
            constructor: function(a, b) {
                var d = this.content.children.indexOf("settingsToggleIndicator"),
                    c, e;
                if (!a.traffic && ~d) c = this.content.settingsToggle, e = c.items, this.content.children.splice(d, 1), delete c.onValueChange, e.pop(), e[0].name = f("mapControl"), e[0].cssClass += " mh5_box-flex1";
                j.constructor.call(this, a, b)
            },
            content: {
                control: e,
                cssClass: "mh5_SettingsDialogContainer",
                vScroll: !0,
                bounce: !1,
                layout: {
                    type: c.RowLayout,
                    align: "strech"
                },
                children: "mapOffset,settingsToggle,settingsToggleBorder,settingsToggleIndicator,settingsList,fillup".split(","),
                mapOffset: {
                    control: e,
                    cssClass: "mh5_mapOffset"
                },
                settingsToggle: {
                    control: c.SegmentedButton,
                    cssClass: "mh5_SettingsToggle mh5_ColumnLayout mh5_standardBackgroundColorDark",
                    items: [{
                        name: f("maps"),
                        value: "maps",
                        cssClass: "settings_maps"
                    }, {
                        name: f("layers"),
                        value: "layers",
                        cssClass: "settings_layers"
                    }],
                    onValueChange: function(a) {
                        var b = this.parent.settingsList,
                            f = this.root.querySelector(".mh5_selected"),
                            f = Math.round(f.offsetLeft + f.offsetWidth / 2);
                        this.parent.settingsToggleIndicator.root.style[nokia.mh5.dom.transformProperty] = "translateX(" + f + "px)";
                        "maps" == a ? (b.maps.visible = !0, b.layers.visible = !1) : (b.maps.visible = !1, b.layers.visible = !0);
                        this.parent.parent.resize()
                    }
                },
                settingsToggleBorder: {
                    control: i,
                    cssClass: "mh5_SettingsIndicatorBorder"
                },
                settingsToggleIndicator: {
                    control: i,
                    cssClass: "mh5_SettingsIndicator",
                    innerHTML: "<div></div>"
                },
                settingsList: {
                    control: e,
                    cssClass: "mh5_SettingsList mh5_standardBackgroundColorDark",
                    children: ["maps", "layers"],
                    maps: {
                        control: e,
                        children: ["mapModeRadioGroup", "retinaTiles", "communityMap", "unitSystemToggle", "languageSwitch"],
                        mapModeRadioGroup: {
                            control: h,
                            cssClass: "mh5_mapTypes mh5_List",
                            itemClass: d,
                            items: [{
                                title: f("UI.SettingsDialog.mapView"),
                                schema: "normal.day",
                                retina: !0
                            }, {
                                title: f("UI.SettingsDialog.satView"),
                                schema: "hybrid.day",
                                retina: !0
                            }, {
                                title: f("UI.SettingsDialog.PTView"),
                                schema: "normal.day.transit",
                                retina: !0
                            }, {
                                title: f("UI.SettingsDialog.trafficView"),
                                schema: "normal.day.traffic",
                                retina: !1
                            }],
                            listeners: {
                                tap: function(b) {
                                    var f = b.data.index,
                                        d = b.data.item,
                                        b = b.data.community,
                                        c = this.parent.communityMap,
                                        e = c.renderedItems[0],
                                        h = b || a.hasClass(e.root, "mh5_selected") && 2 > f;
                                    if (!d.disabled) {
                                        var i = this.getContentRoot();
                                        a.removeClass(i.children[k], "mh5_selected");
                                        a.addClass(i.children[f], "mh5_selected");
                                        i = h ? d.schema + ".community" : d.schema;
                                        i !== g.get("mapSchema") && (g.set("mapSchema", i), nokia.mh5.maps.analytics.log({
                                            gn: "settings",
                                            c32: "change schema",
                                            v32: "~c32"
                                        }));
                                        !d.retina || h ? (g.set("retinaTiles", !1), a.removeClass(this.parent.retinaTiles.renderedItems[0].root, "mh5_selected"), this.parent.retinaTiles.items[0].disabled = this.parent.retinaTiles.renderedItems[0].disabled = !0) : (m && (g.set("retinaTiles", !0), a.addClass(this.parent.retinaTiles.renderedItems[0].root, "mh5_selected")), this.parent.retinaTiles.items[0].disabled = this.parent.retinaTiles.renderedItems[0].disabled = !1);
                                        this.parent.retinaTiles.renderedItems[0].update();
                                        k = f;
                                        e.disabled = c.items[0].disabled = 1 < f;
                                        e.update();
                                        b && a.addClass(e.root, "mh5_selected")
                                    }
                                }
                            }
                        },
                        retinaTiles: {
                            control: h,
                            itemClass: d,
                            cssClass: "mh5_List mh5_RowLayout mh5_SettingOnOff mh5_CommunityMap mh5_RetinaTiles",
                            items: [{
                                title: f("UI.SettingsDialog.Retina"),
                                value: !0
                            }],
                            listeners: {
                                tap: function(b) {
                                    var f = this.root.children[0],
                                        d = a.hasClass(f, "mh5_selected");
                                    b.data.item.disabled || (a[d ? "removeClass" : "addClass"](f, "mh5_selected"), m = !d, g.set("retinaTiles", !d))
                                }
                            }
                        },
                        communityMap: {
                            control: h,
                            itemClass: d,
                            cssClass: "mh5_List mh5_RowLayout mh5_SettingOnOff mh5_CommunityMap",
                            items: [{
                                title: f("UI.SettingsDialog.CommunityMaps"),
                                description: f("UI.SettingsDialog.CommunityMapFootnote"),
                                value: !0
                            }],
                            listeners: {
                                tap: function(b) {
                                    var f = this.root.children[0],
                                        d = a.hasClass(f, "mh5_selected"),
                                        c = g.get("mapSchema");
                                    if (!b.data.item.disabled) a[d ? "removeClass" : "addClass"](f, "mh5_selected"), g.set("mapSchema", d ? c.slice(0, -10) : c + ".community"), d ? (m && (g.set("retinaTiles", !0), a.addClass(this.parent.retinaTiles.renderedItems[0].root, "mh5_selected")), this.parent.retinaTiles.items[0].disabled = this.parent.retinaTiles.renderedItems[0].disabled = !1) : (g.set("retinaTiles", !1), a.removeClass(this.parent.retinaTiles.renderedItems[0].root, "mh5_selected"), this.parent.retinaTiles.items[0].disabled = this.parent.retinaTiles.renderedItems[0].disabled = !0), this.parent.retinaTiles.renderedItems[0].update()
                                }
                            }
                        },
                        unitSystemToggle: {
                            control: c.SegmentedButton,
                            cssClass: "mh5_SegmentedButton mh5_UnitSystemToggle mh5_ColumnLayout",
                            items: [{
                                name: f("UI.SettingsDialog.Km"),
                                value: "km"
                            }, {
                                name: f("UI.SettingsDialog.Miles"),
                                value: "mi"
                            }],
                            onValueChange: function(a) {
                                g.get("unitSystem") != a && (g.set("unitSystem", a), nokia.mh5.maps.analytics.log({
                                    gn: "settings",
                                    c32: "change units",
                                    v32: "~c32"
                                }))
                            }
                        },
                        languageSwitch: {
                            control: e,
                            cssClass: "mh5_languageSwitch",
                            visible: !(nokia.mh5.platform.android || nokia.mh5.platform.android_webview),
                            build: function() {
                                var a = {
                                    en: "English",
                                    es: "Espa\u00f1ol",
                                    "es-mx": "Espa\u00f1ol (Mexico)",
                                    pt: "Portugu\u00eas",
                                    "pt-br": "Portugu\u00eas (Brasil)"
                                },
                                    b = [];
                                nokia.mh5.each(nokia.mh5.i18n_languages, function(f, d) {
                                    "object" === nokia.mh5.type(f) && b.push({
                                        name: a[d],
                                        value: d,
                                        sel: nokia.mh5.i18n.language == d
                                    })
                                }, this);
                                this.root.innerHTML = "<div><div>" + f("UI.SettingsDialog.Language") + "</div></div>";
                                this.add(new c.Select({
                                    items: b,
                                    onChange: function(a, b) {
                                        nokia.mh5.i18n.language = b;
                                        nokia.mh5.win.location.reload()
                                    }
                                }), "select");
                                if (1 === b.length || !nokia.mh5.platform.firefox_mobile) this.visible = !1
                            }
                        }
                    },
                    layers: {
                        control: e,
                        children: ["trafficOnOffSwitch", "trafficSettingsContainer", "criticalitySigns"],
                        visible: !1,
                        trafficOnOffSwitch: {
                            control: h,
                            itemClass: d,
                            cssClass: "mh5_List mh5_RowLayout mh5_SettingOnOff",
                            items: {
                                title: f("UI.SettingsDialog.TrafficIncidents"),
                                value: !0
                            },
                            onClick: function() {
                                var a = this.root.children[0],
                                    b = this.getRootOwnerByClass(c.SettingsDialog);
                                nokia.mh5.maps.analytics.log({
                                    gn: "settings",
                                    c32: !nokia.mh5.dom.hasClass(a, "mh5_select") ? "incidents on" : "incidents off",
                                    v32: "~32"
                                });
                                b._changeIncidents(a, "Incidents")
                            }
                        },
                        trafficSettingsContainer: {
                            control: h,
                            itemClass: new nokia.mh5.Class(i, function(b) {
                                return {
                                    rootHtmlElementName: "li",
                                    cssClass: "mh5_ListItem",
                                    constructor: function(a, f) {
                                        b.constructor.call(this, a, f);
                                        this.update()
                                    },
                                    update: function() {
                                        a[this.disabled ? "addClass" : "removeClass"](this.root, "mh5_disabled");
                                        var b = document.createDocumentFragment(),
                                            f = document.createElement("div");
                                        f.className = "mh5_image mh5_image" + this.value;
                                        b.appendChild(f);
                                        f = document.createElement("div");
                                        f.className = "mh5_name";
                                        f.innerHTML = this.title;
                                        b.appendChild(f);
                                        f = document.createElement("div");
                                        f.className = "mh5_status";
                                        b.appendChild(f);
                                        this.root.appendChild(b)
                                    }
                                }
                            }),
                            cssClass: "mh5_List mh5_RowLayout mh5_TrafficSettings",
                            items: nokia.mh5.components.Traffic.getTrafficTypes().map(function(a) {
                                return {
                                    title: f("UI.SettingsDialog." + a),
                                    value: a
                                }
                            }),
                            onClick: function(a) {
                                if (!this.items[a].disabled) {
                                    var b = this.root.children[a],
                                        a = this.items[a].value;
                                    this.getRootOwnerByClass(c.SettingsDialog)._changeIncidents(b, a)
                                }
                            }
                        },
                        criticalitySigns: {
                            control: h,
                            cssClass: "mh5_criticalitySigns",
                            itemClass: new nokia.mh5.Class(i, function(a) {
                                return {
                                    rootHtmlElementName: "li",
                                    cssClass: "mh5_CriticalitySign",
                                    constructor: function(b, f) {
                                        a.constructor.call(this, b, f);
                                        this.update()
                                    },
                                    update: function() {
                                        this.root.innerHTML = '<div class="text">' + f("maps.Traffic." + this.type) + '</div> <div class="img img_' + this.type + '"></div>'
                                    }
                                }
                            }),
                            items: [{
                                type: "minor"
                            }, {
                                type: "major"
                            }, {
                                type: "critical"
                            }]
                        }
                    }
                },
                fillup: {
                    control: i,
                    cssClass: "mh5_fillup mh5_standardBackgroundColorDark"
                }
            },
            build: function() {
                m = !1;
                this.resize = this.resize.bind(this);
                this.onGlobalTap = this.onGlobalTap.bind(this);
                this.content.settingsList.maps.retinaTiles.visible = nokia.mh5.platform.retina;
                j.build.call(this)
            },
            resize: function() {
                var b = this.content,
                    f = b.getContentRoot();
                a[f.offsetHeight > this.root.offsetHeight ? "addClass" : "removeClass"](b.root, "mh5_autoHeight");
                nokia.mh5.win.setTimeout(b._scroll.refresh, 1)
            },
            _update: function() {
                this.visible && (this._updateMapModeSelection(), this._updateRetinaSelection(), this._updateUnitSystem(), this._updateTrafficIncidentSelection(), this._updateTrafficOnOffButton(), this.resize())
            },
            onGlobalTap: function(b) {
                (!a.contains(this.root, b.target) || this.content.mapOffset.root === b.target) && this._closeDialog(b)
            },
            visibleDidChange: function(f) {
                var d = this;
                f ? (b.add(nokia.mh5.win, "viewportchange", d.resize, !1), b.add(nokia.mh5.doc.body, a.touchStart, d.onGlobalTap, !0), b.add(nokia.mh5.doc.body, "focus", d.onGlobalTap, !0), setTimeout(function() {
                    d.content.settingsToggle.select("maps")
                }, 1), this._update()) : (b.remove(nokia.mh5.win, "viewportchange", d.resize, !1), b.remove(nokia.mh5.doc.body, a.touchStart, d.onGlobalTap, !0), b.remove(nokia.mh5.doc.body, "focus", d.onGlobalTap, !0));
                j.visibleDidChange.apply(d, arguments)
            },
            _updateRetinaSelection: function() {
                var b = this.content.settingsList.maps.retinaTiles.root.children[0],
                    f = g.get("retinaTiles");
                a[f ? "addClass" : "removeClass"](b, "mh5_selected")
            },
            _updateUnitSystem: function() {
                this.content.settingsList.maps.unitSystemToggle.select(g.get("unitSystem"))
            },
            _updateTrafficIncidentSelection: function() {
                var b = this.content.settingsList.layers.trafficSettingsContainer;
                nokia.mh5.each(nokia.mh5.components.Traffic.getTrafficTypes(), function(f) {
                    var d = g.get("traffic" + f + "Enabled"),
                        c = b.renderedItems.filter(function(a) {
                            return a.value === f
                        })[0].root;
                    a[d ? "addClass" : "removeClass"](c, "mh5_selected")
                })
            },
            _updateTrafficOnOffButton: function() {
                var b = g.get("trafficIncidentsEnabled");
                a[b ? "addClass" : "removeClass"](this.content.settingsList.layers.trafficOnOffSwitch.renderedItems[0].root, "mh5_selected")
            },
            _updateMapModeSelection: function() {
                var a = this.content.settingsList.maps.mapModeRadioGroup,
                    f = g.get("mapSchema"),
                    d = /\bcommunity$/.test(f),
                    c = a.items;
                "normal.day.grey" == f && (f = "normal.day.transit");
                if (f) for (var e in c) {
                    if (c[e].schema === f || d && c[e].schema === f.slice(0, -10)) {
                        k = e;
                        break
                    }
                } else k = 0;
                b.fire(a, "tap", {
                    index: k,
                    item: c[k],
                    community: d
                })
            },
            _changeIncidents: function(b, f) {
                var d = a.hasClass(b, "mh5_selected");
                g.set("traffic" + f + "Enabled", !d);
                a[d ? "removeClass" : "addClass"](b, "mh5_selected");
                d = nokia.mh5.app.controller.current.page.traffic;
                d.checkInfoBubbleOnIncidentsChange();
                if (g.get("trafficIncidentsEnabled")) d["Incidents" == f ? "showIncidents" : "reloadIncidents"]();
                else d.hideIncidents()
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.components.InfoBubble");
nokia.mh5.components.InfoBubble = function() {
    function g(a, b) {
        r.font = b;
        r.textBaseline = "bottom";
        r.fillStyle = "rgb(255,255,255)";
        return r.measureText(a || " ").width
    }
    function a(a, b, f) {
        for (var d = g(a, b); f < d;) a = a.substr(0, a.length - 2) + "\u2026", d = g(a, b);
        return {
            text: a,
            textWidth: d
        }
    }
    function b(a, b) {
        setTimeout(a.next = function() {
            return (b = a.shift()) ? !! b(a) || !0 : !1
        }, 0);
        return a
    }
    function c(a, b, f) {
        var d = (f || a.params)[b];
        "string" == typeof d ? (f = new Image, f.src = d, f.onload = a.next, a[b] = f) : "function" == typeof d ? d(function(f) {
            a[b] = f;
            a.next()
        }) : d.width || d.height ? (a[b] = (f || a.params)[b], a.next()) : d instanceof Image && (d.addEventListener("load", function z() {
            d.removeEventListener("load", z, !1);
            a.next()
        }, !1), a[b] = d)
    }
    function e(a) {
        c(a, "left")
    }
    function i(a) {
        c(a, "right")
    }
    function h(a) {
        c(a, "image")
    }
    function d(a) {
        y.star.src = nokia.mh5.assetsPath + "img/fullstar_icon.png";
        c(a, "star", y)
    }
    function j(a) {
        y.hstar.src = nokia.mh5.assetsPath + "img/halfstar_icon.png";
        c(a, "hstar", y)
    }
    function f(a) {
        y.estar.src = nokia.mh5.assetsPath + "img/emptystar_icon.png";
        c(a, "estar", y)
    }
    function k(a, b, f) {
        r.save();
        r.beginPath();
        r.strokeStyle = "#FFFFFF";
        r.moveTo(a, b);
        r.lineTo(a, f - b);
        r.stroke();
        r.closePath();
        r.restore()
    }
    function m(b) {
        var f = document.createElement("CANVAS"),
            d = b.params,
            c = nokia.mh5.extend({}, b.data),
            e = b.left || v,
            h = b.right || v,
            g = b.image || v,
            i = 0,
            j = Number.MAX_VALUE,
            m = 0,
            t = nokia.mh5.platform.firefox_mobile ? 3 : nokia.mh5.platform.firefox ? 1 : 0,
            s = 0,
            q = 0,
            x = "background" in d ? d.background : "rgba(0,15,26,0.85)",
            P = 2 * Math.round(16 * (d.borderRadius || 2) / 12),
            Q = 2 * Math.round(16 / 12),
            K = 2 * Math.round(224 / 12) - 2 * t,
            M = 2 * Math.round(16),
            Ca = 2 * d.maxWidth || Number.MAX_VALUE,
            N, I = 0,
            V = 300,
            L = d.content,
            ga, ma, ba;
        w.forEach(function(a) {
            a in d && d[a] && (c["title" == a ? "name" : a] = d[a])
        });
        Array.isArray(L) && 3 < L.length && (L = L.slice(0, 3));
        r = f.getContext("2d");
        if (g != v) s = g.width;
        else {
            if (e != v && (s += 52 + e.width, N || h != v)) s += 2;
            if (h != v && (s += 52 + h.width, N || e != v)) s += 2
        }
        if (L && g == v) {
            -1 != L.indexOf("rating") && c.ratingValue && (q += 32, I = 140, N = !0);
            V = Math.max(Ca - s - 52, I);
            if (-1 != L.indexOf("title") && c.name) q += K + 12, N = a(c.name, "bold 28pt Arial", V), ga = N.text, I = Math.max(I, N.textWidth), N = !0;
            if (-1 != L.indexOf("description") && c.description) q += M + 12, N = a(c.description, "24pt Arial", V), ma = N.text, I = Math.max(I, N.textWidth), N = !0;
            if (-1 != L.indexOf("more") && c.more) q += M + 12, N = a(c.more, "24pt Arial", V), ba = N.text, I = Math.max(I, N.textWidth), N = !0;
            N && (s += I + 52);
            q && (q -= 12);
            q += x ? 32 : 0
        }
        q = Math.max(q, e.height, h.height, g.height);
        f.width = s;
        f.height = q + (x ? 32 : 0);
        x && u(f.width, q, Q, P, x);
        if (g != v) r.drawImage(g, 0, 0);
        else {
            e != v && (m += 26, r.drawImage(e, m, ~~ ((q - e.height) / 2)), m += e.width, m += 26, (N || h != v) && d.leftDelimiter && k(m, 16, q), i = m);
            if (N) {
                m += 26;
                r.textBaseline = "top";
                r.fillStyle = "#FFFFFF";
                t = n(ga, "bold 28pt Arial", m, t, 12, K);
                t = n(ma, "24pt Arial", m, t, 12, M);
                t = n(ba, "24pt Arial", m, t, 12, M);
                if (-1 != L.indexOf("rating")) {
                    e = 0;
                    for (t += 12; e < ~~c.ratingValue;) l(y.star, e++, m, t);
                    for (e < c.ratingValue && l(y.hstar, e++, m, t); 5 > e;) l(y.estar, e++, m, t)
                }
                m = m + I + 26
            }
            h != v && (j = m, N && d.rightDelimiter && k(m, 16, q), r.drawImage(h, m + 26, ~~ ((q - h.height) / 2)))
        }
        x && (r.translate(s / 2, q - 1), o(x));
        r = null;
        nokia.mh5.event.add(f, "down", function(a) {
            var b = d.listeners,
                f, c = a.offsetX || a.data.offsetX,
                a = a.offsetY || a.data.offsetY;
            if (b) {
                if (b.leftclick && c < i) f = b.leftclick;
                else if (b.rightclick && c > j) f = b.rightclick;
                else if (b.click) f = b.click;
                f && f.call(this, {
                    clickedPoint: {
                        x: c,
                        y: a
                    }
                })
            }
        }.bind(this), !1);
        f.leftDelimiter = i;
        f.rightDelimiter = j;
        b.callback(f)
    }
    function n(a, b, f, d, c, e) {
        if (a) c = d += c, r.font = b, r.fillText(a, f, c), d += e;
        return d
    }
    function l(a, b, f, d) {
        r.drawImage(a, f + 14 * b, d)
    }
    function o(a) {
        r.beginPath();
        r.moveTo(12, 0);
        r.lineTo(0, 28);
        r.lineTo(-12, 0);
        r.closePath();
        r.fillStyle = "rgb(255,255,255)";
        r.fill();
        r.fillStyle = a;
        r.fill();
        r.translate(0, 28);
        r.save();
        r.scale(1.9, 1);
        r.beginPath();
        r.arc(0, 0, 5.2, 0, 2 * Math.PI, !1);
        r.fillStyle = "rgba(0,0,0,0.35)";
        r.fill();
        r.closePath();
        r.restore()
    }
    function u(a, b, f, d, c) {
        var e = f / 2,
            h = d + e,
            k = a - h,
            l = b - h;
        r.fillStyle = c;
        r.lineWidth = f;
        r.lineCap = "round";
        r.moveTo(h, e);
        a = [k, e, k, h, d, s, x, a - e, l, k, l, d, x, q, h, b - e, h, l, d, q, t, e, h, h, h, d, t, s];
        b = 0;
        for (f = a.length; b < f;) r.lineTo(a[b++], a[b++]), r.arc(a[b++], a[b++], a[b++], a[b++], a[b++]);
        r.fill()
    }
    document.createElement("CANVAS");
    var w = ["title", "description", "more"],
        v = {
            height: 0,
            width: 0
        },
        y = {
            star: new Image,
            hstar: new Image,
            estar: new Image
        },
        t = Math.PI,
        q = t / 2,
        s = 3 * q,
        x = 0,
        r;
    return function(a, c, k) {
        this.data = a;
        this.params = c;
        this.parent = c.parent;
        b([function(b) {
            b.params = c;
            b.data = a;
            b.callback = k;
            c.hasOwnProperty("left") && c.left && b.unshift(e);
            c.hasOwnProperty("right") && c.right && b.unshift(i);
            c.hasOwnProperty("image") && c.image && b.unshift(h);
            c.hasOwnProperty("content") && ~c.content.indexOf("rating") && (b.unshift(d), b.unshift(j), b.unshift(f));
            b.next()
        },
        m.bind(this)])
    }
}();
nokia.mh5.provide("nokia.mh5.maps.sso");
nokia.mh5.sso = function() {
    var g = nokia.mh5.event,
        a = nokia.mh5.win,
        b = nokia.mh5.utils,
        c, e = function(e) {
            e ? (c = e, b.setLocalStorageValue("sso_user", JSON.stringify(e))) : c = a.localStorage.removeItem("sso_user")
        };
    return {
        init: function() {
            var i;
            g.add(a, "message", function(b) {
                if (-1 !== "http://demo.maps.public.devbln.europe.nokia.com,http://localhost:4224,http://localhost,http://192.168.56.112:4224,http://192.168.56.101:4224,http://stg.m.maps.nokia.com,http://qa.mh5.public.devbln.europe.nokia.com,http://m.maps.nokia.com,http://convos.americas.nokia.com:8080,http://bsmacvm03.americas.nokia.com:8080,http://conversations-dev.americas.nokia.com:9090/,http://api.qa.pulse.nokia.com,https://ci.ovi.com,https://st-account.nokia.com,https://account.nokia.com,http://m.here.net,http://stg.m.here.net,http://m.here.com,http://stg.m.here.com".split(",").indexOf(b.origin)) {
                    if ((b = JSON.parse(b.data)) && !b.error) e(b), g.fire(a, "sso_signin", b);
                    nokia.mh5.app.controller.current.page.visible = !0
                }
            });
            (i = b.getLocalStorageValue("sso_user")) && (c = JSON.parse(i));
            this.isAuthenticated()
        },
        login: function() {
            if (nokia.mh5.platform.ios_webview) return a.open("http://m.here.com/releases/1.8.44/server/sso/login.php?wrapped");
            if (nokia.mh5.platform.android_webview) window.android_js_interface.loadMe("http://m.here.com/releases/1.8.44/server/sso/login.php?wrapped");
            else return a.open("http://m.here.com/releases/1.8.44/server/sso/login.php");
            return !0
        },
        logout: function(b) {
            nokia.mh5.platform.ios_webview ? a.open("http://m.here.com/releases/1.8.44/server/sso/logout.php?wrapped") : nokia.mh5.platform.android_webview && window.android_js_interface.loadMe("http://m.here.com/releases/1.8.44/server/sso/logout.php?wrapped");
            nokia.mh5.jsonp("http://m.here.com/releases/1.8.44/server/sso/logout.php?jsonp", function() {
                e();
                g.fire(a, "sso_signout");
                "function" === typeof b && b()
            }, 1E4)
        },
        isAuthenticated: function() {
            if (c) {
                var b = Math.round(Date.now() / 1E3);
                if (!c.validuntil || c.validuntil < b) c = a.localStorage.removeItem("sso_user"), g.fire(a, "sso_signout")
            }
            return !!c
        },
        getUserData: function(a) {
            return !this.isAuthenticated() ? void 0 : a ? c[a] : c
        }
    }
}();
nokia.mh5.provide("nokia.mh5.components.sync");
(function() {
    var g = JSON.parse,
        a = JSON.stringify,
        b = nokia.mh5.utils.getLocalStorageValue,
        c = nokia.mh5.utils.setLocalStorageValue,
        e = nokia.mh5.utils.formatString,
        i = function(a) {
            a.preventDefault()
        },
        h = function(a) {
            return e("http://m.here.com/releases/1.8.44/server/scbe/index.php?%action%&deletedSince=%deletedSince%&app_id=%appId%&app_code=%appCode%&csrf_token=%csrfToken%&objectTypes=%objectTypes%&jsonp", nokia.mh5.extend({
                appId: nokia.mh5.appId,
                appCode: nokia.mh5.appCode,
                csrfToken: nokia.mh5.sso.getUserData("csrf_token")
            }, a))
        },
        d = !1,
        j = new nokia.mh5.ui.Container({
            visible: !1,
            cssClass: "mh5_SyncModal mh5_modal mh5_modalBg mh5_transition_fade mh5_transition_hide",
            innerHTML: '<div class="mh5_spinner_big_bright"></div>',
            timer: null,
            timerAction: null,
            timeout: null,
            build: function() {
                nokia.mh5.doc.body.appendChild(this.root);
                this.toggle = this._debounce(this.toggle, 200)
            },
            toggle: function(a) {
                if (a && "show" !== this.timerAction) this._clear(), this.timerAction = "show", this.timer = setTimeout(this._show.bind(this), 100);
                if (!a && "hide" !== this.timerAction) this._clear(), this.timerAction = "hide", this.timer = setTimeout(this._hide.bind(this), 100)
            },
            _show: function() {
                j.visible = !0;
                nokia.mh5.dom.addClass(j.root, "mh5_transition_fade");
                setTimeout(function() {
                    nokia.mh5.dom.addClass(nokia.mh5.doc.body, "mh5_overflow_hidden");
                    nokia.mh5.event.add(nokia.mh5.doc.body, "down", i);
                    j.root.style.top = Math.max(nokia.mh5.win.document.documentElement.scrollTop || 0, nokia.mh5.doc.body.scrollTop || 0) + "px";
                    nokia.mh5.dom.removeClass(j.root, "mh5_transition_hide")
                }, 2);
                this._clear()
            },
            _hide: function() {
                nokia.mh5.dom.addEvent(this.root, "webkitTransitionEnd", this._detach, !1);
                nokia.mh5.dom.addEvent(this.root, "transitionend", this._detach, !1);
                nokia.mh5.dom.addClass(j.root, "mh5_transition_hide");
                nokia.mh5.dom.removeClass(nokia.mh5.doc.body, "mh5_overflow_hidden");
                nokia.mh5.event.remove(nokia.mh5.doc.body, "down", i);
                this._clear();
                setTimeout(this._detach.bind(this), 750)
            },
            _debounce: function(a, b, d) {
                var c, e;
                return function() {
                    var h = this,
                        g = arguments,
                        i = d && !c;
                    clearTimeout(c);
                    c = setTimeout(function() {
                        c = null;
                        d || (e = a.apply(h, g))
                    }, b);
                    i && (e = a.apply(h, g));
                    return e
                }
            },
            _clear: function() {
                if (this.timer) clearTimeout(this.timer), this.timerAction = this.timer = null
            },
            _detach: function() {
                if (nokia.mh5.dom.hasClass(j.root, "mh5_transition_hide")) j.visible = !1, nokia.mh5.dom.removeEvent(j.root, "webkitTransitionEnd", j._detach, !1), nokia.mh5.dom.removeEvent(j.root, "transitionend", j._detach, !1), nokia.mh5.dom.removeClass(j.root, "mh5_transition_hide"), nokia.mh5.dom.removeClass(j.root, "mh5_transition_fade")
            }
        });
    nokia.mh5.components.sync = {
        formatStr: e,
        SCBE_SERVER: "http://m.here.com/releases/1.8.44/server/scbe/index.php?%action%&deletedSince=%deletedSince%&app_id=%appId%&app_code=%appCode%&csrf_token=%csrfToken%&objectTypes=%objectTypes%&jsonp",
        buildUri: h,
        callServer: function(a, b) {
            j.toggle(!0);
            nokia.mh5.jsonp(h(a), function(a) {
                0 === Object.keys(a).length && (a = {
                    error: "Possibly problem connecting to SCBE server"
                });
                j.toggle(!1);
                b && b.call(this, a)
            }.bind(this))
        },
        extend: function(a) {
            return nokia.mh5.extend(Object.create(nokia.mh5.components.sync), a)
        },
        _generateID: function(a) {
            var d = g(b(this.objectType) || "{}"),
                c = 1,
                e;
            do e = a + "_" + c++;
            while (d[e]);
            return e
        },
        _findObject: function(a, b) {
            for (var d in b) if (d === a.id && !b[d].deleted) return b[d]
        },
        _queue: function(a, b, d, c) {
            var e = this.__queue = this.__queue || [],
                h = this.__dangling = this.__dangling || [];
            this.__idc = this.__idc || 0;
            var g = this,
                i = function(a) {
                    if (h[a]) delete h[a];
                    else if (0 != e.length && (e[0].timeoutId && clearTimeout(e[0].timeoutId), e[0].c && e[0].c.apply(this, Array.prototype.slice.call(arguments, 1)), e.shift(), 0 < e.length)) {
                        this.__idc++;
                        e[0].timeoutId = setTimeout(function(a) {
                            var b = e[0];
                            i(a);
                            h[a] = b
                        }, e[0].t, this.__idc);
                        var b = function(a) {
                                return function() {
                                    i.apply(g, [a].concat(Array.prototype.slice.call(arguments, 0)))
                                }
                            }(this.__idc);
                        e[0].f.apply(g, e[0].p ? [e[0].p, b] : [b])
                    }
                }.bind(this);
            e.push({
                f: a,
                p: b,
                c: d,
                t: c
            });
            1 === e.length && (e.unshift([]), i())
        },
        _takeFromServer: function(a, b, d) {
            d[b] = this.mapServerToClient(a);
            d[b].inSync = !0;
            d[b].updatedTime = a.updatedTime
        },
        _synchronize: function(a) {
            if (this.shouldSync()) {
                var b = this;
                b.listServerObjs(function(d) {
                    if (!d || !d.data) a && a();
                    else {
                        for (var c = {}, e, h = {}, g, d = d.data, i = 0, j = d.length; i < j; i++) e = d[i], c[e.id] = e;
                        var h = b.getState(),
                            y = 0,
                            t = Object.keys(h),
                            q = function(a) {
                                var f = t[y++];
                                f ? (e = c[f], g = h[f], g.inSync ? !e || e.deleted ? (delete h[f], q(a)) : e && (g.updated && e.updatedTime == g.updatedTime ? b.updateServerObj(g, function(d) {
                                    if (d) if (!d.error && d.id) b._takeFromServer(d, f, h);
                                    else {
                                        var e = ~d.error.indexOf(f),
                                            d = ~d.error.indexOf("is not found");
                                        if (e && d) {
                                            delete h[f];
                                            delete c[f];
                                            q(a);
                                            return
                                        }
                                    }
                                    q(a)
                                }) : ((e.updatedTime > g.updatedTime || !g.updatedTime) && b._takeFromServer(e, f, h), q(a))) : g.deleted ? e && !e.deleted ? b.removeServerObj(e.id, function(d) {
                                    d && !d.error && (delete c[f], delete h[f], nokia.mh5.event.fire(b, "object_deleted", {
                                        objectType: b.objectType,
                                        id: f
                                    }));
                                    q(a)
                                }) : (delete h[f], q(a)) : e ? (e.deleted ? delete h[f] : !e.deleted && !g.deleted && b._takeFromServer(e, f, h), q(a)) : b.addServerObj(g, function(d) {
                                    if (d && !d.error && d.id) {
                                        b._takeFromServer(d, f, h);
                                        if (f != d.id) h[d.id] = h[f], h[d.id].inSync = !0, delete h[f], nokia.mh5.event.fire(b, "object_created", {
                                            oldId: f,
                                            newId: d.id
                                        });
                                        h[d.id].id = d.id
                                    }
                                    q(a)
                                })) : a && a()
                            };
                        q(function() {
                            for (var d in c) e = c[d], g = h[d], !e.deleted && !g && b._takeFromServer(e, d, h);
                            b.updateState();
                            a && a()
                        })
                    }
                })
            } else a && a()
        },
        shouldSync: function() {
            return !d && nokia.mh5.sso.isAuthenticated()
        },
        setAsyncMode: function() {
            this.asyncProcedure("synchronize")
        },
        asyncProcedure: function(a) {
            var b = this,
                c = b[a];
            d = !0;
            b[a] = function() {
                var e = arguments;
                b[a] = c;
                setTimeout(function() {
                    d = !1;
                    c.apply(b, e)
                })
            }
        },
        synchronize: function(a) {
            var b = this;
            this._queue(this._synchronize, null, function() {
                a && a();
                nokia.mh5.event.fire(b, "synchronized")
            }, 3E4)
        },
        clear: function(a) {
            var b = this.getState(),
                d;
            for (d in b) b.hasOwnProperty(d) && (!a || !b[d].inSync) && delete b[d];
            this.updateState()
        },
        deleteFromServer: function(a) {
            var b = this.get(),
                d = 0;
            0 == b.length ? a && a.call(this) : b.forEach(function(c) {
                this.remove(c, function() {
                    ++d == b.length && a && a.call(this)
                })
            }.bind(this))
        },
        add: function(b, d) {
            var c = this.getState(),
                e = b.id,
                h = !1,
                i, j = this;
            e || (e = this._generateID(this.prefix), h = !0);
            c[e] = g(a(b));
            c[e].inSync = !1;
            c[e].id = e;
            i = this.updateState();
            this.shouldSync() ? this.addServerObj(b, function(a) {
                if (a && !a.error && a.id) {
                    if (h) c[a.id] = c[e], delete c[e], nokia.mh5.event.fire(j, "object_created", {
                        oldId: e,
                        newId: a.id
                    }), e = a.id;
                    c[e] = this.mapServerToClient(a);
                    c[e].inSync = !0;
                    c[e].id = e;
                    this.updateState();
                    d && d(c[e])
                } else d && d({
                    error: !0
                })
            }.bind(this)) : d && d(c[e]);
            return i
        },
        remove: function(a, b) {
            var d = this.getState(),
                c = this._findObject(a, d, !1),
                e = !1;
            if (c) {
                !c.inSync && !c.deleted ? (delete d[c.id], e = !0) : (c.deleted = !0, c.inSync = !1);
                var h = c.id;
                this.updateState();
                this.shouldSync() && !e ? this.removeServerObj(h, function(a) {
                    a && !a.error && (delete d[h], this.updateState());
                    b && b(a)
                }.bind(this)) : (e && (c = null), b && b(c))
            } else b && b()
        },
        get: function(a) {
            var b = [],
                d = this.getState(),
                c;
            for (c in d) d.hasOwnProperty(c) && (!a || !d[c].deleted) && b.push(d[c]);
            return b
        },
        updateState: function() {
            if (!this.state) this.state = {};
            return c(this.objectType, a(this.state))
        },
        initState: function() {
            return this.state = g(b(this.objectType) || "{}")
        },
        getState: function(a) {
            if (this.state) return a ? this.state[a] : this.state;
            this.initState();
            return a ? this.state[a] : this.state
        },
        update: function(a, b) {
            if (!a.id) throw "invalid object was passed to update";
            var d = this.getState(),
                c = this.get().filter(function(b) {
                    return b && b.id == a.id
                }),
                e, h;
            if (0 == c.length) b && b({
                error: !0
            });
            else {
                c = c[0];
                nokia.mh5.extend(c, a);
                h = c.id;
                d[h] = c;
                if (c.inSync) return d[h].updated = !0, e = this.updateState(), this.shouldSync() ? this.updateServerObj(a, function(a) {
                    if (a && !a.error && a.id) nokia.mh5.extend(c, this.mapServerToClient(a)), d[h] = c, d[h].inSync = !0, d[h].updated = !1, this.updateState();
                    b && b(a)
                }.bind(this)) : b && b(d[h]), e;
                d[h].updated = !1;
                b && b(d[h]);
                this.updateState()
            }
        },
        getSyncTimestamp: function() {
            this.syncs = this.syncs || g(b("syncs") || "{}");
            var a = this.syncs[this.objectType];
            a || (a = null);
            return a
        },
        setSyncTimestamp: function(b) {
            if (!this.syncs) this.syncs = {};
            this.syncs[this.objectType] = b;
            return c("syncs", a(this.syncs))
        },
        addServerObj: function(a, b) {
            this.callServer.call(this, {
                action: "add=" + encodeURIComponent(JSON.stringify(this.mapClientToServer(a))),
                objectTypes: this.objectTypes
            }, b)
        },
        updateServerObj: function(a, b) {
            this.callServer.call(this, {
                action: "update=" + encodeURIComponent(JSON.stringify(this.mapClientToServer(a))),
                objectTypes: this.objectTypes
            }, b)
        },
        removeServerObj: function(a, b) {
            this.callServer.call(this, {
                action: "delete=" + encodeURIComponent(a),
                objectTypes: this.objectTypes
            }, b)
        },
        listServerObjs: function(b) {
            var d = this,
                c = d.getSyncTimestamp(),
                e = {
                    action: "list",
                    objectTypes: this.objectTypes
                },
                h = function(a, b) {
                    for (var d in a) a.hasOwnProperty(d) && b(a[d], d)
                };
            c && nokia.mh5.extend(e, {
                deletedSince: c
            });
            this.callServer.call(this, e, function(e) {
                if (e.data) if (e.data.forEach(function(a, b) {
                    if (a.object) e.data[b] = a.object
                }), c) {
                    c = d.getSyncTimestamp();
                    var i = g(a(d.getState())),
                        j = [],
                        n = {};
                    e.data.forEach(function(a) {
                        if (a.updatedTime && a.updatedTime > c) c = a.updatedTime;
                        n[a.id] = a
                    });
                    h(i, function(a, b) {
                        !n[b] && a.inSync && j.push(a)
                    });
                    h(n, function(a) {
                        j.push(a)
                    });
                    d.setSyncTimestamp(c);
                    e.data = j
                } else e.data.forEach(function(a) {
                    if (a.updatedTime && a.updatedTime > c) c = a.updatedTime
                }), d.setSyncTimestamp(c);
                b.call(this, e)
            })
        }
    }
})();
nokia.mh5.provide("nokia.mh5.components.favourites");
(function() {
    var g = JSON.stringify,
        a = nokia.mh5.utils.setLocalStorageValue,
        b = nokia.mh5.components.sync;
    nokia.mh5.components.favourites = b.extend({
        changedFavourite: null,
        objectType: "favourites",
        objectTypes: "favoritePlace",
        prefix: "FAV",
        _findFavourite: function(a, b, g) {
            var h = a.placeId,
                d;
            for (d in b) if (b.hasOwnProperty(d)) {
                var j = b[d];
                if (j && !j.deleted && (h ? j.placeId === h : a.latitude === j.latitude && a.longitude === j.longitude)) return g ? {
                    id: d,
                    fav: j
                } : j
            }
        },
        _findObject: function() {
            return this._findFavourite.apply(this, Array.prototype.slice.call(arguments).concat(!0))
        },
        _fromPlace: function(a) {
            return {
                address: a.address,
                addressDetails: a.addressDetails,
                categoryGroup: a.categoryGroup,
                latitude: a.latitude,
                longitude: a.longitude,
                name: a.name,
                placeId: a.id || a.placeId,
                ratingCount: a.ratingCount,
                ratingValue: a.ratingValue
            }
        },
        add: function(a, e) {
            a.favourite = !0;
            b.add.call(this, this._fromPlace(a), e);
            nokia.mh5.components.favourites.changedFavourite = a;
            return !0
        },
        get: function(a) {
            var b = this.getState(),
                g = [],
                h;
            for (h in b) if (b.hasOwnProperty(h)) {
                var d = b[h];
                delete d.categoryIcon;
                d.favourite = !0;
                var j = d.categoryGroup;
                if (d.categories && d.categories[0] && d.categories[0].categoryId) j = d.categories[0].categoryId;
                d.icon = nokia.mh5.utils.place.getCategoryIconForFav(j)
            }
            if (a) Array.isArray(a) ? a.forEach(function(a) {
                (a = this._findFavourite(a, b)) && g.push(a)
            }, this) : g = this._findFavourite(a, b);
            else for (var f in b) b.hasOwnProperty(f) && !b[f].deleted && g.push(b[f]);
            g && 0 < g.length && g.sort(this.sortFunction);
            return g
        },
        set: function(b) {
            var e = this.getState(),
                i = this._findFavourite(b, e, !0);
            if (!i || !i.placeId) return !1;
            e[i.placeId] = this._fromPlace(b);
            return a("favourites", g(e))
        },
        remove: function(a, e) {
            b.remove.call(this, a, e);
            delete a.favourite;
            nokia.mh5.components.favourites.changedFavourite = a
        },
        mapServerToClient: function(a) {
            var b = a.location || {},
                g = b.position || {},
                b = b.address ? b.address.text ? b.address.text : nokia.mh5.adapters.Search.formatAddress(b.address) : null,
                g = {
                    id: a.id,
                    name: a.name,
                    latitude: g.latitude || null,
                    longitude: g.longitude || null,
                    collectionIds: a.collectionId || [],
                    address: b,
                    favourite: !0,
                    updatedTime: a.updatedTime
                };
            if (a.placesId && (g.placeId = a.placesId, a.categories && a.categories.length)) g.categoryGroup = a.categories[0].categoryId;
            return g
        },
        mapClientToServer: function(a) {
            var b = {
                type: "favoritePlace",
                name: a.name,
                location: {
                    position: {
                        latitude: parseFloat(a.latitude),
                        longitude: parseFloat(a.longitude)
                    },
                    address: a.addressDetails
                }
            };
            b.location.address = b.location.address || {};
            b.location.address.text = a.address;
            if (a.placesId) b.placesId = a.placesId, b.categories = [{
                categoryId: a.categoryGroup
            }];
            if (a.placeId) b.placesId = a.placeId, b.categories = [{
                categoryId: a.categoryGroup
            }];
            return b
        },
        favouritize: function(a) {
            var b = this;
            Array.isArray(a) && a.forEach(function(a) {
                if (b.get(a)) a.favourite = !0
            });
            return a
        },
        sortFunction: function(a, b) {
            var g = a.name ? a.name.toLowerCase() : "",
                h = b.name ? b.name.toLowerCase() : "";
            return g > h ? 1 : g < h ? -1 : 0
        }
    })
})();
nokia.mh5.provide("nokia.mh5.geolocation");
nokia.mh5.geolocation = function(g, a) {
    function b() {
        x && y.clearWatch(x);
        q = x = 0
    }
    function c(b) {
        a.fire(t, b, H)
    }
    function e(a) {
        var b = !q;
        q = 1;
        s = k;
        H = a;
        F = a.coords;
        c(b ? h : d)
    }
    function i() {
        b();
        try {
            x = y.watchPosition(e, function(a) {
                q ? c(f, b(), s = n) : 2 < a.code ? setTimeout(i, 250) : c(j, b(), s = l)
            }, {
                enableHighAccuracy: o,
                timeout: u,
                maximumAge: w
            })
        } catch (a) {
            s = m, c(j, b())
        }
    }
    var h = "positionactivate",
        d = "positionchange",
        j = "positionerror",
        f = "positionlost",
        k = "active",
        m = "denied",
        n = "lost",
        l = "error",
        o = !0,
        u = 6E4,
        w = 1E4,
        v = Object.defineProperty,
        y = nokia.mh5.win.navigator.geolocation,
        t = {},
        q = 0,
        s = y ? "inactive" : "disabled",
        x = 0,
        r = "complete" == document.readyState,
        J, F, H;
    v(t, "enableHighAccuracy", {
        get: function() {
            return o
        },
        set: function(a) {
            o !== a && (o = null == a ? !0 : !! a, q && i())
        }
    });
    v(t, "timeout", {
        get: function() {
            return u
        },
        set: function(a) {
            u !== a && (u = null == a ? 6E4 : a, q && i())
        }
    });
    v(t, "maximumAge", {
        get: function() {
            return w
        },
        set: function(a) {
            w !== a && (w = null == a ? 1E4 : a, q && i())
        }
    });
    v(t, "latitude", {
        get: function() {
            return q && F.latitude
        }
    });
    v(t, "longitude", {
        get: function() {
            return q && F.longitude
        }
    });
    v(t, "available", {
        get: function() {
            return !!q
        }
    });
    v(t, "status", {
        get: function() {
            return s
        }
    });
    v(t, "coords", {
        get: function() {
            return F
        }
    });
    v(t, "deactivate", {
        value: function() {
            q && (b(), s = "inactive", c("positiondeactivate"))
        }
    });
    v(t, "activate", {
        value: function(a) {
            if (!(q || "disabled" === s)) {
                s = "waiting";
                a || (a = {});
                if (!r) return J = a;
                var b = a.enableHighAccuracy;
                o = null == b ? !0 : !! b;
                b = a.timeout;
                u = null == b ? 6E4 : b;
                a = a.maximumAge;
                w = null == a ? 1E4 : a;
                i()
            }
        }
    });
    v(t, "disable", {
        value: function() {
            q && b();
            s = "disabled"
        }
    });
    r || a.add(g, "DOMContentLoaded", function D() {
        r = !0;
        a.remove(g, "DOMContentLoaded", D);
        J && t.activate(J)
    });
    a.add(g, "beforeunload", b);
    a.add(g, "unload", b);
    return t
}(nokia.mh5.win, nokia.mh5.event);
nokia.mh5.provide("nokia.mh5.math");
(function() {
    function g(a, h) {
        var f = a.longitude * b,
            g = a.latitude * b,
            m = h.longitude * b,
            n = h.latitude * b,
            f = c(g) * c(n) + e(g) * e(n) * e(f - m);
        1 < f && (f = 1); - 1 > f && (f = -1);
        return i(f)
    }
    var a = Math.PI,
        b = a / 180,
        c = Math.sin,
        e = Math.cos,
        i = Math.acos,
        h = nokia.mh5.math = {
            bearing: function(d, h) {
                var f = d.longitude * b,
                    k = h.longitude * b,
                    m = d.latitude * b,
                    n = h.latitude * b,
                    l = g(d, h),
                    m = l ? (c(n) - c(m) * e(l)) / (c(l) * e(m)) : 1;
                1 < m && (m = 1); - 1 > m && (m = -1);
                return 0 <= c(k - f) ? i(m) : 2 * a - i(m)
            },
            pointDistance: function(a, b) {
                return 6371E3 * g(a, b)
            },
            segmentDistance: function(a, b, f) {
                var e = h.bearing(b, a),
                    i = h.bearing(b, f),
                    n = g(b, f),
                    f = g(f, a),
                    a = g(b, a);
                return n < 1 / 6371E3 ? 6371E3 * a : 0 === a || 0 === f ? 0 : 0 > (a * a + n * n - f * f) / (2 * a * n) || 0 > (n * n + f * f - a * a) / (2 * n * f) ? -1 : 6371E3 * Math.abs(Math.asin(c(a) * c(e - i)))
            },
            speed: function(a, b) {
                return 1E3 * h.pointDistance(a.coords, b.coords) / (b.timestamp - a.timestamp)
            }
        }
})(this);
nokia.mh5.provide("nokia.mh5.adapters.Search");
(function() {
    var g = nokia.mh5.i18n,
        a = nokia.mh5.utils,
        b = nokia.mh5.geolocation,
        c = Object.prototype.hasOwnProperty;
    nokia.mh5.adapters.Search = {
        merge: function(a, b) {
            for (var h in b) c.call(b, h) && ("object" === nokia.mh5.type(a[h]) && "object" === nokia.mh5.type(b[h]) ? b[h] !== a[h] && b[h] !== a && (a[h] = nokia.mh5.adapters.Search.merge(a[h], b[h])) : void 0 === a[h] && (a[h] = b[h]));
            return a
        },
        formatAddress: function(a) {
            if (!a) return "";
            var b = a.addrCountryCode || a.countryCode,
                c = a.addrCountryName || a.country || b,
                d = a.addrCityName || a.city,
                g = d,
                f = a.addrStateCode || a.state,
                k = a.addrPostalCode || a.postCode,
                m = a.addrStreetName || a.thoroughfare && a.thoroughfare.name,
                a = a.addrHouseNumber || a.thoroughfare && a.thoroughfare.number,
                b = b && -1 < "USA CAN NZL IND GBR AUS IRL FRA LKA".indexOf(b),
                n = [];
            m && (a ? n.push(b ? a + " " + m : m + " " + a) : n.push(m));
            d && (b ? (f && (g += ", " + f), k && (g += " " + k), n.push(g)) : n.push(k ? k + " " + d : d));
            c && n.push(c);
            return n.join(", ")
        },
        map: function(a, b) {
            var c = nokia.mh5.math.pointDistance,
                c = {
                    address: b.vicinity,
                    placeId: b.id,
                    icon: b.icon,
                    href: b.href,
                    categoryName: b.category.id,
                    latitude: b.position[0],
                    longitude: b.position[1],
                    distance: a && c(a, {
                        latitude: b.position[0],
                        longitude: b.position[1]
                    }),
                    name: b.title,
                    ratingValue: b.averageRating
                };
            if (b.bbox) c.boundingBox = [{
                latitude: b.bbox[3],
                longitude: b.bbox[0]
            }, {
                latitude: b.bbox[1],
                longitude: b.bbox[2]
            }];
            if (nokia.mh5.components.favourites.get(c)) c.favourite = !0;
            return c
        },
        fetch: function(c, i, h, d) {
            var j = nokia.mh5,
                f = j.adapters.Search,
                k = f.merge,
                m, n, l = i && i.appId || j.appId,
                o = i && i.appCode || j.appCode;
            if (a.isPlace(c)) if (m = "placeId=" + c.placeId, n = a.cacheObject(m)) k(c, n), h(c);
            else {
                if (!l || !o) throw Error(g("Error.applicationCredential"));
                i = {
                    app_id: l,
                    app_code: o,
                    ScreenSize: j.win.innerWidth + "x" + j.win.innerHeight,
                    lang: nokia.mh5.i18n.language
                };
                c.href ? i.placeUrl = c.href : i.place = c.placeId;
                if (b.available) i.geolocation = "geo:".concat(b.latitude, ",", b.longitude, ";u=", b.coords.accuracy);
                j.jsonp("http://m.here.com/releases/1.8.44/server/index.php?" + a.formatURLParams(i) + "&jsonp", function(b) {
                    if (b && b.name && b.latitude && b.longitude) {
                        k(c, b);
                        var f = nokia.mh5.components.favourites.get(c);
                        if (f) c.favourite = !0, f.categoryGroup !== b.categoryGroup && nokia.mh5.components.favourites.set(b);
                        a.cacheObject(m, a.purify(c));
                        h(c)
                    } else d && d(b.error), a.cacheObject(m, null)
                }, 2E4)
            } else if (!c.longitude || !c.latitude) d && d();
            else if (m = "lat=" + c.latitude + "&lon=" + c.longitude, n = a.cacheObject(m)) k(c, n), h(c);
            else {
                c.name = c.name || c.address;
                if (j = nokia.mh5.components.favourites.get(c)) c.favourite = !0, j.categoryGroup !== c.categoryGroup && nokia.mh5.components.favourites.set(c);
                c.name ? (a.cacheObject(m, a.purify(c)), h(c, !0)) : f.reverseGeoCode(c, i, function(b) {
                    c.name = c.address = b.name;
                    a.cacheObject(m, a.purify(c));
                    h(c)
                })
            }
        },
        getRecommendations: function(c, i, h, d) {
            var j = nokia.mh5,
                f = j.adapters.Search.merge,
                k, m;
            m = i && i.appId || j.appId;
            var n = i && i.appCode || j.appCode;
            if (!c.longitude || !c.latitude) d && d();
            else if (k = c.placeId ? "placeId=" + c.placeId : "lat=" + c.latitude + "&lon=" + c.longitude, (d = a.cacheObject(k)) && d.recommendations) f(c, d), h(d);
            else {
                if (!m || !n) throw Error(g("Error.applicationCredential"));
                m = {
                    app_id: m,
                    app_code: n,
                    lat: c.latitude,
                    lon: c.longitude
                };
                if (c.placeId) m.place = c.placeId;
                if (i && i.init) m.init = "true";
                if (b.available) m.geolocation = "geo:".concat(b.latitude, ",", b.longitude, ";u=", b.coords.accuracy);
                return j.jsonp("http://m.here.com/releases/1.8.44/server/index.php?" + a.formatURLParams(m) + "&jsonp", function(b) {
                    f(c, b);
                    i && !i.init && a.cacheObject(k, a.purify(c));
                    h(c)
                }, 5E3)
            }
        },
        search: function(c, i, h, d) {
            nokia.mh5.each(i, function(a, b) {
                "function" === typeof a && (i[b] = a())
            });
            var j = i.center || i.map.center,
                f = i.box || i.map.box,
                k = f[0],
                f = f[1],
                m = i.position || i.map && i.map.position,
                n = i.suggestions,
                l = "http://places.nlp.nokia.com/places/v1/" + (n ? "suggest/" : "discover/search/"),
                o = i.appId || nokia.mh5.appId,
                u = i.appCode || nokia.mh5.appCode;
            if (!o || !u) throw Error(g("Error.applicationCredential"));
            c = {
                app_code: u,
                app_id: o,
                q: c,
                at: j.latitude + "," + j.longitude,
                size: i.limit || (n ? 4 : 25),
                tf: "plain"
            };
            k.longitude && f.latitude && f.longitude && k.latitude && (c["X-Map-Viewport"] = "".concat(k.longitude, ",", f.latitude, ",", f.longitude, ",", k.latitude));
            if (b.available) c.geolocation = "geo:".concat(b.latitude, ",", b.longitude, ";u=", b.coords.accuracy);
            nokia.mh5.jsonp(l + "?" + a.formatURLParams(c) + "&callback", function(a) {
                if (a.error) {
                    if (d) {
                        var b;
                        "timeout" === a.error && (b = g("Notification.searchProblem"));
                        d(b)
                    }
                } else if (n) h(a.suggestions);
                else {
                    var a = a.results.items || [],
                        f, a = a.map(this.map.bind(this, m));
                    i.map && 0 < a.length && (f = this._getBoundingBox(a, i.map));
                    h({
                        results: a,
                        box: f
                    })
                }
            }.bind(this), 3E4)
        },
        getSuggestions: function(a, b, c, d) {
            var g = b.suggestions;
            b.suggestions = !0;
            this.search(a, b, c, d);
            b.suggestions = g
        },
        reverseGeoCode: function(a, b, c, d) {
            var j = b && b.appId || nokia.mh5.appId,
                b = b && b.appCode || nokia.mh5.appCode;
            if (!j || !b) throw Error(g("Error.applicationCredential"));
            nokia.mh5.jsonp("http://geo.nlp.nokia.com/search/6.2/reversegeocode.json".concat("?token=" + b + "&app_id=" + j, "&prox=", a.latitude, ",", a.longitude, "&mode=retrieveAddresses&jsoncallback"), function(a) {
                var b, e;
                !a.error && a.Response && a.Response.View && a.Response.View[0] && a.Response.View[0].Result && a.Response.View[0].Result[0] ? (a = a.Response.View[0].Result[0], b = a.Location.DisplayPosition, e = a.Location.Address.Label, c({
                    name: e,
                    address: e,
                    latitude: b.Latitude,
                    longitude: b.Longitude,
                    properties: a.Location.Address
                })) : d && ("timeout" === a.error && (b = g("Notification.searchProblem")), d(b))
            }, 1E4)
        },
        _getBoundingBox: function(a, b) {
            var c = a[0].boundingBox,
                d = [];
            if (!c) {
                for (var g = 0, f = a.length; g < f; g++) c = a[g], c.hasOwnerContent || d.push(c);
                d.push(b.center);
                c = b._map.getZoomLevelFor(d);
                b.covers(d) ? 17 > c && 17 > b.zoom ? c = d : (b.zoom = 16, c = b.box) : 12 <= c ? c = d : (b.zoom = 12, b.center = d[0], c = b.box)
            }
            return c
        }
    }
})();
nokia.mh5.provide("nokia.mh5.internals.Map");
nokia.mh5.internals.Map = function(g) {
    function a(a) {
        var b = 0,
            d = 0;
        do b += a.offsetLeft, d += a.offsetTop;
        while (a = a.offsetParent);
        return {
            x: b,
            y: d
        }
    }
    function b(a, b) {
        var d = nokia.mh5.event,
            c = d.add,
            f, e, h, k = g.navigator.msPointerEnabled ? "touchstart" : "down";
        c(a, k, function jc(l) {
            d.remove(a, k, jc);
            f = d.isTouch || g.navigator.msPointerEnabled;
            b.init(f ? "touch" : "mouse");
            f ? (e = b.touch, h = b.gesture, g.navigator.msPointerEnabled ? (c(a, Va, e.start), c(a, Wa, e.move), c(a, Xa, e.end)) : (c(a, "down", e.start), c(a, "move", e.move), c(a, "up", e.end)), c(a, Nb, h.start), c(a, Da, h.change), c(a, wa, h.end), e.start(l)) : (e = b.mouse, c(a, "down", e.down), c(a, "move", e.move), c(a, "up", e.up), c(a, kc, e.wheel), c(a, lc, e.wheel), e.down(l));
            d = c = f = e = h = null
        })
    }
    function c(a, b, d) {
        function c(a, b, d, g, k, l, i, j, C, B, A, n) {
            var i = i + (j - i) * A,
                m = O(a + i * C),
                z = O(b + i * B);
            m != k || z != l ? (h.move(m - d, z - g), e = o(c, n, a, b, m, z, k, l, i, j, C, B, A, n)) : f(h.end())
        }
        function f() {
            u(e);
            e = 0
        }
        var e = 0,
            h = {
                kick: function(a, b, d, g) {
                    var d = 9 * d,
                        k = 9 * g,
                        g = Y(d * d + k * k),
                        d = d / g,
                        k = k / g,
                        l = !0;
                    e && f();
                    !w(d) && !w(k) ? (h.start(), c(a, b, a, b, O(a + g * d), O(b + g * k), 0, g, d, k, 0.2, 17)) : l = !l;
                    return l
                },
                stop: f,
                start: a || H,
                move: b || H,
                end: d || H
            };
        return h
    }
    function e(e, i, B) {
        var n, m, w, t, r, Y;

        function x(a) {
            Ra && Ob(a || p[Z])
        }
        function I() {
            1 === na && F(oa, ra)
        }
        function F(a, b) {
            var d = oa = a,
                c = ra = b,
                d = d + n,
                c = c + m,
                f = !! Ya,
                e = f && Ya.length,
                h = ia.add,
                g = ~~ (d / G),
                k = ~~ (c / G),
                l = d % G,
                j = c % G,
                c = pa - l,
                d = qa - j,
                o, C, g = g - (l = P(c / G)),
                k = k - (j = P(d / G)),
                c = c - G * l,
                d = d - G * j;
            E.clear();
            for (ia.clear(); c < i;) {
                j = d;
                for (l = k; j < B;) {
                    h("".concat(g, "-", l, "-", T, "-", Ea, "-", p._retina ? "x2" : ""), g, l, c, j);
                    if (f) for (o = 0; o < e;)(C = Ya[o](g, l, xa, T, U, Ea)) && h(C, g, l, c, j, C), ++o;
                    j += G;
                    ++l
                }
                c += G;
                ++g
            }
            Fa && ya.call(Wa(), Ta);
            za && ya.call(mc(), wa);
            Pb()
        }
        function ca(a, b, d, c) {
            E.strokeStyle = a || vb;
            E.lineWidth = b || wb;
            E.lineCap = d || fb;
            E.lineJoin = c || fb;
            p.retina && (E.lineWidth *= 2)
        }
        function ha(a, b) {
            for (var d = a.length, c = 2 * d, f = new Qb(c), e; d--;) e = da(a[d], b), f[--c] = e.y, f[--c] = e.x;
            return f
        }
        function Ua(a, b) {
            for (var d = a.length, c = new Qb(d), f; d--;) f = {}, f[$] = a[d], f[aa] = a[d - 1], f = da(f, b), c[d--] = f.y, c[d] = f.x;
            return c
        }
        function hc(a, b, d) {
            for (var c = "", f, e; d--;) f = 0, e = 1 << d, 0 !== (a & e) && f++, 0 !== (b & e) && (f += 2), c += f;
            return c
        }
        function tb() {
            return null != oa && (ja = Za({
                x: oa,
                y: ra
            }, U))
        }
        function Ob(a) {
            if (a) {
                var b = da(a, U);
                Ra = !F(b.x, b.y);
                ja = {};
                ja[aa] = a[aa];
                ja[$] = a[$];
                j(p, "centerset", ja)
            }
        }
        function Qa(a, b) {
            "shape" in a && (a = a.shape);
            for (var d = ea, c = G << ea, f = [], e = [], h = 0, g = 0, k = a.length, l, j, o = p.geometry.top, A = p.geometry.left, o = 0 > i - o ? i : i - o, A = 0 > B - A ? B : B - A; h < k; ++h) V(l = a[h]) && (l = {
                latitude: l,
                longitude: a[++h]
            }), j = da(l, c), f[g] = j.x, e[g++] = j.y;
            h = z.apply(D, f);
            g = z.apply(D, e);
            k = C.apply(D, f);
            l = C.apply(D, e);
            k = f = k - h;
            for (l = e = l - g; A < l || o < k;) l /= 2, k /= 2, --d;
            if (b) p[Z] = Za({
                x: f / 2 + h,
                y: e / 2 + g
            }, c), p.zoom = d;
            return d <= ea && Ga <= d ? d : 0
        }
        function ub(a) {
            this.width = a;
            this._int32Vector = []
        }
        function ib(a) {
            for (var b = G << T, d = da(a[0], b), b = da(a[1], b), d = ((b.x / G | 0) + 1 - (d.x / G | 0)) * ((b.y / G | 0) + 1 - (d.y / G | 0)), a = T, b = d; a++ < ea && (b += d <<= 2) < ib.max;);
            return --a
        }
        function xb(a) {
            var b = !Aa;
            Aa = "online" == a.type;
            ga = L.src = Aa ? $a.settings.defaultImage || yb.settings.defaultImage : nokia.mh5.assetsPath + "img/empty_tile_offline.png";
            b && (ia.clear(), ia.gc(), x())
        }
        function jb(a, b, d, c, f, e, h, g) {
            return (g - b) * (f - a) > (e - b) * (h - a) != (g - c) * (f - d) > (e - c) * (h - d) && (e - b) * (d - a) > (c - b) * (f - a) != (g - b) * (d - a) > (c - b) * (h - a)
        }
        function wa(a) {
            var b = a.shape,
                d = a.style,
                a = oa - pa,
                c = ra - qa,
                f = i + a,
                e = B + c,
                h = 0,
                g = 0,
                k = b.length,
                l, j, o;
            ca(d.color, d.width, d.cap, d.join);
            for (E.beginPath(); h < k;) {
                d = b[h];
                l = b[h + 1];
                switch (!0) {
                case a <= d && c <= l && d <= f && l <= e:
                    g && (E.moveTo(b[h - 2] - a, b[h - 1] - c), g = 0);
                case !g++:
                    h ? E.lineTo(d - a, l - c) : E.moveTo(d - a, l - c);
                    break;
                case jb(j = b[h - 2], o = b[h - 1], d, l, a, c, f, e):
                case jb(j, o, d, l, f, c, a, e):
                    E.moveTo(j - a, o - c), E.lineTo(d - a, l - c), g = 0
                }
                h += 2
            }
            E.stroke()
        }
        function mc() {
            ab[T] || ya.call(za, nc, ab[T] = []);
            return ab[T]
        }
        function kb(a) {
            return a && aa in a && $ in a && !a.shape
        }
        function nc(a, b) {
            var d = V(a[0]) || kb(a[0]) ? a : a.shape;
            ab[T][b] = {
                style: a == d ? 0 : a,
                shape: V(d[0]) ? Ua(d, U) : ha(d, U)
            }
        }
        function oc(a) {
            var a = a.shape || a,
                b = this.x,
                d = this.y,
                c = a.length,
                f = 0,
                e = !1,
                h, g, k, l, i, j, o;
            k = a[c - 2];
            for (l = a[c - 1]; f < c;) h = a[f++], g = a[f++], h > k ? (i = k, o = h, j = l, l = g) : (i = h, o = k, j = g), h < b == b <= k && (d - j) * (o - i) < (l - j) * (b - i) && (e = !e), k = h, l = g;
            return e
        }
        function Ta(a) {
            for (var b = a.shape, a = a.style, d = oa - pa, c = ra - qa, f = i + d, e = B + c, h = 0, g = b.length, k, l, j, o; h < g;) {
                k = b[h];
                l = b[h + 1];
                if (d <= k && c <= l && k <= f && l <= e || jb(j = b[h - 2], o = b[h - 1], k, l, d, c, f, e) || jb(j, o, k, l, f, c, d, e)) {
                    E.beginPath();
                    E.fillStyle = a.color || "rgba(100,100,100,.1)";
                    E.moveTo(b[0] - d, b[1] - c);
                    for (h = 2; h < g;) E.lineTo(b[h] - d, b[h + 1] - c), h += 2;
                    E.fill();
                    E.fillStyle = zb;
                    break
                }
                h += 2
            }
        }
        function Va(a, b) {
            return Ha[T][b].shape.length != (a.shape || a).length
        }
        function Wa() {
            if (!Ha[T] || Ab.call(Fa, Va).length) ya.call(Fa, Xa, Ha[T] = []);
            return Ha[T]
        }
        function Xa(a, b) {
            var d = V(a[0]) || kb(a[0]) ? a : a.shape;
            Ha[T][b] = {
                origin: Fa[b],
                style: a == d ? 0 : a,
                shape: V(d[0]) ? Ua(d, U) : ha(d, U)
            }
        }
        function da(a, b) {
            var d = a[$] / 360 + 0.5,
                c = z(1, C(0, 0.5 - A(W(Ca + M * a[aa] / 180)) / K / 2));
            return {
                x: O(d * b),
                y: O(c * b)
            }
        }
        function Za(a, b) {
            var d = a.x / b,
                c = a.y / b,
                f = {};
            f[aa] = 0 >= c ? 90 : 1 <= c ? -90 : N * (2 * S(va(K * (1 - 2 * c))) - M);
            f[$] = 360 * (1 === d ? 1 : (d % 1 + 1) % 1) - 180;
            return f
        }
        var Ia = pc(),
            ta = e.appendChild(ba()),
            E = ta.getContext("2d"),
            ua = a(ta);
        r = 0;
        Y = 0;
        w = 0;
        t = 0;
        n = 0;
        m = 0;
        var p = {},
            Da = 0,
            Ra = 0,
            na = 1,
            Aa = v.onLine,
            Ba = !0,
            Ja = !0,
            bb = 0,
            za = null,
            Ya = null,
            ab = [],
            vb = Rb,
            zb = "rgba(0,0,0,1)",
            wb = 9,
            fb = "round",
            Bb = 0,
            Cb = 0,
            cb = "%[1-4]%.maps.nlp.nokia.com",
            db = "maptile",
            Db = "newest",
            Fa = null,
            gb, Ha, oa, ra, ja, U, T, Ea, xa, pa, qa, Ka, La, ia, $a, yb, lb, Pb, sa, Eb, Sa, X, R, Fb, Ma, ka, Sb, Gb = "?",
            mb;
        try {
            E.mozImageSmoothingEnabled = !1
        } catch (Nb) {}
        s(p, "box", ja = {
            get: function() {
                var a = da(p[Z], U),
                    b;
                a.x -= pa;
                a.y -= qa;
                b = Za(a, U);
                a.x += i;
                a.y += B;
                a = Za(a, U);
                return [b, a]
            },
            set: function(a) {
                Qa(a, !0)
            }
        });
        s(p, "bbox", ja);
        s(p, "apiKey", {
            set: function(a) {
                Gb = "?app_id=" + a.appId + "&token=" + a.appCode
            },
            get: function() {
                return Gb
            }
        });
        s(p, Z, ja = {
            get: function() {
                return ja || tb()
            },
            set: Ob
        });
        s(p, "centre", ja);
        ja = 0;
        ka = {
            resetDefault: function() {
                ka.defaultPrevented = !1
            },
            preventDefault: function() {
                ka.defaultPrevented = !0
            }
        };
        s(p, "geoToPoint", {
            value: function(a) {
                return da(a, U)
            }
        });
        s(p, "getZoomLevelFor", {
            value: Qa
        });
        s(p, "layer", {
            get: function() {
                return Ya
            },
            set: function(a) {
                Ya = a && [].concat(a)
            }
        });
        s(p, "move", {
            value: function(a, b) {
                F(oa + a, ra + b);
                (a || b) && (ja = 0)
            }
        });
        ub.prototype.set = function(a, b, d) {
            var c, f, e, h;
            for (c = 0; c < d; c++) for (f = 0; f < d; f++) e = a + c, h = b + f, e = h * this.width + e, h = e >> 5, this._int32Vector[h] |= 1 << e - (h << 5)
        };
        ub.prototype.get = function(a, b) {
            a = b * this.width + a;
            b = a >> 5;
            return this._int32Vector[b] & 1 << a - (b << 5)
        };
        ib.max = 1200;
        s(p, "maxStorableZoom", {
            value: function(a) {
                a || (a = p.box);
                return ib(a)
            }
        });
        s(p, "areaToTiles", {
            value: function(a) {
                a || (a = p.box);
                var b = a,
                    d = T,
                    a = ib(a),
                    d = C(d, Ga),
                    a = z(a, ea),
                    c = [],
                    f = [4, 3, 2, 1],
                    e = G << d,
                    h = da(b[0], e),
                    g = da(b[1], e),
                    b = h.x / G | 0,
                    h = h.y / G | 0,
                    e = (g.x / G | 0) + 1,
                    g = (g.y / G | 0) + 1,
                    k = e - b,
                    l = g - h,
                    i, j, o, B, A;
                for (B = d; B <= a; B++) {
                    A = new ub(k, l);
                    for (j = b; j < e; j++) for (o = h; o < g;) if (A.get(j - b, o - h)) o++;
                    else {
                        for (d = 0; i = f[d]; d++) if (0 === j % i && 0 === o % i && j - b + i <= k && o - h + i <= l) {
                            c.push({
                                x: j,
                                y: o,
                                z: B,
                                size: i
                            });
                            A.set(j - b, o - h, i);
                            break
                        }
                        o += i || 1
                    }
                    k <<= 1;
                    l <<= 1;
                    b <<= 1;
                    e <<= 1;
                    h <<= 1;
                    g <<= 1
                }
                return c
            }
        });
        s(p, "offset", {
            get: function() {
                return {
                    left: ua.x,
                    top: ua.y
                }
            },
            set: function(a) {
                ua = {
                    x: ~~ (la.call(a, "x") ? a.x : a.left) || 0,
                    y: ~~ (la.call(a, "y") ? a.y : a.top) || 0
                }
            }
        });
        s(p, "geometry", {
            get: function() {
                return p._retina ? {
                    left: r / 2,
                    top: Y / 2
                } : {
                    left: r,
                    top: Y
                }
            },
            set: function(a) {
                r = ~~ (la.call(a, "x") ? a.x : a.left) || 0;
                Y = ~~ (la.call(a, "y") ? a.y : a.top) || 0;
                w = void 0;
                t = void 0;
                p._retina && (r *= 2, Y *= 2);
                w = O(r / 2);
                t = O(Y / 2)
            }
        });
        g.addEventListener("online", xb, !1);
        g.addEventListener("offline", xb, !1);
        (function(a) {
            function b(a, d) {
                var c = a.zIndex_,
                    f = d.zIndex_;
                return c === f ? 0 : c < f ? -1 : 1
            }
            function d() {
                z.sort(b)
            }
            function c(a) {
                return "string" != typeof a && a.constructor != q && !(a instanceof Image)
            }
            function e(a, b) {
                var d = a.info_;
                if ("string" == typeof d.text) {
                    var c = f.createElement("canvas"),
                        h = c.getContext("2d"),
                        g = b.width,
                        k = b.height,
                        l = d.text,
                        i;
                    d || (d = {});
                    c.width = g;
                    c.height = k;
                    h.drawImage(b, 0, 0, g, k);
                    h.textBaseline = d.textBaseline || "top";
                    h.fillStyle = d.fillStyle || d.color || "rgb(255,255,255)";
                    h.font = d.font || "bold " + (d.fontHeight || ~~ (k / 3) + "px") + " sans-serif";
                    i = h.measureText(l || "").width;
                    h.fillText(l, d.x || (g - i) / 2, d.y || ~~ (k / 3 - 3));
                    d = c
                } else d = b;
                a.img_ = d
            }
            function h() {
                var a = this._,
                    b, d;
                for (this.onload = null; a.length;) b = a.shift(), b.loaded = 1, this === b.img_ && e(b, this), (d = b.onload) && d.call(b)
            }
            function g() {
                var a = nb.call(D, this);~a && (D.splice(a, 1), sa(this, U), z.push(this), I())
            }
            function k(b) {
                var d = a._retina ? 1 : 2,
                    c = b.margin / d,
                    f = b.width / d,
                    d = b.height / d / 2;
                if (c = Q(b.x - this.x) < f / 2 + c && Q(b.y - d - this.y) < d + c) b.clickedPoint.x = this.x - b.x, b.clickedPoint.y = this.y - b.y;
                return c
            }
            function l(a) {
                a.loaded ? (sa(a, U), z.push(a), I()) : (D.push(a), a.onload = g)
            }
            function j(a) {
                var b = nb.call(D, a);~b ? D.splice(b, 1) : ~ (b = nb.call(z, a)) && z.splice(b, 1)
            }
            var C = {
                writable: !0,
                value: null
            },
                A = {},
                z = [],
                D = [],
                S = 0,
                w, v, t;
            Fb = function(b, d) {
                var c = da(a[Z], U);
                c.x += b - pa + n;
                c.y += d - qa + m;
                return Ab.call(z, k, c).concat(R && Q(R.x - c.x) < R.width / 2 && Q(R.y - c.y) < R.height / 2 && R || []).reverse()
            };
            lb = function(b, d, c) {
                var f, e, h = b.scale_,
                    d = b.x - d,
                    c = b.y - c,
                    g = null != b.locationX ? b.locationX : 0.5,
                    k = null != b.locationY ? b.locationY : 1;
                !a._retina && b.retina && (h /= 2);
                E.drawImage(b.image, d - (f = b.width / na * h) * g, c - (e = b.height / na * h) * k, f, e)
            };
            Pb = function() {
                for (var b = oa - pa + n, d = ra - qa + m, c, f, e, h = i + b, g = B + d, k = 0, l = 0, j = z.length, o, C, A, u, D, S = [
                    [],
                    [],
                    []
                ]; k < j;) A = z[k++], l = A.x, u = A.y, f = ~~ (A.width / 2), c = b - f, f = h + f, e = g + A.height, c < l && d < u && l < f && u < e && (A.privileged_ ? D = A : null != A.privilegeLevel ? S[A.privilegeLevel].push(A) : lb(A, b, d));
                for (k = 0; u = S[k]; k++) for (l = 0; l < u.length; l++) lb(u[l], b, d);
                if ((A = R) && A.loaded) if (l = A.x, u = A.y, j = ~~ (X[Hb] * U / 4.007501668E7), b - j < l && d - j < u && l < h + j && u < g + j) {
                    u -= d;
                    l -= b;
                    if (!Ja && !Ba && j) E.fillStyle = "rgba(61,137,12,0.2)", E.drawCircle(l, u, j), E.fillStyle = zb;
                    h = !a._retina ? 2 : 1;
                    E.drawImage(A.image, l - (o = A.width / na / h) + A.width / na / h / 2, u - (C = A.height / na / h) + A.height / na / h / 2, o, C)
                }(A = D) && lb(A, b, d)
            };
            sa = function(a) {
                var b = da(a, U),
                    d = a.img_;
                a.x = b.x;
                a.y = b.y;
                a.width = d.width;
                a.height = d.height
            };
            Eb = function() {
                ya.call(z, sa);
                R && sa(R)
            };
            Sa = function(a, b) {
                var d = typeof a == Na || a instanceof Image || c(a) ? {
                    image: a
                } : a,
                    f = d.image;
                this.margin_ = this.zIndex_ = 0;
                this.lt_ = b[aa];
                this.ln_ = b[$];
                this.scale_ || (this.scale_ = 1);
                this.data = b;
                this.clickedPoint = {
                    x: 0,
                    y: 0
                };
                this.info_ = d;
                "string" == typeof f ? la.call(A, f) ? ((d = this.img_ = A[f])._.push(this), d.onload || h.call(d)) : (d = this.img_ = A[f] = new Image, d.onload = h, d._ = [this], d.src = f, this.width = this.height = 0) : (e(this, f), this.loaded = 1)
            };
            w = {
                zIndex_: C,
                lt_: C,
                ln_: C,
                img_: C,
                info_: C,
                scale_: C,
                privileged_: C,
                clickedPoint: C,
                x: C,
                y: C,
                width: C,
                height: C,
                data: C,
                onload: C,
                loaded: C,
                constructor: {
                    value: v = Sa
                },
                zIndex: {
                    enumerable: !0,
                    get: function() {
                        return this.zIndex_
                    },
                    set: function(a) {
                        this.zIndex_ = a;
                        u(S);
                        S = o(d, 60)
                    }
                },
                toJSON: {
                    value: function(a) {
                        var b = {};
                        for (a in this)!la.call(w, a) && !/_$/.test(a) && (b[a] = this[a]);
                        b.icon = this.img_.src;
                        b[aa] = this.lt_;
                        b[$] = this.ln_;
                        return b
                    }
                },
                image: {
                    enumerable: !0,
                    get: function() {
                        return this.img_
                    },
                    set: function(a) {
                        a instanceof Image || c(a) ? (e(this, a), sa(this)) : (j(this), typeof a == Na ? this.info_.image = a : this.info_ = a, this.loaded = 0, v.call(this, this.info_, this), l(this));
                        I()
                    }
                },
                isPosition: {
                    enumerable: !0,
                    get: function() {
                        return this == R
                    }
                },
                privileged: {
                    enumerable: !0,
                    get: function() {
                        return !!this.privileged_
                    },
                    set: function(a) {
                        var b;
                        if (a) {
                            for (b = z.length; b--;) z[b].privileged_ = !1;
                            b = nb.call(z, this);~b && (z.push(this), z.splice(b, 1))
                        }
                        this.privileged_ = !! a;
                        I()
                    }
                },
                coordinate: t = {
                    get: function() {
                        return this
                    },
                    set: function(a) {
                        this.lt_ = a[aa];
                        this.ln_ = a[$];
                        sa(this);
                        I()
                    }
                },
                coords: t,
                latitude: {
                    enumerable: !0,
                    get: function() {
                        return this.lt_
                    },
                    set: function(a) {
                        this.lt_ = a;
                        sa(this);
                        I()
                    }
                },
                scale: {
                    get: function() {
                        return this.scale_
                    },
                    set: function(a) {
                        this.scale_ = a;
                        I()
                    }
                },
                margin: {
                    get: function() {
                        return this.margin_
                    },
                    set: function(a) {
                        this.margin_ = a
                    }
                },
                retina: {
                    get: function() {
                        return this.retina_
                    },
                    set: function(a) {
                        this.retina_ = a;
                        I()
                    }
                },
                longitude: {
                    enumerable: !0,
                    get: function() {
                        return this.ln_
                    },
                    set: function(a) {
                        this.ln_ = a;
                        sa(this);
                        I()
                    }
                }
            };
            ob ? Sa = ma(Tb + "Poi" + Ub, w) : Ib(Sa.prototype, w);
            s(a, "addPoi", {
                value: function(a) {
                    ya.call([].concat(a), l);
                    u(S);
                    S = o(d, 60)
                }
            });
            s(a, "createPoi", {
                value: function(a, b) {
                    l(a = new Sa(a, b));
                    return a
                }
            });
            s(a, "removePoi", {
                value: function(a) {
                    null == a ? (D = [], z = []) : ya.call([].concat(a), j);
                    I()
                }
            })
        })(p);
        s(p, "pointToGeo", {
            value: function(a) {
                return Za(a, U)
            }
        });
        s(p, "position", {
            get: function() {
                function a(b) {
                    b = b.coords || b.data.coords;
                    X[aa] = b[aa];
                    X[$] = b[$];
                    X[Hb] = b[Hb];
                    X.heading = b.heading;
                    X.speed = b.speed;
                    X.available = !0;
                    if (R) Ja = Ba = !1, R.coords = b, j(p, eb, X);
                    else if (X.marker) R = new Sa(nokia.mh5.assetsPath + "img/position.png", b), R.retina = !0, R.onload = function() {
                        if (R) sa(R), R.loaded = 1, I()
                    }, R.image.width && sa(R), e(X)
                }
                function b(a) {
                    c();
                    g(a)
                }
                function c(a) {
                    X.available = !1;
                    R = null;
                    I();
                    a && j(p, pb, X)
                }
                var f = nokia.mh5.geolocation,
                    e, g;
                X = {
                    marker: !0,
                    deactivate: function() {
                        d(f, Jb, c);
                        d(f, pb, c);
                        d(f, Kb, a);
                        d(f, eb, a);
                        d(f, qb, b);
                        f.deactivate();
                        c()
                    },
                    activate: function(d, k) {
                        if ("disabled" == f.status) return k({
                            type: qb
                        });
                        e = d;
                        g = k;
                        if (R) return e(X);
                        h(f, Jb, c);
                        h(f, pb, c);
                        h(f, Kb, a);
                        h(f, eb, a);
                        h(f, qb, b);
                        f.available ? a({
                            data: f
                        }) : f.activate()
                    },
                    toJSON: function() {
                        var a = {};
                        a[aa] = X[aa];
                        a[$] = X[$];
                        return a
                    },
                    available: !1
                };
                return function() {
                    return X
                }
            }()
        });
        s(p, "route", {
            get: function() {
                return za && 1 == za.length ? za[0] : za
            },
            set: function(a) {
                a ? (ab = [], za = !Vb(a) || V(a[0]) || kb(a[0]) ? [a] : a) : za = null;
                I()
            }
        });
        s(p, "shape", {
            get: function() {
                return gb
            },
            set: function(a) {
                a ? (Ha = [], gb = a, Fa = !Vb(a) || V(a[0]) || kb(a[0]) ? [a] : a) : Fa = null;
                I()
            }
        });
        s(p, "scale", {
            get: function() {
                return na
            },
            set: function(a) {
                1 === na && 1 !== a && (j(p, Wb, {}), Ba = !0);
                E.clearRect(0, 0, i, B);
                na = a;
                E.save();
                E.setTransform(a, 0, 0, a, -a * (Ka - n) + (Ka - n), -a * (La - m) + (La - m));
                F(oa, ra);
                E.restore()
            }
        });
        s(p, Oa, {
            get: function() {
                return Bb ? Xb + ".traffic" : Ea
            },
            set: function(a) {
                Bb = Cb = 0;
                (Bb = /\btraffic\b/.test(a)) ? (Ea = Xb + ".grey", db = "traffictile", cb = "maps.nlp.nokia.com", Db = "newest") : (Cb = /\bcommunity$/.test(a)) ? (Ea = a, cb = "%[1-4]%.communitymaptiles.nokia.com/tilehub/live/", db = ~a.indexOf("hybrid") ? "sat" : "map") : (Ea = a, db = "maptile", cb = "%[1-4]%.maps.nlp.nokia.com", Db = "newest");
                ia.clear();
                ia.gc();
                x()
            }
        });
        s(p, "size", {
            get: function() {
                return p._retina ? {
                    width: i / 2,
                    height: B / 2,
                    rendered: {
                        width: i,
                        height: B
                    }
                } : {
                    width: i,
                    height: B,
                    rendered: {
                        width: i,
                        height: B
                    }
                }
            },
            set: function(a) {
                var b = Ra && p[Z];
                la.call(a, "width") ? (i = a.width, B = a.height) : (i = a[0], B = a[1]);
                ta.style.width = i + "px";
                ta.style.height = B + "px";
                p._retina && (i *= 2, B *= 2);
                pa = Ka = ~~ (i / 2);
                qa = La = ~~ (B / 2);
                nokia.mh5.platform.ios ? (ta.width = 2048 <= i ? 2046 : i, ta.height = 2048 <= B ? 2046 : B) : (ta.width = i, ta.height = B);
                E.font = "7pt sans-serif";
                E.textBaseline = "top";
                E.fillStyle = zb;
                ca();
                x(b)
            }
        });
        Ib(p, {
            restore: {
                value: function() {
                    var a = Ia.get(Z),
                        b = Ia.get(Pa),
                        d = Ia.get(Oa);
                    Ia.get(qc);
                    null != b && (p[Pa] = b);
                    null != d && (p[Oa] = d);
                    a && (p[Z] = a);
                    return !!a
                }
            },
            save: {
                value: function() {
                    var a = p[Oa],
                        b = p[Pa],
                        d = Ra && p[Z];
                    a && Ia.set(Oa, a);
                    b && Ia.set(Pa, b);
                    d && (d = {}, d[aa] = p[Z][aa], d[$] = p[Z][$], Ia.set(Z, d))
                }
            }
        });
        s(p, "tileServer", {
            get: function() {
                return $a
            },
            set: function(a) {
                var b;
                $a = a || yb;
                Aa ? (b = $a.settings.defaultImage) && (ga = L.src = b) : xb({});
                ia.clear();
                ia.gc();
                x()
            }
        });
        s(p, "tileLang", {
            get: function() {
                return mb
            },
            set: function(a) {
                mb = a
            }
        });
        yb = {
            settings: {
                defaultImage: nokia.mh5.assetsPath + "img/empty_tile.png"
            },
            create: function(a, b, d) {
                var c = new Image;
                c.src = Cb ? "http://".concat(cb.replace(/\%\[1\-4\]\%/, 1 + d % 4), db, "/png/", hc(b, d, a)) : "http://".concat(cb.replace(/\%\[1\-4\]\%/, 1 + d % 4), "/maptile/2.1/", db, "/", Db, "/", Ea, "/", a, "/", b, "/", d, "/", G, "/png8", Gb, "&", p._retina ? "ppi=320&" : "", mb ? "lg=" + mb : "");
                return c
            }
        };
        (function() {
            function a() {
                1 === p.scale && (g = !0, p.moveTo(c))
            }
            function b() {
                g || (p.tracking = !1);
                g = !1
            }
            var c = p.position,
                f = !1,
                e, g;
            s(p, "tracking", {
                get: function() {
                    return f
                },
                set: function(k) {
                    k = !! k;
                    k != f && (e = (f = k) ? h : d, ka.resetDefault(), f ? (j(p, Yb, ka), ka.defaultPrevented || (c.available && a(), g = !1)) : j(p, Zb, ka), e(p, eb, a), e(p, Lb, b), e(p, Mb, b))
                }
            })
        })();
        (function() {
            function a() {
                Aa && (this._layer && (c[this._id] = 1), delete f[this._id])
            }
            function b() {
                this.loaded = 1;
                if ((Ba || Ja) && !--g) Ba = Ja = !1;
                p.resume()
            }
            function d(a) {
                if (!(a in this)) f[a].onload = null, f[a].src = ga, delete f[a]
            }
            var c = {},
                f = {},
                e = {},
                h = 0,
                g = 0;
            l(function() {
                Aa && (Ma || ia.gc())
            }, /iP(?:ad|od|hone)/.test(y) ? 1E4 : rc);
            s(p, "paused", {
                get: function() {
                    return !h
                }
            });
            s(p, "pause", {
                value: function() {
                    h && (clearInterval(h), h = 0)
                }
            });
            s(p, "resume", {
                value: function() {
                    h || (h = l(I, 500))
                }
            });
            ia = {
                gc: function() {
                    ya.call($b(f), d, e)
                },
                add: function(d, h, k, l, i, j) {
                    var o = f[d];
                    e[d] = 1;
                    if (!o && (p.tracking || !Ma)) {
                        if (j) {
                            if (!(d in c)) o = f[d] = new Image, o.src = j, o._layer = !0
                        } else o = f[d] = $a.create(T, (h % xa + xa) % xa, (k % xa + xa) % xa);
                        if (o) o.onload = b, o.onerror = a, o._id = d
                    } else o && o.loaded ? o.complete && 0 < o.height && E.drawImage(o, l, i, G, G) : ((!Aa || !Ba && !Ja) && j != d && L.complete && 0 < L.height && E.drawImage(L, l, i, G, G), ++g)
                },
                clear: function() {
                    g = 0;
                    e = {}
                }
            }
        })();
        s(p, "toJSON", {
            value: function(a) {
                a = {
                    _: a
                };
                a[Z] = p[Z];
                a[Pa] = p[Pa];
                a[Oa] = p[Oa];
                return a
            }
        });
        Sb = function(a) {
            a = C(z(a, ea), Ga);
            if (T != a) {
                var b = Ra && p[Z];
                Ra && (p.scale = fa(2, a - T));
                Ba = !1;
                Ja = !0;
                16 < a ? (vb = sc, wb = 8) : (vb = Rb, wb = 5);
                U = G << a;
                xa = 1 << a;
                j(p, ac, {
                    oldValue: T,
                    newValue: a
                });
                T = a;
                ca();
                Aa && ia.gc();
                Eb();
                p.route = p.route;
                na = 1;
                x(b)
            } else na = 1
        };
        s(p, Pa, {
            get: function() {
                return T
            },
            set: function(a) {
                Sb(a)
            }
        });
        Ib(p, {
            MAX_ZOOM_LEVEL: {
                get: function() {
                    return ea
                },
                set: function(a) {
                    ea = null == a ? bc : a
                }
            },
            MIN_ZOOM_LEVEL: {
                get: function() {
                    return Ga
                },
                set: function(a) {
                    Ga = null == a ? tc : a
                }
            }
        });
        var G = p._retina ? 512 : 256;
        (function() {
            function a(b) {
                h(p, b, this)
            }
            function b(a) {
                d(p, a, this)
            }
            function c(a, b) {
                [cc, dc, Lb, ec, fc, ac, Wb, Mb, gc, Yb, Zb, eb, pb, qb, Kb, Jb].forEach(a, b)
            }
            var f = [],
                e = [],
                g;
            s(p, "addNotifications", {
                value: function(b) {
                    g = f.indexOf(b);
                    0 > g && (g = f.push(b) - 1, c(a, e[g] = {
                        handleEvent: function(a) {
                            j(b, a.type, a.data)
                        }
                    }))
                }
            });
            s(p, "dropNotifications", {
                value: function(a) {
                    g = f.indexOf(a); - 1 < g && (c(b, e[g]), f.splice(g, 1), e.splice(g, 1))
                }
            })
        })();
        s(p, "retina", {
            get: function() {
                return p._retina
            },
            set: function(a) {
                var b = p.size.width,
                    d = p.size.height,
                    c = p.geometry.top,
                    f = p.geometry.left;
                if (p._retina !== a) {
                    p._retina = a;
                    G = p._retina ? 512 : 256;
                    if (p._retina) {
                        if (19 < p.zoom) p.zoom = 19;
                        ea = 19
                    } else ea = 20;
                    bc = ea;
                    U = G << p.zoom;
                    E.clear();
                    p.size = {
                        width: b,
                        height: d
                    };
                    p.geometry = {
                        top: c,
                        left: f
                    };
                    ca();
                    p.route = p.route;
                    Eb();
                    ia.clear();
                    ia.gc();
                    x()
                }
            }
        });
        b(ta, function() {
            function a(b, d) {
                var c = p.geoToPoint(p.center);
                return p.pointToGeo({
                    x: c.x - i / 2 + b,
                    y: c.y - B / 2 + d
                })
            }
            function b(d, c) {
                e();
                j(p, fc, a(d, c))
            }
            function d() {
                bb && (u(bb), Ka = pa, La = qa, bb = 0, ++p.zoom)
            }
            function f(a, b) {
                if (2 === C(p.scale + 0.2, 2)) p.scale += 0.2, bb = o(f, 30, a, b);
                else {
                    p.scale = 2;
                    var c = E.drawImage,
                        e = E.clearRect,
                        h = E.drawCircle,
                        g = E.lineTo;
                    E.drawImage = E.clearRect = E.drawCircle = E.lineTo = H;
                    d();
                    p.move(a, b);
                    E.drawImage = c;
                    E.clearRect = e;
                    E.drawCircle = h;
                    E.lineTo = g
                }
            }
            function e() {
                u(W);
                W = 0
            }
            function h(a) {
                if (!fa && (Y(a), !Ma && !(rb < Q(ga - P) || rb < Q(ma - K)))) {
                    sb(a);
                    var d = (ca || a.pageX) - ua.x,
                        c = (hb || a.pageY) - ua.y,
                        a = Fb(d, c),
                        g;
                    g = d;
                    var k = c;
                    if (Fa) {
                        var l = da(p[Z], U);
                        l.x += g - pa + n;
                        l.y += k - qa + m;
                        g = Ab.call(Ha[T], oc, l).reverse()
                    } else g = [];
                    if (a.length || g.length) {
                        if (e(), d = g, e(), d.length && j(p, uc, d), a.length) {
                            if (!a[0].privileged_) a: {
                                d = 0;
                                for (c = a.length; c--;) {
                                    g = a[c];
                                    if (g.privileged_) {
                                        a.splice(c, 1);
                                        a.unshift(g);
                                        g.privileged = 1;
                                        break a
                                    }
                                    if ("privilegeLevel" in g && (!("privilegeLevel" in a[d]) || g.privilegeLevel > a[d].privilegeLevel)) d = c
                                }
                                0 < d && a.unshift(a.splice(d, 1)[0])
                            }
                            j(p, cc, a)
                        }
                    } else W ? (e(), ka.resetDefault(), j(p, Mb, ka), !ka.defaultPrevented && p.zoom < ea && (d -= pa - n, c -= qa - m, Ka += d, La += c, bb = o(f, r, d, c))) : (Ka = pa, La = qa, W = o(b, r, d, c))
                }
            }
            function g(a) {
                L ? (Na = new J, sb(a), a = (a.touches || [a])[0], P = p._retina ? 2 * a.screenX : a.screenX, K = p._retina ? 2 * a.screenY : a.screenY, I ? p.move(M = ba - P, ha = O - K) : I = (rb < Q(ga - P) || rb < Q(ma - K)) && A(), ba = P, O = K) : (a = (a.touches || [a])[0], ba = p._retina ? 2 * a.screenX : a.screenX, O = p._retina ? 2 * a.screenY : a.screenY)
            }
            function l() {
                z(ja = 0);
                j(p, ec, {})
            }
            function A() {
                y();
                Ja = Ba = !1;
                ka.resetDefault();
                j(p, Lb, ka);
                return !ka.defaultPrevented
            }
            function z(a) {
                ga = P = ba = M = ma = K = O = ha = 0;
                return a
            }
            function D() {
                return 100 > new J - Na && z(x.kick(ba, O, M, ha))
            }
            function S() {
                Ma = 0
            }
            function v() {
                Da = 0;
                L = 1
            }
            function y() {
                u(V);
                V = 0
            }
            function q() {
                y();
                fa = 1;
                j(p, gc, a(ca - ua.x, hb - ua.y))
            }
            function va() {
                1 !== G && (p.scale = G);
                N = o(va, 20)
            }
            var r = 250,
                Y = ob ?
            function(a) {
                a.pageX = a.clientX + k.scrollLeft;
                a.pageY = a.clientY + k.scrollTop
            } : H, x = c(function() {
                Ma = 1
            }, function(a, b) {
                p.move(a, b)
            }, function() {
                Ma = 0;
                F(oa, ra);
                l()
            }), W = 0, V = 0, L = 1, I = 1, fa = 0, N = 0, ga, ma, ba, O, P, K, ca, hb, M, ha, Na, G;
            s(p, "moveTo", {
                value: function(a) {
                    var a = da(a, U),
                        b = a.x - oa - w,
                        a = a.y - ra - t;
                    A() && x.kick(b + pa, a + qa, b / 9, a / 9)
                }
            });
            return {
                init: function(a) {
                    "mouse" == a && (L = 0)
                },
                mouse: {
                    down: function(a) {
                        Y(a);
                        V = o(q, 600);
                        d();
                        x.stop();
                        sb(a);
                        Na = fa = 0;
                        ga = ba = P = p._retina ? 2 * a.screenX : a.screenX;
                        ma = O = K = p._retina ? 2 * a.screenY : a.screenY;
                        ca = p._retina ? 2 * a.pageX : a.pageX;
                        hb = p._retina ? 2 * a.pageY : a.pageY;
                        L = 1;
                        I = 0
                    },
                    move: function(a) {
                        Y(a);
                        L && (I || (I = A()));
                        g(a);
                        L || (a = Fb((a.pageX - ua.x) * (p._retina ? 2 : 1), (a.pageY - ua.y) * (p._retina ? 2 : 1)), a.length && j(p, dc, a))
                    },
                    up: function(a) {
                        y();
                        ba != ga || O != ma ? D() || l() : L && o(S, 50) && h(a);
                        L = 0
                    },
                    wheel: function(a) {
                        if (a.detail) var b = 0 < a.detail ? 1 : -1;
                        a.wheelDelta && (b = 0 > a.wheelDelta ? 1 : -1);
                        la.call(a, "wheelDelta") || ic && (b *= -1);
                        p.zoom -= b
                    }
                },
                touch: {
                    start: function(a) {
                        var b = a.touches,
                            c = b.length;
                        sb(a);
                        1 < c || (V = o(q, 600), d(), Na = fa = 0, L && (x.stop(), I = 0, L = 2 > c, a = b[0], ga = ba = P = p._retina ? 2 * a.screenX : a.screenX, ma = O = K = p._retina ? 2 * a.screenY : a.screenY, ca = p._retina ? 2 * a.pageX : a.pageX, hb = p._retina ? 2 * a.pageY : a.pageY))
                    },
                    move: function(a) {
                        g(a)
                    },
                    end: function(a) {
                        var b = a.touches;
                        V && y();
                        L ? I ? D() || l() : (Ma = 0, h(a)) : (L = !Da && 2 > b.length) && F(oa, ra)
                    }
                },
                gesture: {
                    start: function() {
                        y();
                        x.stop(S());
                        Da = 1;
                        tb(L = I = 0);
                        va(G = 1)
                    },
                    change: function(a) {
                        G = a.scale
                    },
                    end: function() {
                        clearInterval(N);
                        p.zoom += 0.9 > G ? -(0.1 > G ? 3 : 0.5 > G ? 2 : 1) : 1.1 < G ? 3 < G ? 3 : 2 < G ? 2 : 1 : 0;
                        o(v, 33)
                    }
                },
                click: h
            }
        }(p));
        ob && (p = ma(Tb + Ub++, p)());
        p.tileServer = null;
        p.size = [i || e.offsetWidth, B || e.offsetHeight];
        p.zoom = 12;
        p.schema = "normal.day";
        return p
    }
    var i = nokia.mh5.event,
        h = i.add,
        d = i.remove,
        j = i.fire,
        f = g.document,
        k = f.documentElement,
        m = g.escape,
        n = g.unescape,
        l = g.setInterval,
        o = g.setTimeout,
        u = g.clearTimeout,
        w = g.isNaN,
        v = g.navigator,
        y = v.userAgent,
        t = g.Array,
        q = g.Object,
        s = q.defineProperty,
        x = {}.__defineGetter__,
        r = {}.__defineSetter__,
        J = g.Date,
        F = g.Function,
        H = F(),
        B = g.JSON,
        D = g.Math,
        z = D.min,
        C = D.max,
        A = D.log,
        S = D.atan,
        va = D.exp,
        Y = D.sqrt,
        fa = D.pow,
        W = D.tan,
        O = D.round,
        P = D.ceil,
        Q = D.abs,
        K = D.PI,
        M = K / 2,
        Ca = K / 4,
        N = 180 / K,
        I = 2 * K,
        V = function(a) {
            return typeof a == tb
        },
        L = new Image,
        ga, ma, ba, ca = !! f.createElement("canvas").getContext,
        ha = !! s,
        Ua = !! x && !! r,
        ic = !+"\u000b1",
        ob;
    if (ha) try {
        if (!s({}, "_", {
            value: 1
        })._) throw ha;
    } catch (hc) {
        ha = !ha
    }
    ob = !(ha || Ua);
    var Tb = "Gaia_",
        tb = "number",
        Na = "string";
    (new J).getFullYear();
    var Qa = ca ? "addEventListener" : "attachEvent",
        aa = "latitude",
        $ = "longitude",
        ea = 20,
        Ga = 3,
        bc = ea,
        tc = Ga,
        cc = "poiclick",
        dc = "poiover",
        uc = "shapeclick",
        qc = "position-available",
        Lb = "mapmovestart",
        ec = "mapmoveend",
        fc = "mapclick",
        ac = "mapzoomchange",
        Wb = "mapscalechange",
        Mb = "mapdblclick",
        gc = "maplongpress",
        Yb = "maptrackingstart",
        Zb = "maptrackingend",
        Z = "center",
        Pa = "zoom",
        Oa = "schema",
        Hb = "accuracy",
        eb = "positionchange",
        pb = "positionlost",
        qb = "positionerror",
        Kb = "positionactivate",
        Jb = "positiondeactivate",
        sc = "rgba(102,17,68,0.55)",
        Rb = "rgba(102,17,68,0.69)",
        kc = (ca ? "" : "on") + "mousewheel",
        lc = "DOMMouseScroll",
        Va = "touchstart",
        Wa = "touchmove",
        Xa = "touchend",
        Nb = "gesturestart",
        Da = "gesturechange",
        wa = "gestureend",
        rc = 6E4,
        rb = 9,
        Xb = "normal.day";
    ha || (s = Ua ?
    function(a, b, d) {
        la.call(d, "value") ? a[b] = d.value : (la.call(d, "get") && x.call(a, b, d.get), la.call(d, "set") && r.call(a, b, d.set));
        return a
    } : function(a, b, d) {
        a[b] = d;
        return a
    });
    var Ib = q.defineProperties ||
    function(a, b) {
        for (var d = $b(b), c = d.length, f; c--;) la.call(b, f = d[c]) && s(a, f, b[f])
    }, $b = q.keys ||
    function(a) {
        var b = [],
            d = 0,
            c;
        for (c in a) la.call(a, c) && (b[d++] = c);
        return b
    }, fb = q.prototype, la = fb.hasOwnProperty, gb = fb.toString, vc = gb.call([]), Vb = t.isArray ||
    function(a) {
        return gb.call(a) == vc
    }, Ta = t.prototype, Ab = Ta.filter ||
    function(a, b) {
        for (var d = [], c = 0; c < this.length; ++c) a.call(b, this[c], c, this) && d.push(this[c]);
        return d
    }, ya = Ta.forEach ||
    function(a, b) {
        for (var d = 0; d < this.length; ++d) a.call(b, this[d], d, this)
    }, nb = Ta.indexOf ||
    function(a) {
        for (var b = this.length; b-- && this[b] !== a;);
        return b
    }, wc = Ta.slice, Qb = g.Int32Array || t;
    o(function(a) {
        if (!a) {
            var b = o,
                d = l,
                c = function(a, b, d, c) {
                    c = wc.call(c, 2);
                    return a(function() {
                        b.apply(this, c)
                    }, d)
                };
            o = function(a, d) {
                return c(b, a, d, arguments)
            };
            l = function(a, b) {
                return c(d, a, b, arguments)
            }
        }
    }, 0, 1);
    var sb = ca ?
    function(a) {
        a.preventDefault()
    } : function(a) {
        (a || g.event).returnValue = !1
    };
    "on" + wa in f || Qa in f &&
    function() {
        function a(d, c, h) {
            A = f.createEvent("Event");
            A.initEvent(h, e, e);
            A.scale = h == Da ? B = b(c) / o : h == wa ? B : 1;
            (d.target || f).dispatchEvent(A)
        }
        function b(a) {
            j = a[0];
            C = j[d];
            m = j[c];
            j = a[a.length - 1];
            n = j[d];
            z = j[c];
            return Y(fa(z - m, 2) + fa(n - C, 2))
        }
        if (!f["_on" + wa]) {
            var d = "screenX",
                c = "screenY",
                e = !0,
                h = !1,
                k = !1,
                l, i, j, o, B, A, C, n, m, z;
            g.navigator.msPointerEnabled &&
            function(a) {
                function b(a, d, c) {
                    l = f.createEvent("Event");
                    l.initEvent(c, e, e);
                    l.touches = d;
                    l.isTouch = !0;
                    (a.target || f).dispatchEvent(l)
                }
                function d(a, f) {
                    g = a.pointerId;
                    k = c[g];
                    if (void 0 !== k) {
                        h.splice(k, 1);
                        delete c[g];
                        for (var e in c) c.hasOwnProperty(e) && c[e] > k && c[e]--;
                        f && b(a, h, Xa)
                    }
                }
                var c = {},
                    h = [],
                    g, k, l;
                nokia.mh5.event.add(a, "MSPointerDown", function(a) {
                    g = a.pointerId;
                    if (void 0 === c[g]) c[g] = h.length, h[h.length] = a, b(a, h, Va)
                });
                nokia.mh5.event.add(a, "MSPointerMove", function(a) {
                    g = a.pointerId;
                    void 0 !== c[g] && (h[c[g]] = a, b(a, h, Wa))
                });
                nokia.mh5.event.add(a, "MSPointerUp", function(a) {
                    d(a, !0)
                });
                nokia.mh5.event.add(a, "MSPointerCancel", function(a) {
                    d(a, !1)
                })
            }(f);
            f[Qa](Va, function(d) {
                d.target instanceof HTMLCanvasElement && d.preventDefault();
                l = h;
                i = d.touches || [];
                h = 1 < i.length;
                h != l && (k = e, o = b(i), a(d, i, "gesturestart"))
            }, e);
            f[Qa](Wa, function(b) {
                h && b.preventDefault();
                h && !k && a(b, b.touches || [], Da);
                k = !1
            }, e);
            f[Qa](Xa, function(b) {
                i = b.touches || [];
                h && 2 > i.length && (h = !1, a(b, i, wa))
            }, e);
            f["_on" + wa] = e
        }
    }();
    var pc = function() {
            var a = B.stringify,
                b = B.parse,
                d = g.localStorage,
                c = 0;
            return function() {
                var e = {
                    get: function(a) {
                        var d = "" + f.cookie,
                            c = d.indexOf((a = m(h + a)) + "=");
                        return ~c ? b(n(d.slice(c + a.length + 1).split(";")[0])) : null
                    },
                    set: function(b, d) {
                        var c = new J;
                        c.setFullYear(c.getFullYear() + 1);
                        f.cookie = "".concat(m(h + b), "=", m(a(d)), ";", "expires=", c.toGMTString())
                    }
                },
                    h = ++c + "html5-map-";
                return {
                    get: d ?
                    function(a) {
                        var c = d.getItem(h + a);
                        try {
                            return null === c ? e.get(a) : b(c)
                        } catch (f) {
                            return null
                        }
                    } : e.get,
                    set: d ?
                    function(b, c) {
                        try {
                            d.setItem(h + b, a(c))
                        } catch (f) {
                            e.set(b, c)
                        }
                    } : e.set
                }
            }
        }();
    ca && (ba = function() {
        function a(b, d, c) {
            this.beginPath();
            this.arc(b, d, c, 0, I);
            this.fill()
        }
        return function() {
            var b = f.createElement("canvas"),
                d = b.getContext("2d");
            d.clear = H;
            d.drawCircle = a;
            return b
        }
    }());
    var Ub = 0;
    e.MAX_ZOOM_LEVEL = ea;
    e.MIN_ZOOM_LEVEL = Ga;
    return e
}(this);
nokia.mh5.provide("nokia.mh5.internals.CartoPOI");
nokia.mh5.internals.CartoPOI = nokia.mh5.Class(function() {
    function g() {
        if (this._timeout) clearTimeout(this._timeout), this._timeout = 0
    }
    function a(a) {
        var b;
        a.placeId = a.id;
        delete a.id;
        if (a.placeId && !(a.placeId in this._cache) && (a = {
            categoryGroup: m(a.category),
            placeId: a.placeId,
            cartopoi: !0,
            latitude: a.lat,
            longitude: a.lon,
            name: a.location_name,
            categories: [{
                id: a.category,
                cartopoi: !0
            }],
            properties: {
                cartopoi: !0,
                placeId: a.placeId,
                priority: a.priority,
                title: a.location_name,
                geoLatitude: a.lat,
                geoLongitude: a.lon
            }
        }, this._cache[a.placeId] = 1, b = m(a.categories[0].id))) a = this._map.createPoi(nokia.mh5.assetsPath + "img/mapsymbols/carto_POI_" + b + ".png", a), a.zIndex = -1, a.retina = !0, a.margin = 10, this._draw.push(a)
    }
    function b() {
        this.parentNode && this.parentNode.removeChild(this)
    }
    function c() {
        this._map.removePoi(this._drawn);
        this._poi = {};
        this._cache = {};
        this._drawn = []
    }
    function e(a, b) {
        a._zoomtimeout = 0;
        if (b !== a._zoom) a._clearTimeout(), a._zoom = b, c.call(a), 14 < b && (a._timeout = setTimeout(a._boundmove, 1E3))
    }
    function i() {
        for (var a = this._wrapper, b = this._wrapper.infoBubbles, d, c = 0, f = b.length; c < f; c++) d = b[c], d.poi.data.cartopoi && a.hideInfoBubble(d)
    }
    function h(a, b, d, c) {
        14 < c && (this._poi[(c - 3 >> 0) + "/" + (a / 8 >> 0) + "/" + (b / 8 >> 0)] = 1)
    }
    function d(a) {
        clearTimeout(this._zoomtimeout);
        this._zoomtimeout = setTimeout(e, 1, this, a.data.newValue)
    }
    function j() {
        var d = nokia.mh5.doc,
            c = this,
            f = c._poi,
            e = [],
            h = [],
            g = 0,
            i, j, m;
        if (k.onLine) for (j in f)++g, i = d.body.appendChild(d.createElement("script")), i.src = "http://b.heatmaps.maps.svc.ovi.com/heatmaps/v2/mapsymbols.default/" + j + "/1024/jsonp", i.onload = i.onerror = b;
        if (g) m = function() {
            if (!--g) {
                for (j in f) e = e.concat(f[j]);
                e.forEach(a, {
                    _cache: c._cache,
                    _map: c._map,
                    _draw: h
                });
                c._drawn = c._drawn.concat(h)
            }
        }, mapsymbols.callback = function(a, b) {
            f[a] = b;
            m()
        };
        this._poi = {};
        this._clearTimeout()
    }
    if (!("mapsymbols" in window)) window.mapsymbols = {};
    var f = nokia.mh5.event,
        k = nokia.mh5.win.navigator,
        m = nokia.mh5.utils.place.categoryIdentifier;
    return {
        constructor: function(a, b) {
            this._active = !1;
            this._bound = h.bind(this);
            this._boundmove = j.bind(this);
            this._boundzoom = d.bind(this);
            this._boundHideInfoBubble = i.bind(this);
            this._boundCleanPois = c.bind(this);
            this._clearTimeout = g.bind(this);
            this._poi = {};
            this._cache = {};
            this._drawn = [];
            this._map = b;
            this._wrapper = a;
            this._zoomtimeout = this._timeout = this._zoom = 0
        },
        activate: function() {
            if (!this._active) {
                var a = this._map,
                    b = [].concat(a.layer || []);
                b.push(this._bound);
                a.layer = b;
                f.add(a, "mapscalechange", this._boundHideInfoBubble);
                f.add(a, "mapscalechange", this._boundCleanPois);
                f.add(a, "mapzoomchange", this._boundzoom);
                f.add(a, "mapmoveend", this._boundmove);
                f.add(a, "mapmovestart", this._clearTimeout);
                this._boundzoom({
                    data: {
                        newValue: a.zoom
                    }
                });
                this._active = !0
            }
        },
        deactivate: function() {
            if (this._active) {
                var a = this._map,
                    b = [].concat(a.layer);
                b.splice(b.indexOf(this._bound), 1);
                a.removePoi(this._drawn);
                a.layer = b;
                f.remove(a, "mapscalechange", this._boundHideInfoBubble);
                f.remove(a, "mapscalechange", this._boundCleanPois);
                f.remove(a, "mapzoomchange", this._boundzoom);
                f.remove(a, "mapmoveend", this._boundmove);
                f.remove(a, "mapmovestart", this._clearTimeout);
                e(this, 0);
                this._active = !1
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.internals.SQLTileServer");
nokia.mh5.internals.SQLTileServer = nokia.mh5.Class(function() {
    function g(b, c, h, g, k) {
        function l() {
            y = n.started = !1
        }
        function i(a) {
            w.type = a;
            (n[u] || e).call(n, w)
        }
        function j(a, b) {
            if (y) l(), w.message = (b || a).message, i("error"), o(), nokia.mh5.maps.analytics.log({
                gn: "map:download",
                c32: "map download failed",
                ev: "event33"
            })
        }
        function o() {
            y = null;
            n.started = !1;
            i("loadend")
        }
        function A() {
            n.started = !0;
            !y && n.dbCreated && (y = !y, z(b.pop()))
        }
        function C(b) {
            t = 0;
            a(function() {
                n.dbCreated = !0;
                y && (l(), i("abort"), o(), nokia.mh5.maps.analytics.log({
                    gn: "map:download",
                    c32: "map download canceled by user",
                    ev: "event34"
                }));
                b && b()
            })
        }
        function m() {
            i("load");
            o();
            nokia.mh5.maps.analytics.log({
                gn: "map:download",
                c32: "map download completed",
                ev: "event35"
            })
        }
        function z(a) {
            var e = a.size,
                l, o, A = O ? K : Q,
                C = 0,
                u = 0;
            nokia.mh5.jsonp("http://" + (1 + a.y % 4) + ".maps.nlp.nokia.com/maptile/2.1/maptile/newest/normal.day/" + a.z + "/" + a.x + "/" + a.y + "/" + (g ? "512" : "256") + "/png8" + k + "&output=base64&" + (g ? "ppi=320&" : "") + "range=" + e + "x" + e + "&callback_func", function(k) {
                if (k.error) return b.push(a), j(null, {
                    message: k.error
                });
                if (y) {
                    for (l = k.length; l--;) C += k[l].length;
                    f(A, H, function(f) {
                        function l() {
                            u -= 1;
                            if (!u) {
                                n.downloaded += 2 * C;
                                if (y) n.current += e * e, n.estimated = n.downloaded / n.current * n.total, i("progress"), t += 1, t == v && d(P, B, {
                                    p1x: c[0].latitude,
                                    p1y: c[0].longitude,
                                    p2x: c[1].latitude,
                                    p2y: c[1].longitude,
                                    minZoom: D,
                                    maxZoom: S,
                                    schema: h,
                                    retina: g
                                }, m, j);
                                y && b.length && z(b.pop())
                            }
                        }
                        o = a.z;
                        k.forEach(function(b, c) {
                            S = Math.max(o, S);
                            D = Math.min(o, D || S);
                            var h = {
                                z: o,
                                x: a.x + c % e,
                                y: a.y + Math.floor(c / e),
                                retina: g,
                                base64: b
                            };
                            if ("idb" === M) h.id = [h.x, h.y, h.z, h.retina].join(";");
                            d(A, H, h, l, j, f);
                            u += 1
                        })
                    })
                } else b.push(a)
            }, 45E3)
        }
        var n = this,
            D = 0,
            S = 0,
            w = {
                data: n
            },
            v = b.length,
            t = 0,
            y;
        n.total = b.reduce(function(a, b) {
            return a + b.size * b.size
        }, 0);
        n.current = 0;
        n.downloaded = 0;
        n.dbCreated = n.started = !1;
        n.stop = C;
        n.start = function() {
            null == y ? C(A) : A();
            nokia.mh5.maps.analytics.log({
                gn: "map:download",
                c32: "map download started",
                v32: "~c32",
                ev: "event32",
                c33: "lat0:" + c[0].latitude + ",lon0:" + c[0].longitude + ",lat1:" + c[1].latitude + ",lon1:" + c[1].longitude,
                v33: "~c33"
            })
        };
        n.pause = l;
        n.resume = A;
        n[u] = null
    }
    function a(a) {
        a = a || e;
        b(function() {
            c(a)
        })
    }
    function b(a) {
        a = a || e;
        f(P, B, function(b) {
            if ("sql" === M) o(b, v + B, [], function() {
                i(a)
            }, e);
            else {
                var d = b.objectStore(B);
                d.openCursor().onsuccess = function(b) {
                    (b = b.target.result) ? (d["delete"](b.key), b["continue"]()) : a()
                }
            }
        })
    }
    function c(a) {
        a = a || e;
        f(Q, H, function(b) {
            if ("sql" === M) o(b, v + H, [], function() {
                m(a)
            }, e);
            else {
                var d = b.objectStore(H);
                d.openCursor().onsuccess = function(b) {
                    (b = b.target.result) ? (d["delete"](b.key), b["continue"]()) : a()
                }
            }
        })
    }
    function e() {}
    function i(a) {
        a = a || e;
        "sql" === M ? f(P, B, function(b) {
            o(b, w + B + " (" + y + " " + F + ", " + t + " " + F + ", " + q + " " + F + ", " + s + " " + F + ", " + x + " " + F + ", " + r + " " + F + ", schema TEXT NOT NULL, retina " + F + ")", [], function() {
                o(b, "SELECT retina FROM " + B, [], a, function() {
                    b.executeSql("ALTER TABLE " + B + " ADD COLUMN retina " + F + " DEFAULT false", [], a, e)
                })
            }, e)
        }) : (K.createObjectStore(B, {
            autoIncrement: !0
        }), a())
    }
    function h(a) {
        !Q && !O && k(A, S, va, Y, function(b) {
            Q = b;
            m(a)
        })
    }
    function d(a, b, d, c, e, h) {
        if ("sql" === M) {
            var g = function(a) {
                    for (var f = Object.keys(d), h = [], g = [], k = 0, l = f.length; k < l; k++) h.push("?"), g.push(d[f[k]]);
                    f = "INSERT INTO " + b + " VALUES (" + h.join(",") + ")";
                    a.executeSql(f, g, c, e)
                };
            h ? g(h) : f(a, b, g)
        } else a = (h || a.transaction([b], "readwrite", 0)).objectStore(b).put(d), a.onsuccess = c, a.onerror = e
    }
    function j(a, b, d, c) {
        if ("sql" === M) a[z](function(a) {
            o(a, "SELECT * FROM " + b, [], function(a, b) {
                c(b ? b : a)
            })
        });
        else {
            var b = a.transaction([b]).objectStore(b),
                f = [];
            if (!d) b.openCursor().onsuccess = function(a) {
                (a = a.target.result) ? (f.push(a.value), a["continue"]()) : c(f)
            }
        }
    }
    function f(a, b, d) {
        if ("sql" === M) a[D](d);
        else d(a[D]([b], "readwrite", 0))
    }
    function k(a, b, d, c, f, e) {
        "sql" === M ? (e = window.openDatabase(a, b, d, c), f(e)) : (a = Ca.open(a), a.onsuccess = function(a) {
            f(a.target.result)
        }, a.onerror = e)
    }
    function m(a) {
        a = a || e;
        "sql" === M ? f(Q, H, function(b) {
            o(b, w + H + " (z " + J + ", x " + J + ", y " + J + ", retina " + F + ", base64 TEXT)", [], function() {
                o(b, "SELECT retina FROM " + H, [], a, function() {
                    b.executeSql("ALTER TABLE " + H + " ADD COLUMN retina " + F + " DEFAULT false", [], a, e)
                })
            }, e)
        }) : (K.createObjectStore(H, {
            keyPath: "id"
        }), a())
    }
    function n(a) {
        if (!W) throw "Web SQL not available";
        this.settings = a
    }
    var l = function(a, b) {
            l = a.item ?
            function(a, b) {
                return a.item(b)
            } : function(a, b) {
                return a[b]
            };
            return l(a, b)
        },
        o = function(a, b, d, c, f) {
            a.executeSql(b, d, c, f)
        },
        u = "onprogress",
        w = "CREATE TABLE IF NOT EXISTS ",
        v = "DROP TABLE ",
        y = "tl_latitude",
        t = "tl_longitude",
        q = "br_latitude",
        s = "br_longitude",
        x = "MIN_ZOOM_LEVEL",
        r = "MAX_ZOOM_LEVEL",
        J = "INTEGER NOT NULL",
        F = "TEXT NOT NULL",
        H = "offline_tiles",
        B = H + "_bbox",
        D = "transaction",
        z = "readTransaction",
        C = window.openDatabase,
        A = "m_nokia_maps",
        S = "1.0",
        va = "",
        Y = 47185920,
        fa = 52428800,
        W = !0,
        O = !nokia.mh5.platform.ios,
        P, Q, K, M, Ca = window.indexedDB || window.mozIndexedDB;
    C ? M = "sql" : Ca ? M = "idb" : (M = "none", W = !1);
    if ("2.2" != nokia.mh5.platform.android.version) if ("undefined" != typeof SQLitePlugin) O = !0, z = D, document.addEventListener("deviceready", function() {
        K = P = Q = new SQLitePlugin(A + ".sqlite3", function() {
            f(K, B, i);
            f(K, H, m)
        })
    }, !1);
    else if (O) if (K = null, "sql" === M) for (; !K && 5242880 < fa;) {
        try {
            K = P = Q = C(A, S, va, fa), K[D](i), K[D](m)
        } catch (N) {}
        fa -= 5242880
    } else {
        if ("idb" === M) C = Ca.open(A, 1), C.onsuccess = function(a) {
            K = P = Q = a.target.result;
            W = !0
        }, C.onerror = function() {
            W = !1
        }, C.onupgradeneeded = function(a) {
            K = P = Q = a.target.result;
            W = !0;
            i();
            m()
        }
    } else try {
        k(A + "_flag", S, va, 1024, function(a) {
            P = a;
            f(a, B, i)
        })
    } catch (I) {
        W = !1
    } else W = !1;
    n.AVAILABLE = nokia.mh5.platform.offlineStorageSupported = W;
    g.prototype.onprogress = null;
    return {
        constructor: n,
        create: function(a, b, d) {
            var c = this.settings,
                f = c.apiKey || "",
                e = c.tileLang,
                h = new Image,
                g = this.retina,
                k = g ? 512 : 256,
                e = e ? "lg=" + e : "";
            if ("sql" === M) Q[z](function(i) {
                o(i, "SELECT base64 FROM " + H + " WHERE z = ? AND x = ? AND y = ? AND retina = ?", [a, b, d, g], function(i, j) {
                    var o = (j || i).rows;
                    if (o.length) h.src = "data:image/png;base64," + l(o, 0).base64;
                    else if (!c.offlineOnly) h.src = "http://".concat(1 + d % 4, ".maps.nlp.nokia.com", "/maptile/2.1/", "maptile", "/newest/", "normal.day", "/", a, "/", b, "/", d, "/", k, "/png8", f, "&", g ? "ppi=320&" : "", e)
                })
            });
            else {
                var i = Q.transaction([H]).objectStore(H).get([b, d, a, g].join(";"));
                i.onsuccess = function() {
                    var l = i.result;
                    if (l) h.src = "data:image/png;base64," + l.base64;
                    else if (!c.offlineOnly) h.src = "http://".concat(1 + d % 4, ".maps.nlp.nokia.com", "/maptile/2.1/", "maptile", "/newest/", "normal.day", "/", a, "/", b, "/", d, "/", k, "/png8", f, "&", g ? "ppi=320&" : "", e)
                }
            }
            return h
        },
        getBoundingBox: function L(a) {
            var b = O ? K : P;
            b ? j(b, B, null, function(b) {
                "sql" === M ? (b = b.rows, b.length ? (h(), b = l(b, 0), a([{
                    latitude: 1 * b[y],
                    longitude: 1 * b[t]
                }, {
                    latitude: 1 * b[q],
                    longitude: 1 * b[s]
                }], 1 * b.MIN_ZOOM_LEVEL, 1 * b.MAX_ZOOM_LEVEL, b.schema, "true" === b.retina ? !0 : !1)) : a(null)) : b[0] && (b = b[0], a([{
                    latitude: b.p1x,
                    longitude: b.p1y
                }, {
                    latitude: b.p2x,
                    longitude: b.p2y
                }], b.maxZoom, b.minZoom, b.schema, "true" === b.retina ? !0 : !1))
            }) : setTimeout(L, 100, a)
        },
        storeBoundingBox: function(a, b) {
            if (!b) b = a.bbox;
            var d = new g(a.areaToTiles(b), b, a.schema, a.retina, this.settings.apiKey || "");
            h(d);
            return d
        },
        removeBoundingBox: function() {
            a()
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.Map");
nokia.mh5.components.Map = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = nokia.mh5.i18n,
        b = nokia.mh5.event,
        c = nokia.mh5.platform,
        e = nokia.mh5.ui.Button,
        i = nokia.mh5.ui.Control,
        h = nokia.mh5.internals,
        d = 3,
        j = function() {
            return "ongestureend" in nokia.mh5.doc || c.android_webview || c.wphone || c.n9
        },
        f = nokia.mh5.win.setTimeout,
        k = nokia.mh5.win.clearTimeout,
        m = nokia.mh5.win.clearInterval,
        n = nokia.mh5.win.setInterval;
    return {
        children: ["mapLogo", "zoomButtons", "positionButton", "settingsButton", "mapContainer"],
        cssClass: "mh5_Map mh5_hwacc_viewer",
        statics: {
            MAX_ZOOM_LEVEL: h.Map.MAX_ZOOM_LEVEL,
            MIN_ZOOM_LEVEL: h.Map.MIN_ZOOM_LEVEL
        },
        passive: !1,
        zoomButtons: {
            control: nokia.mh5.ui.Container,
            children: ["zoomin", "zoomout"],
            visible: !j(),
            cssClass: "mh5_zoom",
            layout: new nokia.mh5.ui.RowLayout,
            zoomin: {
                control: e,
                cssClass: "mh5_Button mh5_zoomIn",
                onClick: function() {
                    var a = this.parent.intervalId,
                        b = this.parent.parent._map;
                    "number" === typeof a && m(a);
                    if (b.zoom < b.MAX_ZOOM_LEVEL) a = this.parent.intervalId = n(function() {
                        1.9 > b.scale ? b.scale += 0.09 : (m(a), a = void 0, b.zoom++)
                    }.bind(this), 33)
                }
            },
            zoomout: {
                control: e,
                cssClass: "mh5_Button mh5_zoomOut",
                onClick: function() {
                    var a = this.parent.intervalId,
                        b = this.parent.parent._map;
                    "number" === typeof a && m(a);
                    if (b.zoom > b.MIN_ZOOM_LEVEL) a = this.parent.intervalId = n(function() {
                        0.5 < b.scale ? b.scale -= 0.05 : (m(a), a = void 0, b.zoom--)
                    }.bind(this), 33)
                }
            }
        },
        mapContainer: {
            control: i,
            cssClass: "mh5_mapContainer"
        },
        positionButton: {
            control: e,
            cssClass: "mh5_Button position missing",
            onClick: function() {
                var a = this.parent._map;
                "available" === this.parent.positionStatus ? a.tracking = !a.tracking : this.parent.initPositioning("buttonClicked")
            }
        },
        settingsButton: {
            control: e,
            cssClass: "mh5_Button settings",
            onClick: function() {
                var a = this.parent;
                new nokia.mh5.ui.SettingsDialog({
                    traffic: a.traffic,
                    visibleDidChange: function(b) {
                        a.passive = b;
                        this.constructor.prototype.visibleDidChange.apply(this, arguments)
                    }
                })
            }
        },
        mapLogo: {
            control: i,
            cssClass: "mh5_mapLogo " + (c.tablet ? "mh5_large" : "mh5_compact"),
            innerHTML: c.tablet ? "<div class='mh5_copyright'>&copy; " + (new Date).getFullYear() + " Here.com <a>" + a("mapTermsOfUse") + "</a></div>" : "",
            onClick: function() {
                nokia.mh5.maps && nokia.mh5.maps.Application ? nokia.mh5.app.controller.switchTo("nokia.mh5.maps.AboutPage" + (c.webview ? "Native" : ""), null, {
                    intoView: ".terms"
                }) : nokia.mh5.win.open("http://m.here.net/tnc.html", "_blank")
            }
        },
        infoBubbleParams: void 0,
        positionStatus: "uninitialized",
        isReady: !1,
        addressLookup: !0,
        dontBind: !0,
        initPositioning: function(a) {
            var b = this,
                c = b._map,
                f = nokia.mh5.utils.getLocalStorageValue("mh5-isFirstTime");
            if (!this.passive && "buttonClicked" !== a && ("uninitialized" === this.positionStatus || "unavailable" === this.positionStatus)) {
                if (f && JSON.parse(f)) this._ipLookupRequest = nokia.mh5.jsonp("http://here.net/services/iplookup/get?NORD&callback", function(a) {
                    delete this._ipLookupRequest;
                    if ("available" !== b.positionStatus && !a.error && !a.errors && a.location) c.zoom = 6, c.moveTo(a.location)
                });
                this.positionStatus = "requesting";
                c.position.activate(function(a) {
                    this.positionStatus = "available";
                    if (this.moveToUserPosition) c.zoom = c.MAX_ZOOM_LEVEL - 4, c.moveTo(a)
                }.bind(this), function(a) {
                    this.positionStatus = 1 == a.code ? "denied" : "unavailable";
                    if (!c.center || !c.center.longitude || !c.center.latitude) c.zoom = d
                }.bind(this))
            }
        },
        positionStatusDidChange: function(a) {
            var b = this.positionButton && this.positionButton.root;
            if (b) if ("available" === a) nokia.mh5.dom.removeClass(b, "missing"), nokia.mh5.dom.addClass(b, "available");
            else if ("unavailable" === a) nokia.mh5.dom.addClass(b, "missing"), nokia.mh5.dom.removeClass(b, "available"), this._map.tracking = !1;
            if (this.onPositionStatusChange) this.onPositionStatusChange(a)
        },
        _onPositionLost: function() {
            this.positionStatus = "unavailable"
        },
        _setupMap: function() {
            var a = this.mapContainer.root,
                d = this._map;
            d.offset = function(a) {
                var b = 0,
                    d = 0;
                do b += a.offsetLeft, d += a.offsetTop;
                while (a = a.offsetParent);
                return {
                    top: d,
                    left: b
                }
            }(a);
            d.size = {
                width: a.offsetWidth,
                height: a.offsetHeight
            };
            Object.defineProperty(this, "pois", {
                set: function(a) {
                    var b = this.getPois();
                    0 < b.length && this.removePoi(b);
                    if (a && 0 < a.length) for (var b = 0, d = a.length; b < d; b++) this.createPoi(a[b].mapIcon || nokia.mh5.utils.place.getCategoryIcon(a[b]), a[b])
                },
                get: function() {
                    return this.getPois()
                }
            });
            i.watch(nokia.mh5.components.settings.current, "mapSchema", this, function(a) {
                if (this.schema !== a) this.schema = a
            });
            this._onMapLongPress = this._onMapLongPress.bind(this);
            this._onPoiClick = this._onPoiClick.bind(this);
            this._onPositionLost = this._onPositionLost.bind(this);
            (a = this.listeners) && nokia.mh5.each(a, function(a, c) {
                b.add("ready" == c ? this : d, c, a.bind(this))
            }, this);
            b.add(d, "mapmoveend", d.save);
            b.add(d, "mapclick", function(a) {
                a.defaultPrevented || this.hideInfoBubble()
            }.bind(this));
            b.add(d, "maplongpress", this._onMapLongPress);
            b.add(d, "poiclick", this._onPoiClick);
            b.add(d, "positionlost", this._onPositionLost)
        },
        passiveDidChange: function(a) {
            this.zoomButtons.visible = !j() && !a;
            this.positionButton && (this.positionButton.visible = !a);
            this.settingsButton && (this.settingsButton.visible = !a);
            nokia.mh5.dom[a ? "addClass" : "removeClass"](this.root, "mh5_passive");
            if (c.android_webview)!a && this.visible ? nokia.mh5.components.Map.active = this : a && nokia.mh5.components.Map.active === this && delete nokia.mh5.components.Map.active
        },
        _onSchemaChange: function(a) {
            var b = this._map,
                d = this._server;
            if (d && "normal.day" === a) try {
                d.getBoundingBox(function(a) {
                    if (null !== a) b.tileServer = d
                })
            } catch (c) {} else b.tileServer = null;
            if (this.mapLogo) nokia.mh5.dom[0 === a.indexOf("hybrid.day") ? "addClass" : "removeClass"](this.mapLogo.root, "mh5_bright");
            if (nokia.mh5.components.settings.current.mapSchema !== a) nokia.mh5.components.settings.current.mapSchema = a
        },
        _prepareAPI: function() {
            function a(d, c, f) {
                var e = {
                    get: function() {
                        return b[c]
                    }
                };
                if (f) e.set = function(a) {
                    b[c] = a;
                    "schema" === c && d._onSchemaChange(a)
                };
                f = d[c];
                Object.defineProperty(d, c, e);
                f && (d[c] = f)
            }
            var b = this._map;
            a(this, "position");
            a(this, "route", !0);
            a(this, "center", !0);
            a(this, "box", !0);
            a(this, "offset", !0);
            a(this, "geometry", !0);
            a(this, "schema", !0);
            a(this, "size", !0);
            a(this, "zoom", !0);
            a(this, "tracking", !0);
            a(this, "apiKey", !0);
            a(this, "tileServer", !0);
            a(this, "shape", !0);
            a(this, "tileLang", !0);
            a(this, "retina", !0);
            this.moveTo = b.moveTo;
            this.geoToPoint = b.geoToPoint;
            this.pointToGeo = b.pointToGeo;
            this.save = b.save;
            this.restore = b.restore;
            this.move = b.move
        },
        createPoi: function(a, b) {
            var d = this._map.createPoi(a, b);
            d.retina = !0;
            if (b.placeId) d.placeId = b.placeId;
            if (b.href) d.href = b.href;
            this._pois.push(d);
            return d
        },
        removePoi: function(a) {
            this._map.removePoi(a);
            if (a) for (var a = [].concat(a), b = 0, d; b < a.length; b++) d = this._pois.indexOf(a[b]), ~d && this._pois.splice(d, 1);
            else this._pois = []
        },
        addPoi: function(a) {
            this._map.addPoi(a);
            this._pois = this._pois.concat(a)
        },
        getPois: function(a, b) {
            if (a) {
                var d = this.comparePOIs,
                    c = this._pois.filter(function(b) {
                        return d(b, a)
                    });
                return a.placeId || b ? c[0] : c
            }
            return this._pois
        },
        _onPoiClick: function(a) {
            var b = a.data[0];
            b.infoBubble ? (a = b.image, nokia.mh5.event.fire(a, "down", {
                offsetX: b.clickedPoint.x + a.width / (this._map.retina ? 2 : 4),
                offsetY: b.clickedPoint.y + a.height / (this._map.retina ? 2 : 4)
            })) : a.defaultPrevented || (b.isPosition ? this.addressLookup && (this.hideInfoBubble(), this._triggerReverseGeoCoding(b)) : b.data.name ? (this.hideInfoBubble(), this.showInfoBubble(b)) : this._triggerReverseGeoCoding(b))
        },
        _onMapLongPress: function(a) {
            if (this.addressLookup && !a.defaultPrevented) this.hideInfoBubble(), a.data.renderOnly = !0, this._triggerReverseGeoCoding(a.data)
        },
        _triggerReverseGeoCoding: function(a) {
            var b = this,
                d = nokia.mh5.adapters.Search,
                c = a.data || a,
                f;
            d.reverseGeoCode(c, {
                appId: this.appId,
                appCode: this.appCode
            }, function(e) {
                c.renderOnly && (f = b.infoBubbleParams ? nokia.mh5.extend({
                    renderOnly: !0
                }, b.infoBubbleParams) : {
                    content: ["title"],
                    maxWidth: 245,
                    renderOnly: !0
                }, delete c.renderOnly);
                d.merge(c, e);
                b.hideInfoBubble();
                b.showInfoBubble(a, f)
            })
        },
        constructor: function(e, k) {
            this.getPoi = this.getPois;
            this.infoBubbles = [];
            this._pois = [];
            this._layer = {};
            this.resize = this.resize.bind(this);
            this._orientationOrResizeHappened = 0;
            var i, j, m;
            if (e) {
                if (e.listeners) i = e.listeners, delete e.listeners;
                if (e.infobubble || e.infoBubble) {
                    if (e.infobubble) e.infoBubble = e.infobubble;
                    this.infoBubbleParams = e.infoBubble;
                    delete e.infoBubble
                }
            }
            g.constructor.call(this, e, k);
            this.appId = this.appId || nokia.mh5.appId;
            this.appCode = this.appCode || nokia.mh5.appCode;
            if (!this.appId || !this.appCode) throw Error(a("Error.applicationCredential"));
            if (i) this.listeners = e.listeners = i;
            i = this.root;
            c.android && nokia.mh5.dom.addEvent(i, "mousemove", function(a) {
                a.stopPropagation();
                a.preventDefault()
            }, !0);
            j = this._map = new h.Map(this.mapContainer.root, i.offsetWidth || 10, i.offsetHeight || 10);
            j.apiKey = {
                appId: this.appId,
                appCode: this.appCode
            };
            j.tileLang = nokia.mh5.l10n.tileLanguageMap[nokia.mh5.i18n.language.substr(0, 2)];
            this._cartoPOI = new h.CartoPOI(this, j);
            c.offlineStorageSupported && (this._server = new h.SQLTileServer({
                apiKey: j.apiKey,
                tileLang: j.tileLang,
                retina: j.retina
            }));
            d = this._map.MIN_ZOOM_LEVEL;
            (!e || null == e.suggestions || e.suggestions) && !this.passive && this._cartoPOI.activate();
            this.prepareBindings();
            this.prepareDidChangeNotifications();
            if (!j.restore()) j.center = {
                latitude: 52.52081,
                longitude: 13.38855
            }, j.zoom = d, this.moveToUserPosition = e && e.hasOwnProperty("moveToUserPosition") ? !! e.moveToUserPosition : !0;
            if (m = this.positionButton) b.add(j, "maptrackingstart", function() {
                nokia.mh5.dom.addClass(m.root, "tracking")
            }), b.add(j, "maptrackingend", function() {
                nokia.mh5.dom.removeClass(m.root, "tracking")
            });
            this._prepareAPI();
            f(function() {
                this._setupMap();
                if (this.mapLogo) nokia.mh5.dom[0 === j.schema.indexOf("hybrid.day") ? "addClass" : "removeClass"](this.mapLogo.root, "mh5_bright");
                this.initPositioning();
                this.isReady = !0;
                b.fire(this, "ready")
            }.bind(this), 0)
        },
        resize: function() {
            k(this._orientationOrResizeHappened);
            this._orientationOrResizeHappened = f(function() {
                var a = this.root,
                    d = a.offsetWidth,
                    a = a.offsetHeight;
                this._orientationOrResizeHappened = 0;
                if (d && a && (d !== this._map.size.width || a !== this._map.size.height)) this._map.size = {
                    width: d,
                    height: a
                }, b.fire(this, "sizechange", this.size)
            }.bind(this), c.hideAddressBar.DELAY + 50)
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.apply(this, arguments);
            if (a) {
                if (this._map.resume(), nokia.mh5.dom.addEvent(nokia.mh5.win, "viewportchange", this.resize, !1), this.resize(), c.android_webview && !this.passive) nokia.mh5.components.Map.active = this
            } else this._map.pause(), nokia.mh5.dom.removeEvent(nokia.mh5.win, "viewportchange", this.resize, !1), c.android_webview && nokia.mh5.components.Map.active === this && delete nokia.mh5.components.Map.active
        },
        showInfoBubble: function(a, b) {
            b = b || a.data.infoBubbleParams || this.infoBubbleParams || {
                content: ["title"],
                maxWidth: 245
            };
            if (!a.infoBubble) {
                if (!b.listeners && this.infoBubbleParams && this.infoBubbleParams.listeners) b.listeners = this.infoBubbleParams.listeners;
                a.infoBubble = !0;
                a.retina = !0;
                var d = this._map,
                    c = this,
                    e;
                c._infoBubbleAnimationTimerId && (m(c._infoBubbleAnimationTimerId), delete c._infoBubbleAnimationTimerId);
                b.maxWidth = Math.max(c._map.size.width - 50, 245);
                if (!b.parent) b.parent = c;
                a.image ? a.originalImage = a.image : (e = d.createPoi(nokia.mh5.doc.createElement("CANVAS"), a), e.locationX = a.locationX, e.locationY = a.locationY, e.infoBubble = !0, e.retina = !0, delete e.data.infoBubble, a = e);
                e = new nokia.mh5.components.InfoBubble(a.data, b, function t(e) {
                    if (a.infoBubble) 20 > d.size.width ? f(function() {
                        t(e)
                    }, 5) : (a.image = e, "privilegeLevel" in b ? a.privilegeLevel = b.privilegeLevel : a.privileged = !0, a.scale = 0.7, c._infoBubbleAnimationTimerId = n(function(a) {
                        a.scale += 0.2;
                        if (0.9 < a.scale && (m(c._infoBubbleAnimationTimerId), delete c._infoBubbleAnimationTimerId, a.scale = 1, !b.renderOnly)) {
                            var f = d.retina,
                                h = d.geoToPoint(d.center),
                                g = d.geoToPoint(a),
                                k = h.x,
                                a = h.y,
                                i = g.x,
                                g = g.y,
                                j = d.size,
                                l = j.width / (f ? 1 : 2),
                                z = e.width / (f ? 2 : 4),
                                C = k + l,
                                k = k - l + d.geometry.left * (f ? 2 : 1),
                                l = i - z,
                                z = i + z,
                                i = !1;
                            l < k ? (h.x -= k + 16 - l, i = !0) : C < z && (h.x += z + 16 - C, i = !0);
                            l = j.height / (f ? 1 : 2);
                            z = e.height / (f ? 1 : 2);
                            C = a + l;
                            k = a - l + d.geometry.top * (f ? 2 : 1);
                            l = g - z;
                            z = g + z;
                            l < k ? (h.y -= k + 16 - l, i = !0) : C < z && (h.y += z + 16 - C, i = !0);
                            i && (h.x += d.geometry.left / 2, h.y += d.geometry.top / 2, d.moveTo(d.pointToGeo(h)))
                        }
                    }, 40, a))
                });
                e.poi = a;
                c.infoBubbles.push(e)
            }
        },
        hideInfoBubble: function(a) {
            var b;
            if (a) Array.isArray(a) || (a = [a]);
            else {
                if (0 === this.infoBubbles.length) return;
                a = this.infoBubbles;
                this.infoBubbles = []
            }
            for (var d = 0, c = a.length; d < c; d++) b = a[d], this.infoBubbles.splice(this.infoBubbles.indexOf(b), 1), b = b.poi, delete b.infoBubble, b.originalImage ? (b.image = b.originalImage, delete b.originalImage, b.privileged = !1) : this._map.removePoi(b)
        },
        addLayer: function(a, b) {
            var d = this._map,
                c = [].concat(d.layer || []);
            if (0 > c.indexOf(a)) d.layer = c.concat(a), "string" == typeof b && (this._layer[b] = d.layer[d.layer.length - 1])
        },
        removeLayer: function(a) {
            var b, d, c = [].concat(this._map.layer || []);
            switch (typeof a) {
            case "string":
                if ("function" == typeof(b = this._layer[a])) if (~ (b = c.indexOf(b))) c.splice(b, 1), c.length ? (this._map.layer = c, delete this._layer[a]) : (this._map.layer = null, this._layer = {});
                break;
            case "function":
                if (~ (b = c.indexOf(a))) if (c.splice(b, 1), c.length) for (d in this._map.layer = c, this._layer) {
                    if (this._layer[d] == a) {
                        delete this._layer[d];
                        break
                    }
                } else this._map.layer = null, this._layer = {}
            }
        },
        hasLayer: function(a) {
            return "string" == typeof a && "function" == typeof this._layer[a] || "function" == typeof a && ~ [].concat(this._map.layer || []).indexOf(a) ? !0 : !1
        },
        comparePOIs: function(a, b) {
            return a.placeId ? a.placeId === b.placeId : a.latitude === b.latitude && a.longitude === b.longitude
        },
        covers: function(a) {
            function b(a) {
                a = c(a);
                return a.x < f.x || a.x > e.x || a.y < f.y || a.y > e.y
            }
            var d = this.box,
                c = this.geoToPoint,
                f = c(d[0]),
                e = c(d[1]);
            return !Array.isArray(a) ? !b(a) : !a.some(b)
        },
        storeTiles: function(a) {
            var b = this._server;
            if (b) return b = b.storeBoundingBox(this._map, a && a.box), a && a.callback && (b.onprogress = a.callback), a && !a.hold && b.start(), b
        },
        showStoredTiles: function(a, b) {
            var d = this,
                c = this._map,
                f = this._server;
            f ? f.getBoundingBox(function(e, h, g, k, i) {
                e ? (nokia.mh5.components.settings.set("retinaTiles", i), d.retinaTilesDidChange(i), c.tileServer = f, c.box = e, c.zoom = h, c.schema = k, a && a(e, h, k, i)) : b && b()
            }) : b && b()
        },
        removeStoredTiles: function() {
            this._server && this._server.removeBoundingBox()
        },
        retinaTilesBinding: "nokia.mh5.components.settings#current.retinaTiles",
        retinaTilesDidChange: function(a) {
            if (this._server instanceof h.SQLTileServer) this._server.retina = a;
            this._map.retina = a
        }
    }
});
nokia.mh5.provide("nokia.mh5.app.controller");
(function() {
    var g = nokia.mh5.history,
        a = {},
        b = {},
        c = nokia.mh5.doc.title,
        e = function(a) {
            for (var b in mappings) if (mappings[b] === a) return b
        },
        i = function(a, b) {
            return {
                page: a,
                params: b,
                onPopState: function(a, b) {
                    nokia.mh5.app.controller.currentViewState = a;
                    nokia.mh5.app.controller.switchTo(a.page, a.params, {
                        dontPushToHistory: !0,
                        isHistory: !b
                    })
                }
            }
        },
        h = nokia.mh5.app.controller = {
            queue: [],
            setConfiguration: function(a) {
                b = a
            },
            getPage: function(d) {
                return b[d] ? a[d] || (a[d] = b[d] instanceof nokia.mh5.Class ? new b[d] : new nokia.mh5.ui.Page(b[d])) : new(nokia.mh5.require(d))
            },
            resetViewCache: function() {
                a = {}
            },
            getMap: function() {
                var a = this.current.page;
                return a.map ? a.map : a.children.map(function(b) {
                    return nokia.mh5.resolve(b + ".map", a)
                }).filter(function(a) {
                    return !!a && a instanceof nokia.mh5.components.Map
                }).pop()
            },
            switchTo: function(a, b, c) {
                var e = this,
                    g = e.domNode || nokia.mh5.doc.body,
                    i = e.current,
                    l = h.getPage(a);
                if (e.inTransition) e.queue.unshift(arguments);
                else if (e.current = {
                    name: a,
                    page: l
                }, b && l.setModel(b), c && c.replaceLastHistoryEntry ? e.updateHistoryEntry() : (!c || !c.dontPushToHistory) && e.pushHistoryEntry(e.current.name, l.getNavigationState(), l.getHash()), !(i && i.name === a)) if (nokia.mh5.platform.ios && ("TEXTAREA" === document.activeElement.tagName || "INPUT" === document.activeElement.tagName) && document.activeElement.blur(), i) e.inTransition = !0, nokia.mh5.dom.doTransition({
                    type: "slide",
                    parentNode: g,
                    node: l.root,
                    previousNode: i.page.root,
                    isHistory: c && c.isHistory,
                    onNodeAttached: function() {
                        if (!l.visible) l.visible = !0, c && c.intoView && l.intoView && l.intoView(c.intoView)
                    },
                    callback: function() {
                        var a = nokia.mh5.win,
                            b = a.document.createEvent("Event");
                        e.inTransition = !1;
                        i.page.visible = !1;
                        0 < e.queue.length ? a.setTimeout(function() {
                            e.switchTo.apply(e, e.queue.shift())
                        }, 0) : (b.initEvent("hideAddressBar", !0, !0), a.dispatchEvent(b))
                    }
                });
                else if (g.appendChild(l.root), !l.visible) l.visible = !0, c && c.intoView && l.intoView && l.intoView(c.intoView)
            },
            updateHistoryEntry: function() {
                if (this.browserHistory) {
                    var a = this.current.name,
                        b = this.current.page,
                        f = this.currentViewState = i(a, b.getNavigationState()),
                        h = e(a),
                        h = h && this.manipulateUrl ? "#action=" + h + "&params=" + encodeURIComponent(b.getHash()) + "&bmk=1" : "";
                    b.model && b.model.traffic && (h += "&traffic=true");
                    g.replaceState(f, c || a, h)
                }
            },
            pushHistoryEntry: function(a, b, f) {
                if (this.browserHistory) {
                    var b = this.currentViewState = i(a, b),
                        h = e(a),
                        f = h && this.manipulateUrl ? "#action=" + h + "&params=" + encodeURIComponent(f) + "&bmk=1" : "";
                    g.pushState(b, c || a, f)
                }
            },
            back: function() {
                this.browserHistory && g.back()
            },
            showOnMap: function(a) {
                this.switchTo("search", a)
            },
            route: function(a) {
                if (a && a.from && a.to) {
                    var b = "walk";
                    5E3 < nokia.mh5.math.pointDistance(a.from, a.to) && (b = "drive");
                    a.parameters = a.parameters || {};
                    a.parameters.mode = b
                }
                this.switchTo("route", a)
            },
            share: function(a) {
                this.switchTo("share", {
                    data: a
                })
            },
            details: function(a) {
                this.switchTo("search", {
                    selection: a,
                    mapMode: !0,
                    showDetails: !0
                })
            },
            navigate: function(a, b) {
                this.switchTo("navigation", {
                    to: a,
                    _route: b
                })
            }
        }
})();
nokia.mh5.provide("nokia.mh5.adapters.Route");
(function() {
    function g(a) {
        return !a.length || 2 > a.length ? [] : a.map(function(b, d) {
            var c = !d,
                f = d === a.length - 1,
                e = f ? /\.?\s*The trip takes.*<\/span>/ : /\s*<span class="distance-description">.*<\/span>/,
                g = f && a[d - 1].shape ? a[d - 1].shape.slice(-2) : b.shape,
                k = b.instruction.match(/<span class="direction">(\w+)<\/span>/),
                i = d && !("action" in a[d - 1]) && "forward" === b.direction,
                j = b.instruction.slice(0, 4).toLowerCase();
            if ("bear" === j && k && k[1]) b.direction = j + (k[1].charAt(0).toUpperCase() + k[1].slice(1));
            return {
                action: c && "depart" || f && "arrive" || !i && b.direction,
                direction: f && k && k[1],
                instruction: b.instruction.replace(e, ""),
                first: c,
                last: f,
                iconIndex: "action" in b ? h[b.action] : h[b.direction],
                distance: b.length,
                latitude: b.position.latitude,
                longitude: b.position.longitude,
                shape: g && g.reduce(function(a, b, d, c) {
                    return d % 2 ? a : a.concat([{
                        latitude: b,
                        longitude: c[d + 1]
                    }])
                }, f ? [{
                    latitude: g[g.length - 2],
                    longitude: g[g.length - 1]
                }] : [])
            }
        })
    }
    function a(a) {
        if (!a.length || 2 > a.length) return [];
        a[0].name = k;
        a[a.length - 1].name = m;
        return a.map(function(b, d) {
            var c, h = "",
                g, k = 0 === d,
                i = d === a.length - 1;
            c = k || i ? j[k ? 0 : 2] + '<span class="mh5_pt_highlight">' + b.name + "</span>" : "<span>" + j[1] + b.name + "</span>";
            if (!i) if (h = f[b.action], 0 === b.action) {
                if ((g = a[d + 1]) && (g.name || g.line)) h += '<span class="mh5_pt_highlight">' + (g.name !== b.name || !g.line ? g.name : g.line) + "</span>"
            } else 1 === b.action && (h = 0 <= h.indexOf("{0}") ? h.replace("{0}", '<span class="mh5_pt_highlight">' + (b.line || "") + "</span>") : h, h += '<span class="mh5_pt_highlight">' + b.direction + "</span><br>", h += '<span class="mh5_pt_light">' + (1 < b.stops ? e("RA.forXStops", {
                stops: b.stops
            }) : e("RA.for1Stop")) + "</span>");
            return {
                waypoint: c,
                wIconIndex: 0,
                action: h,
                aIconIndex: 0,
                first: k,
                last: i,
                duration: b.duration,
                color: b.color,
                latitude: b.position.latitude,
                longitude: b.position.longitude
            }
        })
    }
    function b(a, b, c, f) {
        var h, g, k = b.mode,
            j = a[0],
            l = a[a.length - 1];
        if ("pt" === k) h = "http://m.here.com/releases/1.8.44/server/PublicTransport.php", g = {
            slat: j.latitude,
            slon: j.longitude,
            dlat: l.latitude,
            dlon: l.longitude,
            date: (b.departure || new Date(Date.now() - 6E4 * (new Date).getTimezoneOffset() + 9E5)).toISOString().substr(0, 19)
        }, a = "jsonp";
        else {
            h = "http://route.nlp.nokia.com/routing/6.2/calculateroute.json";
            g = {
                app_id: b.appId,
                token: b.appCode,
                mode: [b.type || "fastest", "drive" === k ? "car" : "pedestrian", "traffic:" + ("walk" === k || !1 === b.traffic ? "disabled" : "enabled")].join(";"),
                routeattributes: "sh,bb,sm",
                maneuverattributes: "po,le,ac,di" + ("walk" === k ? ",sh" : ""),
                instructionformat: "html",
                jsonAttributes: "33",
                departure: b.departure && b.departure.toISOString() || "now",
                language: e.getIsoLanguage()
            };
            a.forEach(function(a, b) {
                g["waypoint" + b] = a.latitude + "," + a.longitude
            });
            b.features && (g.mode += ";" + Object.keys(b.features).map(function(a) {
                return a + ":" + b.features[a]
            }).join(","));
            if (b.zoom) g.resolution = d[b.zoom];
            a = "jsoncallback"
        }
        h += "?" + i.formatURLParams(g) + "&" + a;
        n && n.cancel();
        n = nokia.mh5.jsonp(h, function(a) {
            a.error ? f && f(a.error) : c(a.response)
        }, 6E4)
    }
    function c(a, b, d) {
        var c = "http://route.nlp.nokia.com/routing/6.2/getroute.json",
            f = a.mode,
            a = {
                routeId: a.routeId,
                app_id: a.appId,
                token: a.appCode,
                mode: [a.type || "fastest", "drive" === f ? "car" : "pedestrian", "traffic:" + ("walk" === f || !1 === a.traffic ? "disabled" : "enabled")].join(";"),
                routeattributes: "sh,-legs,-wp,-sm,-li,-no",
                jsonAttributes: "33",
                departure: a.departure && a.departure.toISOString() || "now"
            },
            c = c + ("?" + i.formatURLParams(a) + "&jsoncallback");
        l && l.cancel();
        l = nokia.mh5.jsonp(c, function(a) {
            var c = a.response;
            !a.error && c && c.route ? (a = c.route.shape, b(a)) : d && d(a.error)
        }, 6E4)
    }
    var e = nokia.mh5.i18n,
        i = nokia.mh5.utils,
        h = {
            depart: 0,
            departAirport: 0,
            arrive: 0,
            arriveAirport: 0,
            arriveLeft: 0,
            arriveRight: 0,
            leftLoop: 5,
            leftUTurn: 3,
            sharpLeftTurn: 11,
            leftTurn: 9,
            slightLeftTurn: 7,
            "continue": 0,
            slightRightTurn: 6,
            rightTurn: 8,
            sharpRightTurn: 10,
            rightUTurn: 2,
            rightLoop: 4,
            leftExit: 17,
            rightExit: 16,
            leftRamp: 19,
            rightRamp: 18,
            leftFork: 21,
            middleFork: 1,
            rightFork: 20,
            leftMerge: 15,
            rightMerge: 14,
            nameChange: 1,
            trafficCircle: 48,
            ferry: 47,
            leftRoundaboutExit1: 34,
            leftRoundaboutExit2: 35,
            leftRoundaboutExit3: 36,
            leftRoundaboutExit4: 37,
            leftRoundaboutExit5: 38,
            leftRoundaboutExit6: 39,
            leftRoundaboutExit7: 40,
            leftRoundaboutExit8: 41,
            leftRoundaboutExit9: 42,
            leftRoundaboutExit10: 43,
            leftRoundaboutExit11: 44,
            leftRoundaboutExit12: 45,
            rightRoundaboutExit1: 22,
            rightRoundaboutExit2: 23,
            rightRoundaboutExit3: 24,
            rightRoundaboutExit4: 25,
            rightRoundaboutExit5: 26,
            rightRoundaboutExit6: 27,
            rightRoundaboutExit7: 28,
            rightRoundaboutExit8: 29,
            rightRoundaboutExit9: 30,
            rightRoundaboutExit10: 31,
            rightRoundaboutExit11: 32,
            rightRoundaboutExit12: 33,
            forward: 0,
            uTurnRight: 2,
            bearRight: 4,
            lightRight: 6,
            right: 8,
            hardRight: 10,
            uTurnLeft: 3,
            bearLeft: 5,
            lightLeft: 7,
            left: 9,
            hardLeft: 11
        },
        d = {
            3: 12578,
            4: 6289,
            5: 3145,
            6: 1572,
            7: 786,
            8: 393,
            9: 197,
            10: 98,
            11: 49,
            12: 25,
            13: 12,
            14: 8,
            15: 1,
            16: 1,
            17: 1,
            18: 1,
            19: 1,
            20: 1
        },
        j = ["<span>" + e("RA.departFrom") + "</span> ", e("RA.Station") + " ", "<span>" + e("RA.arriveAt") + "</span> "],
        f = ["<span>" + e("RA.walkTo") + "</span> ", "<span>" + e("take") + "</span> {0} <span>" + e("towards") + "</span> "],
        k = "Start",
        m = "",
        n, l;
    nokia.mh5.adapters.Route = {
        fetch: function(f, h, i, j, l) {
            var n, q, s = function(b) {
                    var f = b && b.route && (b.route[0] ? b.route[0] : b.route),
                        e = "pt" === h.mode ? a : g;
                    if (f && f.shape && f.shape.length) {
                        b = f.summary;
                        e = {
                            box: b.bbox || f.boundingBox && [f.boundingBox.topLeft, f.boundingBox.bottomRight] || f.shape,
                            shape: f.shape,
                            summary: {
                                distance: b.distance || 0,
                                time: b.trafficTime || b.baseTime
                            },
                            maneuvers: e(f.maneuvers || Array.prototype.concat.apply([], f.leg.map(function(a) {
                                return a.maneuver
                            })), this.ename)
                        };
                        if (b.disclaimers) e.summary.disclaimers = b.disclaimers;
                        "drive" === h.mode && h.updateCallback && 1 < d[h.zoom] && c(nokia.mh5.extend({
                            routeId: f.routeId
                        }, h), h.updateCallback);
                        i(e)
                    } else x.call(b && b.error)
                },
                x = function(a) {
                    var b = h.mode;
                    "timeout" === a ? a = e("Notification.noRoutingService") : "pt" === b ? "too near" === a ? a = e("Notification.destInWalkingDistance") : "unavailable" === a && (a = e("Notification.noPublicTransportService")) : a || (b = e("Notification.noModeAvailable", {
                        mode: e("RA." + b)
                    }), a = b.charAt(0).toUpperCase() + b.slice(1));
                    j(a || e("Notification.noRoutingService"))
                },
                r, J;
            if (Array.isArray(f) && 2 <= f.length) n = f[0], q = f[f.length - 1];
            else if (f && f.hasOwnProperty("latitude") && f.hasOwnProperty("longitude") && h && h.hasOwnProperty("latitude") && h.hasOwnProperty("longitude")) n = f, q = h, f = [n, q], h = i, i = j, j = l;
            else {
                j(e("Notification.error"));
                return
            }
            r = h.appId = h.appId || nokia.mh5.appId;
            J = h.appCode = h.appCode || nokia.mh5.appCode;
            j = j ||
            function() {};
            if (!r || !J) throw Error(e("Error.applicationCredential"));
            if ("pt" === h.mode) if (m = q.name, n.name) k = n.name;
            else var F = s,
                s = function(a) {
                    nokia.mh5.adapters.Search.reverseGeoCode(n, {
                        appId: r,
                        appCode: J
                    }, function(b) {
                        k = b.name;
                        F.call(this, a)
                    }, x)
                };
            b(f, h, s, x)
        }
    }
})();
nokia.mh5.provide("nokia.mh5.components.RouteListItem");
nokia.mh5.components.RouteListItem = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    var a = nokia.mh5.i18n;
    return {
        rootHtmlElementName: "li",
        cssClass: "mh5_ListItem",
        constructor: function(a, c) {
            g.constructor.call(this, a, c);
            this.update()
        },
        update: function() {
            var b;
            b = this.first && " mh5_maneuver_start" || this.last && " mh5_maneuver_end" || "";
            var c = "";
            this.waypoint ? (nokia.mh5.dom.addClass(this.root, " mh5_pt"), c = 0 <= this.action.indexOf("Walk") ? " mh5_pt_walk" : " mh5_pt_tube", b = '<div class="mh5_pt_waypoint' + b + '"><div><\!--waypoint icon--\></div>' + ("<div>" + this.waypoint + "</div>"), b += "</div>", this.last || (b += '<div class="mh5_pt_line" style="background-color:' + this.color + '"></div>', nokia.mh5.dom.addClass(this.root, c), b = b + '<div class="mh5_pt_action"><div><\!--action icon--\></div>' + ("<div>" + this.action + "</div>"), b += "</div>"), this.root.innerHTML = b) : ((this.first || this.last) && (this.iconIndex = 0), b = "<div>" + ('<div class="mh5_ListItem_icon' + b + '"></div>') + "<div>" + ('<div class="mh5_ListItem_name">' + this.instruction + "</div>"), this.distance && (b += '<div class="mh5_ListItem_address">' + a("followFor") + " <span>" + nokia.mh5.utils.formatDistance(this.distance, nokia.mh5.components.settings.current.unitSystem) + "</span></div>"), this.root.innerHTML = b + "</div></div>", this.root.firstChild.firstChild.style.backgroundPosition = -3.6 * this.iconIndex + "rem 0")
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.Navigation");
nokia.mh5.components.Navigation = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = nokia.mh5.i18n,
        b = 35,
        c, e, i, h = !0,
        d = "onplay" in document.createElement("audio"),
        j = nokia.mh5.dom,
        f = nokia.mh5.event,
        k = nokia.mh5.geolocation,
        m = nokia.mh5.math,
        n, l = nokia.mh5.utils.formatString,
        o = function(a, b, d, c) {
            return c[d + 1] ? a + m.pointDistance(b, c[d + 1]) : a
        },
        u = function(a) {
            return this.distance >= a - this.margin && this.distance <= a + this.margin
        },
        w = nokia.mh5.ui.Notification,
        v = nokia.mh5.adapters.Route,
        y = {
            arrive_km: {
                start: 0,
                duration: 2523
            },
            arrive_100_km: {
                start: 3.023,
                duration: 5134
            },
            arrive_1000_km: {
                start: 8.657,
                duration: 4941
            },
            arrive_200_km: {
                start: 14.098,
                duration: 5130
            },
            arrive_2000_km: {
                start: 19.728,
                duration: 4961
            },
            arrive_300_km: {
                start: 25.189,
                duration: 5174
            },
            arrive_400_km: {
                start: 30.863,
                duration: 5205
            },
            arrive_50_km: {
                start: 36.568,
                duration: 4993
            },
            arrive_500_km: {
                start: 42.061,
                duration: 5203
            },
            arrive_750_km: {
                start: 47.764,
                duration: 6253
            },
            arrive_left_km: {
                start: 54.517,
                duration: 3926
            },
            arrive_right_km: {
                start: 58.943,
                duration: 3823
            },
            bearLeft_km: {
                start: 63.266,
                duration: 2728
            },
            bearLeft_100_km: {
                start: 66.494,
                duration: 4154
            },
            bearLeft_1000_km: {
                start: 71.148,
                duration: 3961
            },
            bearLeft_200_km: {
                start: 75.609,
                duration: 4150
            },
            bearLeft_2000_km: {
                start: 80.259,
                duration: 3982
            },
            bearLeft_300_km: {
                start: 84.741,
                duration: 4194
            },
            bearLeft_400_km: {
                start: 89.435,
                duration: 4225
            },
            bearLeft_50_km: {
                start: 94.16,
                duration: 4013
            },
            bearLeft_500_km: {
                start: 98.673,
                duration: 4224
            },
            bearLeft_750_km: {
                start: 103.397,
                duration: 5273
            },
            bearRight_km: {
                start: 109.17,
                duration: 2713
            },
            bearRight_100_km: {
                start: 112.383,
                duration: 4139
            },
            bearRight_1000_km: {
                start: 117.022,
                duration: 3945
            },
            bearRight_200_km: {
                start: 121.467,
                duration: 4135
            },
            bearRight_2000_km: {
                start: 126.102,
                duration: 3966
            },
            bearRight_300_km: {
                start: 130.568,
                duration: 4178
            },
            bearRight_400_km: {
                start: 135.246,
                duration: 4209
            },
            bearRight_50_km: {
                start: 139.955,
                duration: 3998
            },
            bearRight_500_km: {
                start: 144.453,
                duration: 4208
            },
            bearRight_750_km: {
                start: 149.161,
                duration: 5258
            },
            depart_E_km: {
                start: 154.919,
                duration: 4176
            },
            depart_N_km: {
                start: 159.595,
                duration: 4293
            },
            depart_NE_km: {
                start: 164.388,
                duration: 4502
            },
            depart_NW_km: {
                start: 169.39,
                duration: 4588
            },
            depart_S_km: {
                start: 174.478,
                duration: 4340
            },
            depart_SE_km: {
                start: 179.318,
                duration: 4540
            },
            depart_SW_km: {
                start: 184.358,
                duration: 4622
            },
            depart_W_km: {
                start: 189.48,
                duration: 4301
            },
            forward_km: {
                start: 194.281,
                duration: 3639
            },
            forward_100_km: {
                start: 198.42,
                duration: 5065
            },
            forward_1000_km: {
                start: 203.985,
                duration: 4872
            },
            forward_200_km: {
                start: 209.357,
                duration: 5061
            },
            forward_2000_km: {
                start: 214.918,
                duration: 4892
            },
            forward_300_km: {
                start: 220.31,
                duration: 5105
            },
            forward_400_km: {
                start: 225.915,
                duration: 5136
            },
            forward_50_km: {
                start: 231.551,
                duration: 4924
            },
            forward_500_km: {
                start: 236.975,
                duration: 5134
            },
            forward_750_km: {
                start: 242.609,
                duration: 6184
            },
            hardLeft_km: {
                start: 249.293,
                duration: 3312
            },
            hardLeft_100_km: {
                start: 253.105,
                duration: 4738
            },
            hardLeft_1000_km: {
                start: 258.343,
                duration: 4545
            },
            hardLeft_200_km: {
                start: 263.388,
                duration: 4734
            },
            hardLeft_2000_km: {
                start: 268.622,
                duration: 4565
            },
            hardLeft_300_km: {
                start: 273.687,
                duration: 4778
            },
            hardLeft_400_km: {
                start: 278.965,
                duration: 4809
            },
            hardLeft_50_km: {
                start: 284.274,
                duration: 4597
            },
            hardLeft_500_km: {
                start: 289.371,
                duration: 4807
            },
            hardLeft_750_km: {
                start: 294.678,
                duration: 5857
            },
            hardRight_km: {
                start: 301.035,
                duration: 3279
            },
            hardRight_100_km: {
                start: 304.814,
                duration: 4704
            },
            hardRight_1000_km: {
                start: 310.018,
                duration: 4511
            },
            hardRight_200_km: {
                start: 315.029,
                duration: 4701
            },
            hardRight_2000_km: {
                start: 320.23,
                duration: 4532
            },
            hardRight_300_km: {
                start: 325.262,
                duration: 4744
            },
            hardRight_400_km: {
                start: 330.506,
                duration: 4775
            },
            hardRight_50_km: {
                start: 335.781,
                duration: 4563
            },
            hardRight_500_km: {
                start: 340.844,
                duration: 4774
            },
            hardRight_750_km: {
                start: 346.118,
                duration: 5823
            },
            left_km: {
                start: 352.441,
                duration: 2738
            },
            left_100_km: {
                start: 355.679,
                duration: 4163
            },
            left_1000_km: {
                start: 360.342,
                duration: 3970
            },
            left_200_km: {
                start: 364.812,
                duration: 4160
            },
            left_2000_km: {
                start: 369.472,
                duration: 3991
            },
            left_300_km: {
                start: 373.963,
                duration: 4203
            },
            left_400_km: {
                start: 378.666,
                duration: 4234
            },
            left_50_km: {
                start: 383.4,
                duration: 4022
            },
            left_500_km: {
                start: 387.922,
                duration: 4233
            },
            left_750_km: {
                start: 392.655,
                duration: 5282
            },
            lightLeft_km: {
                start: 398.437,
                duration: 3152
            },
            lightLeft_100_km: {
                start: 402.089,
                duration: 4578
            },
            lightLeft_1000_km: {
                start: 407.167,
                duration: 4385
            },
            lightLeft_200_km: {
                start: 412.052,
                duration: 4574
            },
            lightLeft_2000_km: {
                start: 417.126,
                duration: 4405
            },
            lightLeft_300_km: {
                start: 422.031,
                duration: 4618
            },
            lightLeft_400_km: {
                start: 427.149,
                duration: 4649
            },
            lightLeft_50_km: {
                start: 432.298,
                duration: 4437
            },
            lightLeft_500_km: {
                start: 437.235,
                duration: 4647
            },
            lightLeft_750_km: {
                start: 442.382,
                duration: 5697
            },
            lightRight_km: {
                start: 448.579,
                duration: 3093
            },
            lightRight_100_km: {
                start: 452.172,
                duration: 4519
            },
            lightRight_1000_km: {
                start: 457.191,
                duration: 4325
            },
            lightRight_200_km: {
                start: 462.016,
                duration: 4515
            },
            lightRight_2000_km: {
                start: 467.031,
                duration: 4346
            },
            lightRight_300_km: {
                start: 471.877,
                duration: 4558
            },
            lightRight_400_km: {
                start: 476.935,
                duration: 4590
            },
            lightRight_50_km: {
                start: 482.025,
                duration: 4378
            },
            lightRight_500_km: {
                start: 486.903,
                duration: 4588
            },
            lightRight_750_km: {
                start: 491.991,
                duration: 5638
            },
            right_km: {
                start: 498.129,
                duration: 2785
            },
            right_100_km: {
                start: 501.414,
                duration: 4211
            },
            right_1000_km: {
                start: 506.125,
                duration: 4017
            },
            right_200_km: {
                start: 510.642,
                duration: 4207
            },
            right_2000_km: {
                start: 515.349,
                duration: 4038
            },
            right_300_km: {
                start: 519.887,
                duration: 4250
            },
            right_400_km: {
                start: 524.637,
                duration: 4281
            },
            right_50_km: {
                start: 529.418,
                duration: 4070
            },
            right_500_km: {
                start: 533.988,
                duration: 4280
            },
            right_750_km: {
                start: 538.768,
                duration: 5329
            },
            uTurnLeft_km: {
                start: 544.597,
                duration: 3346
            },
            uTurnLeft_100_km: {
                start: 548.443,
                duration: 4772
            },
            uTurnLeft_1000_km: {
                start: 553.715,
                duration: 4579
            },
            uTurnLeft_200_km: {
                start: 558.794,
                duration: 4768
            },
            uTurnLeft_2000_km: {
                start: 564.062,
                duration: 4599
            },
            uTurnLeft_300_km: {
                start: 569.161,
                duration: 4812
            },
            uTurnLeft_400_km: {
                start: 574.473,
                duration: 4843
            },
            uTurnLeft_50_km: {
                start: 579.816,
                duration: 4631
            },
            uTurnLeft_500_km: {
                start: 584.947,
                duration: 4841
            },
            uTurnLeft_750_km: {
                start: 590.288,
                duration: 5891
            },
            uTurnRight_km: {
                start: 596.679,
                duration: 3324
            },
            uTurnRight_100_km: {
                start: 600.503,
                duration: 4749
            },
            uTurnRight_1000_km: {
                start: 605.752,
                duration: 4556
            },
            uTurnRight_200_km: {
                start: 610.808,
                duration: 4746
            },
            uTurnRight_2000_km: {
                start: 616.054,
                duration: 4577
            },
            uTurnRight_300_km: {
                start: 621.131,
                duration: 4789
            },
            uTurnRight_400_km: {
                start: 626.42,
                duration: 4820
            },
            uTurnRight_50_km: {
                start: 631.74,
                duration: 4608
            },
            uTurnRight_500_km: {
                start: 636.848,
                duration: 4819
            },
            uTurnRight_750_km: {
                start: 642.167,
                duration: 5868
            },
            arrive_mi: {
                start: 0,
                duration: 2523
            },
            arrive_100_mi: {
                start: 3.023,
                duration: 5144
            },
            arrive_1600_mi: {
                start: 8.667,
                duration: 4865
            },
            arrive_200_mi: {
                start: 14.032,
                duration: 5140
            },
            arrive_300_mi: {
                start: 19.672,
                duration: 5183
            },
            arrive_400_mi: {
                start: 25.355,
                duration: 5215
            },
            arrive_50_mi: {
                start: 31.07,
                duration: 5003
            },
            arrive_500_mi: {
                start: 36.573,
                duration: 5213
            },
            arrive_800_mi: {
                start: 42.286,
                duration: 4501
            },
            arrive_left_mi: {
                start: 47.287,
                duration: 3926
            },
            arrive_right_mi: {
                start: 51.713,
                duration: 3823
            },
            bearLeft_mi: {
                start: 56.036,
                duration: 2728
            },
            bearLeft_100_mi: {
                start: 59.264,
                duration: 4164
            },
            bearLeft_1600_mi: {
                start: 63.928,
                duration: 3885
            },
            bearLeft_200_mi: {
                start: 68.313,
                duration: 4160
            },
            bearLeft_300_mi: {
                start: 72.973,
                duration: 4204
            },
            bearLeft_400_mi: {
                start: 77.677,
                duration: 4235
            },
            bearLeft_50_mi: {
                start: 82.412,
                duration: 4023
            },
            bearLeft_500_mi: {
                start: 86.935,
                duration: 4234
            },
            bearLeft_800_mi: {
                start: 91.669,
                duration: 3521
            },
            bearRight_mi: {
                start: 95.69,
                duration: 2713
            },
            bearRight_100_mi: {
                start: 98.903,
                duration: 4149
            },
            bearRight_1600_mi: {
                start: 103.552,
                duration: 3869
            },
            bearRight_200_mi: {
                start: 107.921,
                duration: 4145
            },
            bearRight_300_mi: {
                start: 112.566,
                duration: 4188
            },
            bearRight_400_mi: {
                start: 117.254,
                duration: 4219
            },
            bearRight_50_mi: {
                start: 121.973,
                duration: 4008
            },
            bearRight_500_mi: {
                start: 126.481,
                duration: 4218
            },
            bearRight_800_mi: {
                start: 131.199,
                duration: 3505
            },
            depart_E_mi: {
                start: 135.204,
                duration: 4176
            },
            depart_N_mi: {
                start: 139.88,
                duration: 4293
            },
            depart_NE_mi: {
                start: 144.673,
                duration: 4502
            },
            depart_NW_mi: {
                start: 149.675,
                duration: 4588
            },
            depart_S_mi: {
                start: 154.763,
                duration: 4340
            },
            depart_SE_mi: {
                start: 159.603,
                duration: 4540
            },
            depart_SW_mi: {
                start: 164.643,
                duration: 4622
            },
            depart_W_mi: {
                start: 169.765,
                duration: 4301
            },
            forward_mi: {
                start: 174.566,
                duration: 3639
            },
            forward_100_mi: {
                start: 178.705,
                duration: 5075
            },
            forward_1600_mi: {
                start: 184.28,
                duration: 4796
            },
            forward_200_mi: {
                start: 189.576,
                duration: 5071
            },
            forward_300_mi: {
                start: 195.147,
                duration: 5114
            },
            forward_400_mi: {
                start: 200.761,
                duration: 5146
            },
            forward_50_mi: {
                start: 206.407,
                duration: 4934
            },
            forward_500_mi: {
                start: 211.841,
                duration: 5144
            },
            forward_800_mi: {
                start: 217.485,
                duration: 4432
            },
            hardLeft_mi: {
                start: 222.417,
                duration: 3312
            },
            hardLeft_100_mi: {
                start: 226.229,
                duration: 4748
            },
            hardLeft_1600_mi: {
                start: 231.477,
                duration: 4469
            },
            hardLeft_200_mi: {
                start: 236.446,
                duration: 4744
            },
            hardLeft_300_mi: {
                start: 241.69,
                duration: 4787
            },
            hardLeft_400_mi: {
                start: 246.977,
                duration: 4819
            },
            hardLeft_50_mi: {
                start: 252.296,
                duration: 4607
            },
            hardLeft_500_mi: {
                start: 257.403,
                duration: 4817
            },
            hardLeft_800_mi: {
                start: 262.72,
                duration: 4105
            },
            hardRight_mi: {
                start: 267.325,
                duration: 3279
            },
            hardRight_100_mi: {
                start: 271.104,
                duration: 4714
            },
            hardRight_1600_mi: {
                start: 276.318,
                duration: 4435
            },
            hardRight_200_mi: {
                start: 281.253,
                duration: 4710
            },
            hardRight_300_mi: {
                start: 286.463,
                duration: 4754
            },
            hardRight_400_mi: {
                start: 291.717,
                duration: 4785
            },
            hardRight_50_mi: {
                start: 297.002,
                duration: 4573
            },
            hardRight_500_mi: {
                start: 302.075,
                duration: 4784
            },
            hardRight_800_mi: {
                start: 307.359,
                duration: 4071
            },
            left_mi: {
                start: 311.93,
                duration: 2738
            },
            left_100_mi: {
                start: 315.168,
                duration: 4173
            },
            left_1600_mi: {
                start: 319.841,
                duration: 3894
            },
            left_200_mi: {
                start: 324.235,
                duration: 4170
            },
            left_300_mi: {
                start: 328.905,
                duration: 4213
            },
            left_400_mi: {
                start: 333.618,
                duration: 4244
            },
            left_50_mi: {
                start: 338.362,
                duration: 4032
            },
            left_500_mi: {
                start: 342.894,
                duration: 4243
            },
            left_800_mi: {
                start: 347.637,
                duration: 3530
            },
            lightLeft_mi: {
                start: 351.667,
                duration: 3152
            },
            lightLeft_100_mi: {
                start: 355.319,
                duration: 4588
            },
            lightLeft_1600_mi: {
                start: 360.407,
                duration: 4309
            },
            lightLeft_200_mi: {
                start: 365.216,
                duration: 4584
            },
            lightLeft_300_mi: {
                start: 370.3,
                duration: 4627
            },
            lightLeft_400_mi: {
                start: 375.427,
                duration: 4659
            },
            lightLeft_50_mi: {
                start: 380.586,
                duration: 4447
            },
            lightLeft_500_mi: {
                start: 385.533,
                duration: 4657
            },
            lightLeft_800_mi: {
                start: 390.69,
                duration: 3945
            },
            lightRight_mi: {
                start: 395.135,
                duration: 3093
            },
            lightRight_100_mi: {
                start: 398.728,
                duration: 4529
            },
            lightRight_1600_mi: {
                start: 403.757,
                duration: 4249
            },
            lightRight_200_mi: {
                start: 408.506,
                duration: 4525
            },
            lightRight_300_mi: {
                start: 413.531,
                duration: 4568
            },
            lightRight_400_mi: {
                start: 418.599,
                duration: 4600
            },
            lightRight_50_mi: {
                start: 423.699,
                duration: 4388
            },
            lightRight_500_mi: {
                start: 428.587,
                duration: 4598
            },
            lightRight_800_mi: {
                start: 433.685,
                duration: 3886
            },
            right_mi: {
                start: 438.071,
                duration: 2785
            },
            right_100_mi: {
                start: 441.356,
                duration: 4221
            },
            right_1600_mi: {
                start: 446.077,
                duration: 3941
            },
            right_200_mi: {
                start: 450.518,
                duration: 4217
            },
            right_300_mi: {
                start: 455.235,
                duration: 4260
            },
            right_400_mi: {
                start: 459.995,
                duration: 4291
            },
            right_50_mi: {
                start: 464.786,
                duration: 4079
            },
            right_500_mi: {
                start: 469.365,
                duration: 4290
            },
            right_800_mi: {
                start: 474.155,
                duration: 3577
            },
            uTurnLeft_mi: {
                start: 478.232,
                duration: 3346
            },
            uTurnLeft_100_mi: {
                start: 482.078,
                duration: 4782
            },
            uTurnLeft_1600_mi: {
                start: 487.36,
                duration: 4503
            },
            uTurnLeft_200_mi: {
                start: 492.363,
                duration: 4778
            },
            uTurnLeft_300_mi: {
                start: 497.641,
                duration: 4821
            },
            uTurnLeft_400_mi: {
                start: 502.962,
                duration: 4853
            },
            uTurnLeft_50_mi: {
                start: 508.315,
                duration: 4641
            },
            uTurnLeft_500_mi: {
                start: 513.456,
                duration: 4851
            },
            uTurnLeft_800_mi: {
                start: 518.807,
                duration: 4139
            },
            uTurnRight_mi: {
                start: 523.446,
                duration: 3324
            },
            uTurnRight_100_mi: {
                start: 527.27,
                duration: 4759
            },
            uTurnRight_1600_mi: {
                start: 532.529,
                duration: 4480
            },
            uTurnRight_200_mi: {
                start: 537.509,
                duration: 4756
            },
            uTurnRight_300_mi: {
                start: 542.765,
                duration: 4799
            },
            uTurnRight_400_mi: {
                start: 548.064,
                duration: 4830
            },
            uTurnRight_50_mi: {
                start: 553.394,
                duration: 4618
            },
            uTurnRight_500_mi: {
                start: 558.512,
                duration: 4829
            },
            uTurnRight_800_mi: {
                start: 563.841,
                duration: 4116
            }
        },
        t = [2E3, 1E3, 750, 500, 400, 300, 200, 100, 50, 0],
        q = [1600, 800, 500, 400, 300, 200, 100, 50, 0],
        s = function(a) {
            var b = j.query(".mh5_audio")[0],
                f = y[a],
                g;
            if (g = b) if (g = f)(e || i) != a ? (!h && (e = a), g = h) : g = !1;
            if (g) {
                i = a;
                h = !1;
                try {
                    d ? b.addEventListener("play", function() {
                        c = setTimeout(x, f.duration + 500)
                    }, !1) : c = setTimeout(x, f.duration), b.currentTime = f.start, b.play()
                } catch (k) {
                    clearTimeout(c)
                }
            }
        },
        x = function() {
            var a = j.query(".mh5_audio")[0];
            clearTimeout(c);
            a.pause();
            c = 0;
            h = !0;
            e && (a = e, e = "", s(a))
        },
        r = function(a, b) {
            var d = m.bearing(a, b),
                c = Math.PI / 8;
            if (d > c && d <= 3 * c) return "NE";
            if (d > 3 * c && d <= 5 * c) return "E";
            if (d > 5 * c && d <= 7 * c) return "SE";
            if (d > 7 * c && d <= 9 * c) return "S";
            if (d > 9 * c && d <= 11 * c) return "SW";
            if (d > 11 * c && d <= 13 * c) return "W";
            if (d > 13 * c && d <= 15 * c) return "NW";
            if (d > 15 * c || d <= c) return "N"
        },
        J = function(b) {
            switch (b) {
            case "NE":
                return a("North") + a("East");
            case "E":
                return a("East");
            case "SE":
                return a("South") + a("East");
            case "S":
                return a("South");
            case "SW":
                return a("South") + a("West");
            case "W":
                return a("West");
            case "NW":
                return a("North") + a("West");
            case "N":
                return a("North")
            }
        },
        F = function(a) {
            var b = Math.round;
            return "mi" == n ? 800 > a ? 10 * b(a / 10) + "yd" : (1609 > a ? (a / 1609).toFixed(1) : b(a / 1609)) + "mi" : 500 >= a ? 10 * b(a / 10) + "m" : 1E3 >= a ? 50 * b(a / 50) + "m" : (a / 1E3).toFixed(1) + "km"
        };
    return {
        statics: {
            ROUTE_START: 0,
            ROUTE_ON: 1,
            ROUTE_OFF: 2,
            ROUTE_END: 3,
            ROUTE_FAST: 4
        },
        children: ["header", "map", "maneuvers", "notification"],
        cssClass: "mh5_Nav",
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        header: {
            children: ["edit", "instruction", "endNavigation", "toggle"],
            control: nokia.mh5.ui.Container,
            rootHtmlElementName: "header",
            layout: {
                type: nokia.mh5.ui.ColumnLayout
            },
            edit: {
                control: nokia.mh5.ui.Button,
                cssClass: "mh5_Button mh5_edit",
                onClick: function() {
                    nokia.mh5.maps.analytics.log({
                        gn: "navigation",
                        c32: "cancel navigation",
                        v32: "~32"
                    });
                    nokia.mh5.history.back()
                }
            },
            instruction: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_nav_instruction",
                visible: !1,
                valueDidChange: function(b) {
                    if (b) {
                        var d = "",
                            c = b.first && " mh5_maneuver_start" || b.last && " mh5_maneuver_end" || "",
                            f = this.parent.parent,
                            e = nokia.mh5.components.Navigation;
                        switch (f._state) {
                        case e.ROUTE_START:
                            d += l(l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "hint",
                                content: a("maps.Nav.headDirectionforDistance", {
                                    direction: "<span>%direction%</span>",
                                    distance: "<span>%distance%</span>"
                                })
                            }), {
                                direction: J(f._initialDirection),
                                distance: 5 < b.distance ? F(b.distance) : "5" + ("mi" === n ? "yd" : "m")
                            });
                            break;
                        case e.ROUTE_END:
                            d += l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "hint",
                                content: l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                    cssClass: "hint_content",
                                    content: f.to.name.split(",")[0]
                                })
                            });
                            d += l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "maneuver",
                                content: l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                    cssClass: "maneuver_content",
                                    content: a("maps.Nav.reachedDestination")
                                })
                            });
                            break;
                        case e.ROUTE_FAST:
                            d += l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "maneuver",
                                content: l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                    cssClass: "maneuver_content",
                                    content: a("maps.Nav.speeding")
                                })
                            });
                            break;
                        default:
                            d += l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "icon " + c
                            }), d += l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "distance",
                                content: b.distance && 5 < b.distance ? F(b.distance) : "now"
                            })
                        }
                        "arrive" !== b.action && (d += l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                            cssClass: "maneuver",
                            content: l("<div class='mh5_nav_%cssClass%'>%content%</div>", {
                                cssClass: "maneuver_content",
                                content: b.instruction
                            })
                        }));
                        this.root.innerHTML = d;
                        if (!b.first && !b.last) this.root.firstChild.style.backgroundPositionX = -3.6 * b.iconIndex + "rem"
                    }
                }
            },
            toggle: {
                control: nokia.mh5.ui.Button,
                cssClass: "mh5_Button mh5_maneuvers",
                visible: !1,
                onClick: function() {
                    var a = this.parent.parent,
                        b = a.maneuvers,
                        d = {
                            type: "fade",
                            mode: b.visible ? "out" : "in",
                            node: b.root,
                            persistence: !0,
                            callback: b.visible &&
                            function() {
                                b.visible = !1;
                                j.removeClass(this.root, "mh5_ListMode");
                                f.fire(nokia.mh5.win, "hideAddressBar")
                            }.bind(this)
                        };
                    j.doTransition(d);
                    b.visible ? j.removeClass(a.header.root, "mh5_ListMode") : j.addClass(a.header.root, "mh5_ListMode");
                    if (!b.visible) b.visible = !0, j.addClass(this.root, "mh5_ListMode")
                }
            }
        },
        map: {
            control: nokia.mh5.components.Map,
            addressLookup: !1,
            settingsButton: !1,
            suggestions: !1,
            infoBubble: {
                content: ["title"],
                listeners: {
                    click: function() {
                        nokia.mh5.app.controller.details(this.data)
                    }
                }
            }
        },
        maneuvers: {
            control: nokia.mh5.ui.List,
            cssClass: "mh5_List mh5_Maneuvers",
            itemClass: nokia.mh5.components.RouteListItem,
            visible: !1
        },
        notification: {
            control: w,
            visible: !1
        },
        build: function() {
            var b = this,
                d = {
                    appId: b.appId,
                    appCode: b.appCode,
                    mode: "walk"
                },
                c = b._routeCallback = b._routeCallback.bind(b),
                e = b._routeErrback = b._routeErrback.bind(b);
            b._onPositionChange = b._onPositionChange.bind(b);
            Object.defineProperty(b, "to", {
                enumerable: !0,
                get: function() {
                    return b._to
                },
                set: function(f) {
                    b._to = f;
                    k.available && (v.fetch(k.coords, f, d, c, e), b.showNotification(a("Notification.routeCalculation")))
                }
            });
            f.add(k, ["positionerror", "positionlost", "positiondeactivate"], function() {
                b.showNotification(a("Notification.lookingForCurrentPosition"))
            });
            f.add(b.map, "ready", function() {
                this.geometry = {
                    y: parseFloat(nokia.mh5.win.getComputedStyle(b.header.root, null).getPropertyValue("height")),
                    x: 0
                };
                this.tracking = !0
            });
            g.build.call(this)
        },
        update: function(a, b) {
            b ? (this._to = a, this._routeCallback(b)) : this.to = a
        },
        visible: !1,
        route: null,
        _routeCallback: function(a) {
            var b = a.maneuvers,
                d = b[0],
                c = this.header.instruction,
                e = a.shape,
                h = this.map,
                g = this.to,
                i = nokia.mh5.assetsPath + "img";
            this.route = a;
            n = nokia.mh5.components.settings.get("unitSystem");
            this._state = nokia.mh5.components.Navigation.ROUTE_START;
            c.visible = !0;
            this._initialDirection = r(d, b[1]);
            c.value = d;
            this.maneuvers.items = b;
            this.header.toggle.visible = !0;
            this.resetNotification();
            h.removePoi();
            h.box = h._map.route = e;
            h.createPoi(i + "/from.png", {
                latitude: e[0],
                longitude: e[1]
            });
            h.createPoi(i + "/to.png", {
                latitude: g.latitude,
                longitude: g.longitude,
                name: g.name
            });
            this._speedCount = this._offRouteCount = this._positionLostCount = 0;
            this._lastSegment = this._lastPoint = null;
            this._lastPosition = {
                coords: {}
            };
            h.zoom = 17;
            h.center = h.position.available ? h.position : d;
            h.tracking = !0;
            s("depart_" + this._initialDirection + "_" + n);
            f.add(k, "positionchange", this._onPositionChange)
        },
        _routeErrback: function(a) {
            this.showNotification(a)
        },
        showNotification: function(a, b) {
            var d = this.notification;
            d.text = a;
            d.timeout = b || w.TIMEOUT_INFINITY;
            d.visible = !0
        },
        resetNotification: function() {
            var a = this.notification;
            a.timeout = w.TIMEOUT_DEFAULT;
            a.visible = !1
        },
        visibleDidChange: function(a) {
            var b = this.map,
                d = nokia.mh5.win;
            g.visibleDidChange.call(this, a);
            if (b.visible = a) this._maximumAge = k.maximumAge, k.maximumAge = 3, n = nokia.mh5.components.settings.get("unitSystem"), f.add(d, "pagehide", x), f.add(d, "blur", x);
            else if (i = e = "", c && x(), f.remove(k, "positionchange", this._onPositionChange), f.remove(d, "pagehide", x), f.remove(d, "blur", x), "_maximumAge" in this) k.maximumAge = this._maximumAge, delete this._maximumAge
        },
        _onPositionChange: function(d) {
            var c = nokia.mh5.components.Navigation,
                e = this.header.instruction,
                h = d.data,
                g = this._lastPosition,
                j = h.coords,
                l = this.route.maneuvers;
            if (70 < j.accuracy) 5 < ++this._positionLostCount && this.showNotification(a("Notification.noGPSSignal"));
            else if (this._positionLostCount = 0, b = 35 < j.accuracy ? j.accuracy : 35, d = this._getState(h), g.coords.latitude = j.latitude, g.coords.longitude = j.longitude, g.timestamp = h.timestamp, d.state == c.ROUTE_END) c = l[l.length - 1], e.value = c, h = "arrive_" + (c.direction ? "_" + c.direction + "_" : "") + n, f.remove(k, "positionchange", this._onPositionChange), i != h && s(h), nokia.mh5.maps.analytics.log({
                gn: "navigation",
                c32: "end navigation",
                v32: "~c32"
            });
            else if ("segment" in d) if (this.resetNotification(), d.state === c.ROUTE_FAST) e.value = {
                distance: 0,
                first: !1,
                last: !1
            };
            else {
                if (d.state === c.ROUTE_ON) c = l[d.segment + 1] || l[d.segment], h = d.distanceToEnd, e.value = {
                    distance: 1 < h && h,
                    iconIndex: c.iconIndex,
                    last: c.last,
                    instruction: c.instruction
                }, d.action && s(d.action)
            } else d.state === c.ROUTE_START ? (c = l[0], e.value = c) : d.state === c.ROUTE_OFF && (h = m.pointDistance(j, l[this._lastSegment].shape[this._lastPoint]), this.showNotification(a("Notification.offRoute", {
                value: F(h > b ? h : b)
            })))
        },
        _getState: function(a) {
            var d = this.route.maneuvers,
                c = nokia.mh5.components.Navigation,
                f;
            var e = a.coords,
                h, g;
            f = Number.MAX_VALUE;
            var k, i = -1;
            for (h = this._lastSegment || 0; h < d.length; h++) {
                g = e;
                var j = d[h].shape,
                    l = Number.MAX_VALUE,
                    w = -1,
                    y = void 0,
                    v = void 0,
                    s = void 0;
                for (y = 0, v = j.length - 1; y < v; y++) s = m.segmentDistance(g, j[y], j[y + 1]), 0 <= s && s <= l && (l = s, w = y + 1);
                g = {
                    distance: l,
                    point: w
                };
                if (g.distance < f && g.distance < b) f = g.distance, i = h, k = g.point
            }~i ? (h = d[i].shape.slice(k), h = h.reduce(o, m.pointDistance(e, h[0])), g = d[i + 1] || d[i], e = ("mi" == n ? q : t).filter(u, {
                distance: h,
                margin: 50 > h ? 25 : 15
            })[0], f = {
                action: g && g.action && 0 <= e && g.action + (g.direction && !e ? "_" + g.direction : e ? "_" + e : "") + "_" + n,
                segment: i,
                distance: f,
                distanceToEnd: h,
                point: k
            }) : f = void 0;
            k = this._lastPosition;
            i = m.speed;
            switch (this._state) {
            case c.ROUTE_START:
                if (f && 10 > f.distance) this._state = c.ROUTE_ON;
                break;
            case c.ROUTE_ON:
                if (f) {
                    this._offRouteCount = 0;
                    this._speedCount = k.timestamp && 8.3 < i(k, a) ? this._speedCount + 1 : 0;
                    if (30 < this._speedCount) this._state = c.ROUTE_FAST;
                    if (f.segment === d.length - 2 && 20 > f.distanceToEnd) this._state = c.ROUTE_END
                } else 5 <= this._offRouteCount ? this._state = c.ROUTE_OFF : this._offRouteCount++;
                break;
            case c.ROUTE_OFF:
                if (f) this._state = c.ROUTE_ON, this._offRouteCount = 0;
                break;
            case c.ROUTE_FAST:
                if (8.3 > i(k, a) && 0 === --this._speedCount) this._state = c.ROUTE_ON
            }
            return f ? (f.state = this._state, this._lastSegment = f.segment, this._lastPoint = f.point, f) : {
                state: this._state
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.ImageDialog");
nokia.mh5.ui.ImageDialog = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a = nokia.mh5.i18n;
    return {
        cssClass: "mh5_ImageDialog mh5_modal mh5_modalBg",
        children: ["content", "spinner", "errorMessage", "imageProviderText"],
        secondLevel: !0,
        content: {
            control: nokia.mh5.ui.Control,
            rootHtmlElementName: "img",
            cssClass: "mh5_CarouselImage",
            visible: !1
        },
        spinner: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_spinner_big_bright",
            visible: !0
        },
        errorMessage: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_errorMessage",
            innerHTML: "<span>" + a("Notification.unableToLoadImage") + "</span>",
            visible: !1
        },
        imageProviderText: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_imageProvider",
            visible: !1
        },
        constructor: function(b, c) {
            b.closeOnTap = !0;
            g.constructor.call(this, b, c);
            var e = this,
                i = this.content.root,
                h = nokia.mh5.win.setTimeout(function() {
                    nokia.mh5.dom.addClass(e.root, "mh5_loading")
                }, 50),
                d = new Image;
            d.onload = function() {
                nokia.mh5.win.clearTimeout(h);
                nokia.mh5.dom.removeClass(e.root, "mh5_loading");
                e.content.visible = !0;
                i.src = d.src;
                var b = d.width < e.root.offsetWidth ? d.width : e.root.offsetWidth,
                    c = d.height < e.root.offsetHeight ? d.height : e.root.offsetHeight,
                    g = i.style;
                b < c ? g.width = b + "px" : g.height = c + "px";
                e._updateImagePosition();
                if (e.provider) e.imageProviderText.root.innerHTML = a("source") + ": " + e.provider, e.imageProviderText.visible = !0, e._updateTextPosition()
            };
            d.onerror = function() {
                nokia.mh5.win.clearTimeout(h);
                nokia.mh5.dom.removeClass(e.root, "mh5_loading");
                e.errorMessage.visible = !0
            };
            d.src = b.src
        },
        _updatePosition: function() {
            g._updatePosition.call(this);
            this._updateImagePosition();
            this._updateTextPosition()
        },
        _updateImagePosition: function() {
            var a = this.content.root,
                c = a.style;
            c.top = "50%";
            c.marginTop = "-" + a.offsetHeight / 2 + "px";
            c.left = "50%";
            c.marginLeft = "-" + a.offsetWidth / 2 + "px"
        },
        _updateTextPosition: function() {
            var a = this.content.root;
            this.imageProviderText.root.style.top = a.offsetTop + a.offsetHeight + 5 + "px";
            this.imageProviderText.root.style.left = a.offsetLeft + "px"
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Carousel");
nokia.mh5.ui.Carousel = new nokia.mh5.Class(nokia.mh5.ui.Container, function() {
    return {
        cssClass: "mh5_Carousel",
        hScroll: !0,
        hScrollbar: !1,
        visible: !0,
        imagePool: [],
        onClick: function(g) {
            g = (g.hasOwnProperty("data") ? g.data.target : null) || g.target;
            "IMG" === g.tagName && new nokia.mh5.ui.ImageDialog({
                src: g.getAttribute("data-image-src"),
                provider: g.getAttribute("data-image-provider") || "Business Owner"
            })
        },
        imagePoolDidChange: function(g) {
            if (!g || 0 === g.length) this.getContentRoot().innerHTML = "", this.visible = !1;
            else {
                var a = "",
                    b = 0;
                g.forEach(function(b) {
                    a += '<img src="' + b.thumbnailSrc + '" data-image-src="' + b.imageSrc + '" data-image-provider="' + (b.providerName ? b.providerName : "") + '" draggable = "false" />'
                });
                g = this.getContentRoot();
                g.innerHTML = a;
                for (var c = g.children, e = this, g = c.length - 1; 0 <= g; --g) {
                    var i = c[g];
                    i.onerror = function() {
                        this.parentNode && this.parentNode.removeChild(this)
                    };
                    i.onload = function() {
                        b = b++;
                        ++b === c.length - 1 && e._scroll && e._scroll.refresh()
                    }
                }
                this.visible = !! a
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Alert");
nokia.mh5.ui.Alert = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a, b = nokia.mh5.win,
        c = nokia.mh5.doc,
        e = nokia.mh5.i18n,
        i = function() {
            this.update()
        },
        h = function(a) {
            a.preventDefault()
        };
    return {
        cssClass: "mh5_Alert mh5_modal mh5_modalBg",
        disableUpdatePosition: !0,
        title: e("alert"),
        message: "",
        okay: e("ok"),
        onOkay: null,
        content: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_AlertWrapper",
            children: ["title", "message", "buttonContainer"],
            title: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_AlertTitle"
            },
            message: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_AlertMessage"
            },
            buttonContainer: {
                control: nokia.mh5.ui.Container,
                cssClass: "mh5_AlertButtons",
                children: ["okay"],
                okay: {
                    control: nokia.mh5.ui.Button,
                    onClick: function() {
                        var b = this.getRootOwnerByClass(a);
                        if (b.onOkay) b.onOkay(b);
                        g._closeDialog.call(b)
                    }
                }
            }
        },
        okayDidChange: i,
        messageDidChange: i,
        titleDidChange: i,
        update: function() {
            this.content.title.root.innerHTML = this.title;
            this.content.message.root.innerHTML = this.message;
            this.content.buttonContainer.okay.text = this.okay
        },
        constructor: a = function(a, b) {
            g.constructor.call(this, a, b)
        },
        visibleDidChange: function(a) {
            if (a) this.root.style.top = (void 0 !== b.pageYOffset ? b.pageYOffset : (c.documentElement || c.body.parentNode || c.body).scrollTop) + "px";
            this._scrollEnabler(a);
            g.visibleDidChange.apply(this, arguments)
        },
        _scrollEnabler: function(a) {
            nokia.mh5.dom[a ? "addClass" : "removeClass"](c.body, "mh5_overflow_hidden");
            nokia.mh5.event[a ? "add" : "remove"](c.body, "down", h)
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.PlaceListItem");
nokia.mh5.components.PlaceListItem = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        rootHtmlElementName: "li",
        cssClass: "mh5_ListItem",
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            this.update()
        },
        update: function() {
            this.root.innerHTML = this._generateInnerHTML()
        },
        _generateInnerHTML: function() {
            var a, b = !(!this.address && !this.ratingValue);
            a = '<div><div class="mh5_ImgWrapper">' + ('<img src="' + nokia.mh5.utils.place.getCategoryIcon(this) + '"></img>');
            a += "</div>";
            b && (a += '<div class="mh5_RowLayout">');
            this.distance && (a += '<div class="mh5_ColumnLayout"><div class="mh5_RowLayout">');
            a += '<div class="mh5_ListItem_name">' + this.name + "</div>";
            this.placeId && this.address && (a += '<div class="mh5_ListItem_address">' + this.address.replace(/\n/g, ", ") + "</div>");
            if (this.distance) {
                var c = nokia.mh5.utils.formatDistance(this.distance, nokia.mh5.components.settings.current.unitSystem);
                a += '</div><div class="mh5_ListItem_distance">' + c + "</div></div>"
            }
            if (!this._rating) this._rating = new nokia.mh5.ui.Rating;
            if (this.ratingValue) this._rating.value = this.ratingValue;
            a += this._rating.root.outerHTML;
            b && (a += "</div>");
            return a + "</div>"
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.PlaceDetails");
nokia.mh5.components.PlaceDetails = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = nokia.mh5.i18n,
        b = [{
            name: a("eating"),
            value: "eating",
            cssClass: "eating"
        }, {
            name: a("shopping"),
            value: "shopping",
            cssClass: "shopping"
        }, {
            name: a("going-out"),
            value: "going-out",
            cssClass: "goingOut"
        }, {
            name: a("sights"),
            value: "sights",
            cssClass: "sights"
        }, {
            name: a("PT"),
            value: "public-transport",
            cssClass: "publicTransport"
        }],
        c = ["summary", "recommendations", "legalNote"],
        e = nokia.mh5.platform,
        i = nokia.mh5.dom;
    return {
        control: nokia.mh5.ui.Container,
        children: "summary,actions,images,ownerContent,guides,reviews,spinner,recommendations,fillup,legalNote".split(","),
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        summary: {
            control: nokia.mh5.components.PlaceSummary
        },
        actions: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_placeActions actions stretch mh5_standardBackgroundColorDark",
            layout: {
                type: nokia.mh5.ui.ColumnLayout
            },
            children: ["dial", "share", "route", "website", "collect"],
            dial: {
                control: nokia.mh5.ui.Button,
                cssClass: "button contact mh5_primaryColorDark",
                disabled: !0,
                text: a("call"),
                onClick: function() {
                    var a = this.parent.parent;
                    nokia.mh5.event.fire(a, "dial", a.place)
                }
            },
            share: {
                control: nokia.mh5.ui.Button,
                cssClass: "button share mh5_primaryColorDark",
                disabled: !0,
                onClick: function() {
                    var a = this.parent.parent;
                    nokia.mh5.event.fire(a, "share", a.place)
                },
                text: a("share")
            },
            route: {
                control: nokia.mh5.ui.Button,
                cssClass: "button route mh5_primaryColorDark",
                disabled: !0,
                onClick: function() {
                    var a = this.parent.parent;
                    nokia.mh5.event.fire(a, "route", a.place)
                },
                text: a("route")
            },
            website: {
                control: nokia.mh5.ui.Button,
                cssClass: "button web mh5_primaryColorDark",
                disabled: !0,
                text: a("web"),
                target: "_blank",
                onClick: function() {
                    var a = this.parent.parent;
                    nokia.mh5.event.fire(a, "website", a.place)
                }
            },
            collect: {
                control: nokia.mh5.ui.Button,
                cssClass: "button favourite mh5_primaryColorDark",
                disabled: !0,
                onClick: function() {
                    var a = this.parent.parent;
                    nokia.mh5.event.fire(a, "collect", a.place)
                }
            }
        },
        images: {
            control: nokia.mh5.ui.Carousel,
            clear: function() {
                this.imagePool = []
            }
        },
        ownerContent: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_PlaceDetailsData mh5_primaryColorBright",
            visible: !1,
            clear: function() {
                this.root.innerHTML = ""
            }
        },
        guides: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_PlaceDetailsData mh5_primaryColorBright",
            visible: !1,
            update: function(b) {
                this.clear();
                if (b) {
                    for (var d = "", c, f = 0, e = b.length; f < e; f++) c = "", b[f].providerUrl && (c = i.createHyperlinkHTML({
                        href: b[f].providerUrl,
                        "class": "mh5_link",
                        target: "_blank"
                    }, " " + a("more"))), d += '<div><div class="mh5_guide">', d += b[f].providerIcon ? '<div class="mh5_ImgWrapper"><img class="mh5_icon" src="' + b[f].providerIcon + '"></div>' : "", d += "<div>", d += '<h2 class="title">' + b[f].providerName + "</h2>", d += this.parent._formatDescription(b[f].description, c), d += "</div>", d += "</div></div>";
                    this.root.innerHTML = '<div class="mh5_guides"><h1 class="mh5_title">' + a("guides") + "</h1>" + d + "</div>";
                    this.visible = !0
                }
            },
            clear: function() {
                this.root.innerHTML = "";
                this.visible = !1
            }
        },
        reviews: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_PlaceDetailsData mh5_primaryColorBright",
            visible: !1,
            update: function(b) {
                this.clear();
                if (b) {
                    for (var d = "", c, f = 0, e = b.length; f < e; f++) {
                        c = "";
                        d += '<div><div class="mh5_review">';
                        d += '<div class="mh5_ImgWrapper"><img class="mh5_icon" src="' + b[f].providerIcon + '.lima-desktop.png"></div>';
                        d += "<div>";
                        d += "<h2>" + (b[f].title || this.parent.place.name) + "</h2>";
                        if (b[f].ratingValue) {
                            var g = new nokia.mh5.ui.Rating;
                            g.value = b[f].ratingValue;
                            d += g.root.outerHTML
                        }
                        b[f].url && (c = i.createHyperlinkHTML({
                            href: b[f].url,
                            "class": "mh5_link",
                            target: "_blank"
                        }, " " + a("more")));
                        d += this.parent._formatDescription(b[f].description, c);
                        d += '<p class="mh5_reviewFooter">' + a("posted", {
                            by_part: b[f].userName ? a("by_part", {
                                name: b[f].userName
                            }) : "",
                            date: b[f].date
                        }) + "</p>";
                        d += "</div>";
                        d += "</div></div>"
                    }
                    this.root.innerHTML = '<div class="mh5_reviews"><h1 class="mh5_title">' + a("reviews") + "</h1>" + d + "</div>";
                    this.visible = !0
                }
            },
            clear: function() {
                this.root.innerHTML = "";
                this.visible = !1
            }
        },
        spinner: {
            control: nokia.mh5.ui.Control,
            visible: !1,
            innerHTML: "<div class='mh5_spinner_big_dark'></div>",
            cssClass: "mh5_spinnerContainer"
        },
        recommendations: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_nearby_places",
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            children: ["title", "categoryToggle", "categoryToggleBorder", "indicator", "list"],
            visible: !1,
            indicator: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_recommendationIndicator mh5_primaryBorderColorBright",
                innerHTML: "<div></div>"
            },
            title: {
                control: nokia.mh5.ui.Control,
                rootHtmlElementName: "h1",
                cssClass: "mh5_title",
                innerHTML: a("nearbyPlaces"),
                visible: !1
            },
            categoryToggle: {
                control: nokia.mh5.ui.SegmentedButton,
                cssClass: "mh5_nearbyCategoryToggle mh5_ColumnLayout mh5_primaryColorBright",
                items: b,
                onValueChange: function(a) {
                    var b = this.parent,
                        c = b.parent,
                        f = this.root.querySelector(".mh5_selected"),
                        f = Math.round(f.offsetLeft + f.offsetWidth / 2);
                    c._selectedNearbyCategory = a;
                    b.list.items = c.place && c.place.recommendations ? nokia.mh5.components.favourites.favouritize(c.place.recommendations[a]) : [];
                    b.indicator.root.style[nokia.mh5.dom.transformProperty] = "translateX(" + f + "px)";
                    nokia.mh5.win.setTimeout(function() {
                        c.resize(!0)
                    }, 1)
                }
            },
            categoryToggleBorder: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_primaryBackgroundColorBright"
            },
            list: {
                control: nokia.mh5.ui.List,
                visible: !1,
                itemClass: nokia.mh5.components.PlaceListItem,
                listeners: {
                    tap: function(a) {
                        var b = a.data.item,
                            c = this.getRootOwnerByClass(nokia.mh5.components.PlaceDetails),
                            f = {
                                placeId: b.placeId,
                                href: b.href,
                                latitude: b.latitude,
                                longitude: b.longitude,
                                address: b.address,
                                category: b.category,
                                icon: b.icon,
                                name: b.name
                            };
                        b.placeId && "pt" === b.placeId.substring(0, 2) && delete f.placeId;
                        a = nokia.mh5.event.fire(c, "nearby", {
                            place: f,
                            index: a.data.index
                        });
                        if (!a.defaultPrevented) c.place = f
                    }
                }
            }
        },
        fillup: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_fillup"
        },
        legalNote: {
            control: nokia.mh5.ui.Container,
            rootHtmlElementName: "footer",
            cssClass: "mh5_RowLayout mh5_secondaryColorBright",
            innerHTML: "&copy; " + (new Date).getFullYear() + " Nokia Here.com",
            children: ["ownerContentProvider", "imageProviders", "reportLink"],
            clear: function() {
                this.ownerContentProvider.clear();
                this.imageProviders.clear()
            },
            ownerContentProvider: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_provider",
                innerHTML: "",
                clear: function() {
                    this.innerHTML = "";
                    this.visible = !1
                }
            },
            imageProviders: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_provider",
                innerHTML: "",
                clear: function() {
                    this.innerHTML = "";
                    this.visible = !1
                }
            },
            reportLink: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_report",
                innerHTML: a("reportPlace"),
                onClick: function() {
                    return new nokia.mh5.ui.Alert({
                        title: a("report.title"),
                        message: a("report.message")
                    })
                }
            }
        },
        adapter: nokia.mh5.adapters.Search,
        cssClass: "mh5_PlaceDetails",
        constructor: function(b, d) {
            var e, f, k, i, n, l, o, u;
            b || (b = {});
            for (k = 0; l = c[k]; k++) if (l in b) throw Error(a("Error.propertyCannotBeOverwritten", {
                name: l
            }));
            if (!b.hasOwnProperty("actions") || !0 === b.actions) b.actions = {};
            if (b.actions && !b.actions.collect) b.actions.collect = null;
            g.constructor.call(this, b, d);
            if (this.customContent) {
                e = [].concat(this.customContent);
                f = this.children;
                for (k = 0; i = e[k]; k++) {
                    n = i.control || nokia.mh5.ui.Control;
                    n = new n(i, this);
                    if (this[i.name]) throw Error(a("Error.customContentNotAllowed", {
                        name: i.name
                    }));
                    l = !this[i.name] && i.name || "customContent" + (k + 1);
                    o = i.after && f.indexOf(i.after);
                    u = o >= f.length - 1;
                    this[i.after && u ? "add" : "insertBefore"](n, l, i.before || f[o + 1])
                }
            }
        },
        build: function() {
            var a = this.parameters;
            Object.defineProperty(this, "parameters", {
                get: function() {
                    return this._parameters
                },
                set: function(a) {
                    this._parameters = {};
                    nokia.mh5.each(a, function(a, b) {
                        this._parameters[b] = "function" === typeof a ? a.bind(this) : a
                    }, this)
                }
            });
            if (a) this.parameters = a;
            e.ios && i.addClass(this.root.firstChild.firstChild, "mh5_noFlicker");
            this.resize = this.resize.bind(this);
            g.build.call(this)
        },
        resize: function(a) {
            var b = this.getContentRoot(),
                c = b.parentNode,
                f = this._selectedNearbyCategory,
                e = this.recommendations.categoryToggle;
            b.offsetHeight > this.root.offsetHeight ? i.addClass(c, "mh5_fillupDisable") : i.removeClass(c, "mh5_fillupDisable");
            this._scroll && nokia.mh5.win.setTimeout(this._scroll.refresh, 1);
            this.images && this.images._scroll && nokia.mh5.win.setTimeout(this.images._scroll.refresh, 1);
            !a && this.visible && f && e.select(f)
        },
        remove: function(b) {
            if (~c.indexOf(b)) throw Error(a("Error.unableToRemove", {
                name: b
            }));
            g.remove.call(this, b)
        },
        _setContentData: function(b) {
            var d = "",
                c = this.legalNote,
                f, e;
            if (b.imageProviders) {
                f = [];
                e = 0;
                for (var g = b.imageProviders.length; e < g; e++) f.push(b.imageProviders[e].url ? i.createHyperlinkHTML({
                    href: b.imageProviders[e].url,
                    target: "_blank"
                }, b.imageProviders[e].name) : b.imageProviders[e].name);
                if (c) c.imageProviders.root.innerHTML = a("imagesProvidedBy") + f.join(", "), c.imageProviders.visible = !0
            }
            b.extended && nokia.mh5.each(b.extended, function(a) {
                d += this._renderSimpleContent(a.label, a.text)
            }, this);
            d += this._renderSimpleContent(a("PT"), b.publicTransport);
            if (this.ownerContent) {
                if (b.ownerContent && (e = b.ownerContent, d += this._renderOwnerContent(e), e.providerName && c)) f = e.providerName, e.providerUrl ? (e = e.providerUrl, c.ownerContentProvider.root.innerHTML = a("contentProvidedBy") + i.createHyperlinkHTML({
                    href: e,
                    target: "_blank"
                }, f)) : c.ownerContentProvider.root.innerHTML = a("contentProvidedBy") + f, c.ownerContentProvider.visible = !0;
                this.ownerContent.visible = !! d;
                this.ownerContent.root.innerHTML = d
            }
            this.guides && this.guides.update(b.premiumContent);
            this.reviews && this.reviews.update(b.reviews)
        },
        _setRecommendations: function(a) {
            var b = !1,
                c = a.recommendations,
                f = this.recommendations,
                e = f.categoryToggle,
                g, i;
            if (c) {
                e.select(null);
                nokia.mh5.each(e.items, function(a) {
                    if (c && c[a.value] && c[a.value].length) {
                        if (b = !0, delete a.disabled, void 0 === g) g = a.value
                    } else if (a.disabled = !0, this._selectedNearbyCategory === a.value) this._selectedNearbyCategory = void 0
                }.bind(this));
                e.update();
                if (void 0 === this._selectedNearbyCategory && g) this._selectedNearbyCategory = g;
                if ("public-transport" === this._selectedNearbyCategory) {
                    e = c[this._selectedNearbyCategory];
                    for (i = 0; i < e.length; i++) if (e[i].name === a.name) {
                        c[this._selectedNearbyCategory].splice(i, 1);
                        break
                    }
                }
                f.visible = b;
                f.title.visible = b;
                f.list.visible = b;
                f.categoryToggle.visible = b;
                this.resize()
            } else f.visible = !1
        },
        showError: function(b) {
            var c = this.fillup,
                e = this.actions,
                f;
            "not found" === b ? (b = a("Error.placeRemovedByOwner.header"), f = a("Error.placeRemovedByOwner.message")) : (b = a("Error.placeError.header"), f = a("Error.placeError.message"));
            e && ["dial", "share", "route", "website", "collect"].forEach(function(a) {
                if (e[a]) e[a].disabled = !0
            });
            if (c) {
                if (c) c.root.innerHTML = '<div class="mh5_error"><h2>' + b + "</h2><p>" + f + "</p></div>"
            } else this._error = {
                header: b,
                message: f
            }
        },
        _formatDescription: function(a, b) {
            return !a ? "" : '<p class="mh5_description">' + a.replace(/\n{2,}/g, '</p><p class="mh5_description">').replace(/\n/g, "<br>") + (b || "") + "</p>"
        },
        _renderSimpleContent: function(a, b) {
            return !a || !b ? "" : '<div class="mh5_placeData"><h2 class="title">' + a + "</h2>" + this._formatDescription(b) + "</div>"
        },
        _renderOwnerContent: function(b) {
            return !b ? "" : '<div class="mh5_ownerContent"><h1 class="mh5_title">' + a("placeDescription") + "</h1>" + this._formatDescription(b) + "</div>"
        },
        vScroll: !0,
        bounce: !1,
        place: null,
        parameters: {},
        placeDidChange: function(a) {
            delete this._error;
            var b = nokia.mh5.adapters.Search,
                c = this.adapter || b;
            this.update();
            a && c.fetch(a, this.parameters, function(a) {
                b.merge(this.place, a);
                this.update();
                nokia.mh5.event.fire(this, "done");
                if (!a.recommendations) this.spinner.visible = !0, b.getRecommendations(a, this.parameters, function(a) {
                    this.spinner.visible = !1;
                    this._setRecommendations(a);
                    this.resize()
                }.bind(this))
            }.bind(this), function() {
                this.showError.apply(this, arguments);
                nokia.mh5.event.fire(this, "done")
            }.bind(this))
        },
        unitSystemBinding: "nokia.mh5.components.settings#current.unitSystem",
        update: function() {
            var a = this.place,
                b, c, f, e, g;
            if (a) {
                this.summary.update(a);
                b = this.actions;
                c = a.phone;
                if (this.images) this.images.imagePool = a.gallery;
                this.legalNote.clear();
                this._setContentData(a);
                this._setRecommendations(a);
                if (this.fillup) this.fillup.root.innerHTML = "";
                if (b) {
                    f = b.dial;
                    e = b.share;
                    g = b.route;
                    b = b.website;
                    if (f) {
                        if (!nokia.mh5.platform.firefox_mobile) f.link = "tel:" + c;
                        f.disabled = !c;
                        f.update()
                    }
                    if (e && a.name && (a.placeId || a.longitude && a.latitude)) e.disabled = !1, e.update();
                    if (g && a.name && (a.placeId || a.longitude && a.latitude)) g.disabled = !1;
                    if (b) b.link = a.website, b.disabled = !a.website, b.update();
                    this.checkCollectState()
                }
                this.resize();
                nokia.mh5.event.fire(this, "update", a)
            }
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.call(this, a);
            nokia.mh5.event.remove(nokia.mh5.components.favourites, "synchronized", this.checkCollectState);
            if (a) {
                if (i.addEvent(nokia.mh5.win, "viewportchange", this.resize, !1), this.resize(), this._error && (nokia.mh5.event.fire(this, "error", this._error), delete this._error), this.actions && this.actions.collect) this.checkCollectState = this.checkCollectState.bind(this), nokia.mh5.event.add(nokia.mh5.components.favourites, "synchronized", this.checkCollectState), this.checkCollectState()
            } else i.removeEvent(nokia.mh5.win, "viewportchange", this.resize, !1)
        },
        unitSystemDidChange: function() {
            this.recommendations && this.recommendations.list.renderedItems && this.recommendations.list.renderedItems.forEach(function(a) {
                a.update && a.update()
            })
        },
        checkCollectState: function() {
            var b = this.actions.collect,
                c = this.place;
            if (b) c.favourite = !! nokia.mh5.components.favourites.get(c), b.disabled = c.name && (c.placeId || c.longitude && c.latitude) ? !1 : !0, b.text = c.favourite ? a("collections.favourite.edit.manage") : a("collections.favourite.edit.collect"), i[c.favourite ? "addClass" : "removeClass"](b.root, "saved")
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.Search");
nokia.mh5.components.Search = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    function a() {
        var a = e.getLocalStorageValue("history");
        return a ? JSON.parse(a) : []
    }
    var b, c, e = nokia.mh5.utils,
        i = function(a) {
            return a.toLowerCase().charAt(0) === c.toLowerCase()
        },
        h = function(a) {
            return 0 <= a.toLowerCase().indexOf(c)
        };
    return {
        statics: {
            SEARCH_COMPLETION: {
                add: function(b) {
                    if (b) {
                        var c = a(),
                            f = c.indexOf(b),
                            f = ~f && c.splice(f, 1)[0];
                        100 < c.unshift(f || b) && c.pop();
                        e.setLocalStorageValue("history", JSON.stringify(c))
                    }
                },
                get: function(d, e, f) {
                    var g = this.searchAdapter,
                        m = this.parameters,
                        n = m && m.limit,
                        l, o, d = d.trim();
                    b && clearTimeout(b);
                    2 < d.length && g && g.getSuggestions ? b = setTimeout(function() {
                        b = null;
                        m.limit = f;
                        g.getSuggestions(d, m, e);
                        m.limit = n
                    }, 200) : (l = a(), c = d.toLowerCase(), n = d && 1 == d.length && l.filter(i), o = !(n && n.length) && h, e((o ? l.filter(o) : n || l).splice(0, f || 4)))
                }
            }
        },
        children: ["input", "completion"],
        input: {
            control: nokia.mh5.ui.TextInput,
            type: "search"
        },
        cssClass: "mh5_Search",
        completion: {
            control: nokia.mh5.ui.List,
            cssClass: "mh5_SearchCompletion",
            visible: !1,
            itemClass: new nokia.mh5.Class(nokia.mh5.ui.Control, function(a) {
                return {
                    rootHtmlElementName: "li",
                    constructor: function(b, c) {
                        a.constructor.call(this, b, c);
                        var e = RegExp(this.parent.parent.query.replace(/[#-.]|[\[-\^]|[?|{}\/]/g, "\\$&"), "i");
                        this.root.innerHTML = nokia.mh5.utils.escapeHTML(this.text).replace(e, '<span class="mh5_secondaryColorBright">$&</span>')
                    }
                }
            }),
            listeners: {
                tap: function(a) {
                    var b = this.parent;
                    b.query = a.data.item.text;
                    b.input.blur();
                    b.search()
                }
            }
        },
        searchAdapter: nokia.mh5.adapters.Search,
        completionAdapter: nokia.mh5.components.Search.SEARCH_COMPLETION,
        parameters: {},
        constructor: function(a, b) {
            this.searchAdapter = a.searchAdapter ? a.searchAdapter : this.searchAdapter;
            this.completionAdapter = a.completionAdapter ? a.completionAdapter : nokia.mh5.components.Search.SEARCH_COMPLETION;
            g.constructor.call(this, a, b)
        },
        build: function() {
            var a = nokia.mh5.event.add,
                b = this.input,
                c = this.query,
                e = this.parameters;
            Object.defineProperty(this, "parameters", {
                get: function() {
                    return this._parameters
                },
                set: function(a) {
                    this._parameters = {};
                    nokia.mh5.each(a, function(a, b) {
                        this._parameters[b] = "function" === typeof a ? a.bind(this) : a
                    }, this)
                }
            });
            if (e) this.parameters = e;
            Object.defineProperty(this, "query", {
                get: function() {
                    return b.value
                },
                set: function(a) {
                    b.value = a
                }
            });
            if (c) this.query = c;
            this.completionAdapter && nokia.mh5.ui.Control.watch(b, "value", this, this._updateCompletion);
            a(b, "submit", this.search.bind(this));
            a(b, "focus", this._onFocus.bind(this));
            a(b, "blur", this._onBlur.bind(this));
            g.build.call(this)
        },
        search: function() {
            var a = nokia.mh5.event.fire,
                b = this.query;
            this.completion.visible = !1;
            b ? (this.completionAdapter && this.completionAdapter.add(b), a(this, "beforesearch", {
                query: b
            }).defaultPrevented || this.searchAdapter.search(b, this.parameters, function(b) {
                a(this, "success", b)
            }.bind(this), function(b) {
                a(this, "error", b)
            }.bind(this))) : a(this, "clear")
        },
        _onFocus: function() {
            if (this.completionAdapter) this._updateCompletion(), this.completion.visible = !0
        },
        _onBlur: function() {
            var a = this.completion;
            a.visible && setTimeout(function() {
                a.visible = !1
            }, nokia.mh5.platform.blackberry ? 1E3 : 250)
        },
        _updateCompletion: function() {
            var a = this.completion;
            this.completionAdapter.get.call(this, this.input.value, function(b) {
                a.items = b.map(function(a) {
                    return {
                        text: a
                    }
                })
            }, 4)
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.Route");
nokia.mh5.components.Route = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = nokia.mh5.geolocation,
        b = nokia.mh5.i18n,
        c = nokia.mh5.dom.addClass,
        e = nokia.mh5.dom.removeClass,
        i = b("currentLocation"),
        h = nokia.mh5.ui.Control.prototype.getRootOwnerByClass,
        d = new nokia.mh5.Class(nokia.mh5.ui.Control, function() {
            return {
                rootHtmlElementName: "li",
                innerHTML: "<div class='mh5_ListItem_name'>" + i + "</div><div></div>",
                update: function(a) {
                    var b = this.root.lastChild;
                    switch (a) {
                    case "active":
                        e(b, "mh5_spinner", "mh5_hidden");
                        c(b, "mh5_position_available");
                        break;
                    case "waiting":
                        e(b, "mh5_position_available", "mh5_hidden");
                        c(b, "mh5_spinner");
                        break;
                    default:
                        e(b, "mh5_spinner", "mh5_position_available"), c(b, "mh5_hidden")
                    }
                }
            }
        }),
        j;
    return {
        routeAdapter: nokia.mh5.adapters.Route,
        constructor: j = function(a, b) {
            this.routeAdapter = a.routeAdapter ? a.routeAdapter : this.routeAdapter;
            g.constructor.call(this, a, b)
        },
        build: function() {
            var b = this.parameters || {
                mode: "walk"
            },
                c = this.from,
                d = this.to,
                e = nokia.mh5.event,
                l = e.add,
                o = e.fire,
                u = this.inputs.from,
                w = this.inputs.to,
                e = function(b) {
                    var c = h.call(this, j),
                        d = w == b.target ? "to" : "from",
                        f = c[d + "List"],
                        b = b.data.results,
                        e = 0 < b.length;
                    (f.visible = e) ? f.items = b : this.input.value = c[d] && c[d].name || "from" == d && a.available && i || ""
                },
                v = function(a) {
                    o(h.call(this, j), "error", a.data)
                };
            Object.defineProperties(this, {
                parameters: {
                    enumerable: !0,
                    get: function() {
                        return this._routeParameters
                    },
                    set: function(a) {
                        this._routeParameters = {};
                        nokia.mh5.each(a, function(a, b) {
                            this._routeParameters[b] = "function" === typeof a ? a.bind(this) : a
                        }, this);
                        this.mode.button.select(this._routeParameters.mode);
                        this.route()
                    }
                },
                from: {
                    enumerable: !0,
                    get: function() {
                        return this._from
                    },
                    set: function(a) {
                        this._from = a;
                        this.inputs.from.input.value = a && a.name || "";
                        this.route()
                    }
                },
                to: {
                    enumerable: !0,
                    get: function() {
                        return this._to
                    },
                    set: function(a) {
                        this._to = a;
                        this.inputs.to.input.value = a && a.name || "";
                        this.route()
                    }
                }
            });
            !b.mode && (b.mode = "walk");
            b && (this.parameters = b);
            c && (this.from = c);
            d && (this.to = d);
            l(u, "beforesearch", function(b) {
                if (b.data.query == i) b.preventDefault(), a.available ? this.parent.parent.from = {
                    name: i,
                    latitude: a.latitude,
                    longitude: a.longitude
                } : u.input.value = ""
            });
            l(u, "success", e);
            l(u, "error", v);
            l(u, "clear", function() {
                var b = h.call(this, j);
                b.from && b.from.name != i && a.available ? b.from = {
                    name: i,
                    latitude: a.latitude,
                    longitude: a.longitude
                } : (b.from = void 0, o(b, "clear"))
            });
            l(w, "success", e);
            l(w, "error", v);
            l(w, "clear", function() {
                h.call(this, j).to = void 0;
                o(h.call(this, j), "clear")
            });
            l(a, "positionactivate", function() {
                var b = this.inputs.from,
                    c = b.completion.renderedItems;
                "" === b.input.value && (this.from = {
                    name: i,
                    latitude: a.latitude,
                    longitude: a.longitude
                });
                c.length && c[0].update && c[0].update("active")
            }.bind(this));
            l(a, ["positionerror", "positiondeactivate", "positionlost"], function() {
                this.inputs.from.input.value == i && (this.from = void 0)
            }.bind(this));
            g.build.call(this)
        },
        cssClass: "mh5_Route",
        children: ["inputs", "mode", "fromList", "toList"],
        inputs: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_inputs",
            layout: {
                type: nokia.mh5.ui.ColumnLayout
            },
            children: ["from", "to"],
            from: {
                control: nokia.mh5.components.Search,
                completionAdapter: {
                    get: function(b, c) {
                        var d = a.status,
                            e = "active" == d || "waiting" == d;
                        nokia.mh5.components.Search.SEARCH_COMPLETION.get.call(this, b, function(a) {
                            e && a.unshift(i);
                            c(a)
                        }, e ? 3 : 4)
                    },
                    add: function(a) {
                        a != i && nokia.mh5.components.Search.SEARCH_COMPLETION.add(a)
                    }
                },
                completion: {
                    itemsDidChange: function(b) {
                        var c = b.length && b[0].text == i,
                            e = a.status;
                        c && (b[0].itemClass = d);
                        this.constructor.prototype.itemsDidChange.call(this, b);
                        c && this.renderedItems[0].update(e)
                    }
                },
                input: {
                    placeholder: b("from"),
                    cssClass: "mh5_TextInput mh5_secondaryColorBrightPH mh5_secondaryColorBright"
                }
            },
            to: {
                control: nokia.mh5.components.Search,
                input: {
                    placeholder: b("to"),
                    cssClass: "mh5_TextInput mh5_secondaryColorBrightPH mh5_secondaryColorBright"
                }
            }
        },
        mode: {
            control: nokia.mh5.ui.Container,
            children: ["button"],
            button: {
                control: nokia.mh5.ui.SegmentedButton,
                cssClass: "mh5_SegmentedIconButton mh5_mode mh5_ColumnLayout",
                items: ["drive", "walk", "pt"].map(function(a) {
                    return {
                        iconClass: "mh5_icon_" + a,
                        value: a
                    }
                }),
                onValueChange: function(a) {
                    var b = h.call(this, j),
                        c = b.parameters;
                    if (c.mode !== a) c.mode = a, b.route()
                }
            }
        },
        fromList: {
            control: nokia.mh5.ui.List,
            itemClass: nokia.mh5.components.PlaceListItem,
            visible: !1,
            onClick: function(a) {
                this.parent.from = this.items[a];
                this.visible = !1
            }
        },
        toList: {
            control: nokia.mh5.ui.List,
            itemClass: nokia.mh5.components.PlaceListItem,
            visible: !1,
            onClick: function(a) {
                this.parent.to = this.items[a];
                this.visible = !1
            }
        },
        route: function() {
            var b = nokia.mh5.event.fire,
                c = this,
                d = c.from && c.from.name != i && c.from || a.available && a.coords,
                e = c.to,
                g = c.parameters,
                h;
            if (d && e && (h = b(c, "beforeroute", {
                from: d,
                to: e,
                parameters: g
            }), !h.defaultPrevented)) h = d.name == i && delete d.name, c._from = c._from || {}, c._from.latitude = d.latitude, c._from.longitude = d.longitude, c.routeAdapter.fetch([d, e], g, function(a) {
                b(c, "success", a)
            }, function(a) {
                b(c, "error", {
                    message: a
                })
            }), h && (d.name = i)
        }
    }
});
nokia.mh5.provide("nokia.mh5.components.IncidentDetails");
nokia.mh5.components.IncidentDetails = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    function a(a) {
        return 10 > a ? "0" + a : a
    }
    function b(b) {
        return b.toLocaleDateString() + " " + b.getHours() + ":" + a(b.getMinutes()) + ":" + a(b.getSeconds())
    }
    var c = nokia.mh5.dom,
        e = nokia.mh5.i18n,
        i = nokia.mh5.win,
        h = [e("maps.Traffic.critical"), e("maps.Traffic.major"), e("maps.Traffic.minor")];
    return {
        control: nokia.mh5.ui.Container,
        children: ["filler", "title", "data", "fillup"],
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        filler: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_incidentDetailsFiller",
            onClick: function() {
                this.parent.visible = !1
            }
        },
        title: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_incidentDetailsTitle mh5_standardBackgroundColorDark"
        },
        data: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_incidentDetailsData"
        },
        fillup: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_fillup"
        },
        cssClass: "mh5_IncidentDetails",
        build: function() {
            this.resize = this.resize.bind(this);
            g.build.call(this)
        },
        resize: function() {
            var a = this.getContentRoot();
            c[a.offsetHeight > this.root.offsetHeight ? "addClass" : "removeClass"](a.parentNode, "mh5_fillupDisable");
            this._scroll && i.setTimeout(this._scroll.refresh, 1)
        },
        vScroll: !0,
        bounce: !1,
        incident: null,
        incidentDidChange: function(a) {
            if (a) {
                var c, f = a.icon,
                    a = a.incident;
                c = "<p>" + (e("maps.Traffic.incidentStartTime") + ": " + b(a.startTime) + "<br>" + e("maps.Traffic.incidentEndTime") + ": " + b(a.endTime) + "</p>");
                this.title.root.innerHTML = c;
                c = "<div class='header'><div style='background-image:url(" + f + ")'></div><h1 class='mh5_title'>" + (e("maps.Traffic." + a.type.replace(/\s/g, "")) || e("maps.Traffic.Othernews")) + "</h1></div>" + (a.origin ? "<p>" + e("maps.Traffic.incidentDescription" + (a.direction ? "" : "NoDirection"), {
                    origin: a.origin,
                    direction: a.direction
                }) + "</p>" : "");
                f = a.end ? a.bidirectional ? "maps.Traffic.incidentBidir" : "maps.Traffic.incidentUnidir" : "maps.Traffic.incidentAt";
                c += "<p>" + (a.start ? e(f, {
                    start: a.start,
                    end: a.end
                }) + "<br>" : "") + a.description + "</p><p>" + e("maps.Traffic.criticalityTitle") + ": " + h[a.criticality] + "</p>";
                this.data.root.innerHTML = c
            } else this.title.root.innerHTML = "", this.data.root.innerHTML = "";
            var g = this;
            i.setTimeout(function() {
                g.resize()
            }, 500)
        },
        visibleDidChange: function(a) {
            a ? (c.addEvent(i, "viewportchange", this.resize, !1), this.resize()) : c.removeEvent(i, "viewportchange", this.resize, !1);
            g.visibleDidChange.call(this, a)
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.ProgressBar");
nokia.mh5.ui.ProgressBar = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        rootHtmlElementName: "div",
        innerHTML: "<div class='left'></div><div class='right'></div><div class='overlay'><div><div class='left'></div><div class='right'></div></div></div>",
        cssClass: "mh5_ProgressBar",
        progressRatio: 0,
        targetProgressRatio: 0,
        progressIncrement: 0.02,
        refreshTimeout: 1E3 / 30,
        constructor: function() {
            g.constructor.apply(this, arguments);
            this.refresh = this.refresh.bind(this);
            this.update()
        },
        update: function() {
            this.refresh()
        },
        setProgress: function(a) {
            a = Math.min(1, a);
            this.targetProgressRatio = a = Math.max(0, a);
            this.refresh()
        },
        refresh: function() {
            var a = this.targetProgressRatio - this.progressRatio,
                b;
            if (a) b = Math.abs(a), b <= this.progressIncrement ? this.progressRatio = this.targetProgressRatio : (a /= Math.abs(a), this.progressRatio += a * this.progressIncrement, setTimeout(this.refresh, this.refreshTimeout)), this.updateProgressDOM()
        },
        updateProgressDOM: function() {
            var a = this.root.children[0],
                b = this.root.children[1],
                c = this.root.children[2],
                e = c.children[0],
                g = a.clientWidth + b.clientWidth;
            c.style.width = this.progressRatio * (a.clientWidth + 2 * b.clientWidth) + "px";
            e.style.width = g + "px"
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.SaveProgressDialog");
nokia.mh5.maps.SaveProgressDialog = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a = nokia.mh5.i18n,
        b, c = {
            starting: a("maps.SPD.startDownload"),
            waiting: a("maps.SPD.savingArea"),
            loading: a("maps.SPD.savingArea"),
            error: a("Notification.error"),
            finished: a("done")
        },
        e = {
            starting: a("maps.SPD.instructionStart"),
            loading: a("maps.SPD.instructionLoad"),
            error: "",
            finished: a("maps.SPD.instructionFinished")
        },
        i = {
            warning: a("maps.SPD.keepInMind"),
            cancelButton: a("cancel"),
            startButton: a("start")
        },
        h = a("maps.SPD.minZoom"),
        d = a("maps.SPD.maxZoom"),
        j = nokia.mh5.ui.Container,
        f = nokia.mh5.ui.Control;
    return {
        cssClass: "mh5_SaveProgressDialog mh5_modal",
        currentState: "starting",
        children: ["contents"],
        downloadTitles: c,
        downloadInstructions: e,
        startingScreenTexts: i,
        progressObject: null,
        contents: {
            control: j,
            children: ["header", "startingContainer", "errorContainer", "finishedContainer"],
            header: {
                control: j,
                children: ["headerWrapper"],
                cssClass: "mh5_dialogHeader",
                headerWrapper: {
                    control: j,
                    children: ["title", "instructions"],
                    title: {
                        control: f,
                        rootHtmlElementName: "h1",
                        cssClass: "mh5_title"
                    },
                    instructions: {
                        control: f,
                        cssClass: "mh5_instructions"
                    }
                }
            },
            startingContainer: {
                control: j,
                cssClass: "mh5_screenContainer",
                children: ["mapPreview", "warning", "progressText", "progressBar", "buttons"],
                mapPreview: {
                    control: j,
                    cssClass: "mh5_mapPreviews",
                    children: ["lowZoom", "highZoom"],
                    lowZoom: {
                        control: nokia.mh5.components.Map,
                        passive: !0,
                        suggestions: !1,
                        addressLookup: !1,
                        positionButton: null,
                        cssClass: "mh5_mapPreview",
                        moveToUserPosition: !1,
                        mapLogo: !1,
                        children: ["label", "mapContainer"],
                        label: {
                            cssClass: "mh5_label",
                            control: f,
                            rootHtmlElementName: "span",
                            innerHTML: h
                        }
                    },
                    highZoom: {
                        control: nokia.mh5.components.Map,
                        passive: !0,
                        suggestions: !1,
                        addressLookup: !1,
                        positionButton: null,
                        cssClass: "mh5_mapPreview",
                        moveToUserPosition: !1,
                        mapLogo: !1,
                        children: ["label", "mapContainer"],
                        label: {
                            cssClass: "mh5_label",
                            control: f,
                            rootHtmlElementName: "span",
                            innerHTML: d
                        }
                    }
                },
                warning: {
                    cssClass: "mh5_warning",
                    control: f,
                    innerHTML: i.warning
                },
                progressText: {
                    control: f,
                    cssClass: "mh5_progressText",
                    rootHtmlElementName: "span",
                    innerHTML: a("maps.SPD.waiting"),
                    visible: !1
                },
                progressBar: {
                    control: nokia.mh5.ui.ProgressBar,
                    visible: !1
                },
                buttons: {
                    control: j,
                    cssClass: "mh5_buttonContainer",
                    children: ["cancel", "start"],
                    cancel: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: i.cancelButton,
                        onClick: function() {
                            var a = this.getRootOwnerByClass(b);
                            a._closeDialog();
                            a.progressObject.stop();
                            if (a.onCancel) a.onCancel()
                        }
                    },
                    start: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: i.startButton,
                        onClick: function() {
                            this.disabled = !0;
                            this.getRootOwnerByClass(b)._startProgressObject()
                        }
                    }
                }
            },
            errorContainer: {
                control: j,
                cssClass: "mh5_screenContainer",
                children: ["text", "buttons"],
                visible: !1,
                text: {
                    control: f,
                    rootHtmlElementName: "span",
                    innerHTML: a("maps.SPD.smtUnexpected")
                },
                buttons: {
                    control: j,
                    cssClass: "mh5_buttonContainer",
                    children: ["closeButton", "resumeButton"],
                    resumeButton: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: a("retry"),
                        onClick: function() {
                            this.disabled = !0;
                            this.getRootOwnerByClass(b).progressObject.resume()
                        }
                    },
                    closeButton: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: a("cancel"),
                        onClick: function() {
                            var a = this.getRootOwnerByClass(b);
                            a.progressObject.stop();
                            a._closeDialog();
                            if (a.onCancel) a.onCancel()
                        }
                    }
                }
            },
            finishedContainer: {
                control: j,
                cssClass: "mh5_screenContainer",
                children: ["image", "buttons"],
                visible: !1,
                image: {
                    control: j,
                    innerHTML: "<img src='lcapp/img/maps/savingdialog/example.png'>"
                },
                buttons: {
                    control: j,
                    cssClass: "mh5_buttonContainer",
                    children: ["closeButton"],
                    closeButton: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: a("ok"),
                        onClick: function() {
                            var a = this.getRootOwnerByClass(b);
                            a._closeDialog();
                            if (a.onFinish) a.onFinish()
                        }
                    }
                }
            }
        },
        constructor: b = function(a, b) {
            a.disableUpdatePosition = !0;
            a.allowScrolling = !0;
            g.constructor.call(this, a, b);
            this.onFinish = a && a.onFinish;
            this.onCancel = a && a.onCancel;
            this.isSuccess = !1;
            if (a && (this.downloadTitles = a.downloadTitles || this.downloadTitles, this.downloadInstructions = a.downloadInstructions || this.downloadInstructions, this._setCurrentState("starting"), this._initializeMapPreviews(a.mapState), a.progressObject)) this.progressObject = a.progressObject, this.progressObject.onprogress = function(a) {
                switch (a.type) {
                case "error":
                    this.contents.errorContainer.buttons.resumeButton.disabled = !1;
                    this._setCurrentState("error");
                    break;
                case "progress":
                    this._timeSinceLastEvent = 0;
                    this._setCurrentState("loading");
                    this._updateProgress(a);
                    break;
                case "load":
                    this.isSuccess = !0, this._setCurrentState("finished")
                }
            }.bind(this);
            this._update()
        },
        _initializeMapPreviews: function(a) {
            var b = this.contents.startingContainer.mapPreview;
            if (a)["highZoom", "lowZoom"].forEach(function(c) {
                b[c].schema = a.schema;
                b[c].center = a.center;
                b[c].box = a.box
            }), b.lowZoom.zoom = a.zoom.low, b.highZoom.zoom = a.zoom.high
        },
        _startProgressObject: function() {
            nokia.mh5.components.settings.set("hasOfflineMaps", !1);
            this.progressObject.start();
            this._startTimeoutTimer()
        },
        _startTimeoutTimer: function() {
            var a = this,
                b = function() {
                    setTimeout(b, 500);
                    if ("loading" === a.currentState) {
                        if (a._timeSinceLastEvent += 500, 15E3 < a._timeSinceLastEvent) a.progressObject.pause(), a._timeSinceLastEvent = 0, a._setCurrentState("error")
                    } else a._timeSinceLastEvent = 0
                };
            b()
        },
        _setCurrentState: function(a) {
            if (this.currentState !== a) this.currentState = a, this._update()
        },
        _update: function() {
            var a = this.contents,
                b = a.header.headerWrapper,
                c = a.startingContainer;
            b.title.root.innerHTML = this.downloadTitles[this.currentState];
            b.instructions.root.innerHTML = this.downloadInstructions[this.currentState];
            c.visible = "starting" === this.currentState || "loading" === this.currentState;
            c.buttons.start.visible = "starting" === this.currentState;
            c.warning.visible = "loading" !== this.currentState;
            c.progressText.visible = c.progressBar.visible = "loading" === this.currentState;
            a.errorContainer.visible = "error" === this.currentState;
            a.finishedContainer.visible = "finished" === this.currentState
        },
        _updateProgress: function(a) {
            var a = a.data,
                b = this.contents.startingContainer;
            b.progressBar.setProgress(a.current / a.total);
            b.progressText.root.innerHTML = "".concat((a.downloaded / 1024 / 1024).toFixed(2), " MB")
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.SegmentedBar");
nokia.mh5.maps.SegmentedBar = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    var a = nokia.mh5.components.Map;
    return {
        cssClass: "mh5_SegmentedBar",
        constructor: function(b) {
            g.constructor.call(this);
            b = b || {};
            Object.keys(b).forEach(function(a) {
                this[a] = b[a]
            }, this);
            void 0 === this.min && (this.min = a.MIN_ZOOM_LEVEL);
            void 0 === this.max && (this.max = a.MAX_ZOOM_LEVEL);
            this.segments = [];
            for (var c = 0, e = this.max - this.min; c <= e; c += 1) this.segments[c] = {
                node: this.root.appendChild(nokia.mh5.doc.createElement("div")),
                value: this.segments[c - 1] ? this.segments[c - 1].value + 1 : this.min
            }, this.segments[c].node.className = "mh5_segment"
        },
        setRange: function(a, c) {
            void 0 === c && (c = a);
            this.segments.forEach(function(e) {
                nokia.mh5.dom.removeClass(e.node, "mh5_active");
                e.value >= a && e.value <= c && nokia.mh5.dom.addClass(e.node, "mh5_active")
            })
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.CameraViewDialog");
nokia.mh5.maps.CameraViewDialog = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a = nokia.mh5.i18n,
        b = function(a) {
            a.preventDefault();
            a.stopPropagation()
        },
        c = a("saveMapArea"),
        e = a("maps.CVD.details"),
        i = a("maps.CVD.viewDetails"),
        h = a("maps.CVD.tooLarge"),
        d = a("maps.CVD.goOnline"),
        j = nokia.mh5.components.settings,
        f = nokia.mh5.event.add,
        k = nokia.mh5.event.remove,
        m = nokia.mh5.ui.Control,
        n = nokia.mh5.ui.Container,
        l;
    return {
        cssClass: "mh5_modal mh5_CameraViewDialog",
        children: ["map", "content"],
        map: {
            control: nokia.mh5.components.Map,
            cssClass: "mh5_Map",
            moveToUserPosition: !1,
            suggestions: !1,
            addressLookup: !1,
            mapLogo: !1
        },
        content: {
            control: n,
            cssClass: "mh5_cameraViewContainer",
            children: ["header", "cameraFinderContainer"],
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            header: {
                control: n,
                cssClass: "mh5_cameraViewHeader",
                children: ["settingsTitle", "instructions", "detailsLevelIndicator", "infoButton"],
                settingsTitle: {
                    control: m,
                    rootHtmlElementName: "h1",
                    cssClass: "mh5_title",
                    innerHTML: c
                },
                instructions: {
                    control: m,
                    rootHtmlElementName: "span",
                    cssClass: "mh5_instructions"
                },
                infoButton: {
                    control: m,
                    cssClass: "mh5_InfoDialogOpen",
                    onClick: function() {
                        this.getRootOwnerByClass(l)._openInfoDialog()
                    }
                },
                detailsLevelIndicator: {
                    control: nokia.mh5.maps.SegmentedBar
                }
            },
            cameraFinderContainer: {
                control: n,
                cssClass: "mh5_cameraViewFinder",
                children: ["buttons"],
                buttons: {
                    control: n,
                    cssClass: "mh5_cameraFinderContainer",
                    children: ["cancelButton", "saveButton"],
                    saveButton: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: a("save"),
                        onClick: function(a) {
                            var c;
                            a && b(a);
                            clearTimeout(c || 0);
                            c = setTimeout(function() {
                                c = 0;
                                this.getRootOwnerByClass(l)._saveOfflineMap(!0)
                            }.bind(this), 10)
                        }
                    },
                    cancelButton: {
                        control: nokia.mh5.ui.Button,
                        cssClass: "mh5_Button mh5_textButton",
                        text: a("cancel"),
                        onClick: function(a) {
                            a && b(a);
                            this.getRootOwnerByClass(l)._closeDialog()
                        }
                    }
                }
            }
        },
        build: function() {
            this._map = this.map._map;
            ["_mapZoomChangeListener", "_mapReadyListener"].forEach(function(a) {
                this[a] = this[a].bind(this)
            }, this);
            g.build.call(this)
        },
        constructor: l = function(a, b) {
            a = a || {};
            a.disableUpdatePosition = !0;
            a.allowScrolling = !0;
            g.constructor.call(this, a, b);
            this.oldSchema = a && a.oldSchema;
            var c = a && a.oldMap;
            if (c) this.map.tracking = !1, this.map.box = c.box, this.map.zoom = c.zoom;
            this._setInstructionText()
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.call(this, a);
            clearTimeout(this.visibleTimer || 0);
            this.visibleTimer = setTimeout(function(b) {
                a ? (m.watch(j.current, "isOnline", b, b._isOnlineChanged), nokia.mh5.app.controller.current.page.visible = !1) : m.removeBinding(j.current, "isOnline", b, b._isOnlineChanged)
            }, 800, this)
        },
        _addHandlers: function() {
            g._addHandlers.call(this);
            f(this.map, "ready", this._mapReadyListener);
            f(nokia.mh5.win, "viewportchange", this._mapZoomChangeListener)
        },
        _mapReadyListener: function() {
            f(this.map._map, "mapzoomchange", this._mapZoomChangeListener);
            this._setZooms()
        },
        _removeHandlers: function() {
            g._removeHandlers.call(this);
            k(this.map._map, "mapzoomchange", this._mapZoomChangeListener);
            k(this.map, "ready", this._mapReadyListener);
            k(nokia.mh5.win, "viewportchange", this._mapZoomChangeListener)
        },
        _calcStorableZoomLevels: function() {
            var a;
            this.maxStorableZoomLevels = this.maxStorableZoomLevels || 0;
            a = this._map.maxStorableZoom() - (this._currentZoom || this.map.zoom);
            if (this.maxStorableZoomLevels < a) this.maxStorableZoomLevels = a;
            return this.storableZoomLevels = a
        },
        _mapZoomChangeListener: function(a) {
            this._setZooms(a)
        },
        _setZooms: function(a) {
            var b = this._map.MAX_ZOOM_LEVEL,
                c = this.content.header.detailsLevelIndicator;
            this._currentZoom = a && a.data.newValue || this.map.zoom;
            a = void 0 === this.storableZoomLevels || this.storableZoomLevels <= this.maxStorableZoomLevels ? this._calcStorableZoomLevels() : this.storableZoomLevels;
            this._maxDetailLevelZoom = b = this._currentZoom < b - a ? this._currentZoom + a : b;
            c.setRange(this._currentZoom, b)
        },
        _closeDialog: function() {
            nokia.mh5.app.controller.current.page.visible = !0;
            j.set("mapSchema", this.oldSchema || j.get("mapSchema"));
            g._closeDialog.call(this)
        },
        _isOnlineChanged: function() {
            this.content.cameraFinderContainer.buttons.saveButton.disabled = !j.get("isOnline")
        },
        _setInstructionText: function() {
            var a = this.content.header,
                b = e;
            j.get("isOnline") ? this.content.cameraFinderContainer.buttons.saveButton.disabled ? b = h : j.get("hasOfflineMaps") && (b = i) : b = d;
            a.instructions.root.innerHTML = b
        },
        _openInfoDialog: function() {
            var b = new nokia.mh5.ui.Dialog({
                cssClass: "mh5_InfoDialog mh5_modal mh5_modalBg",
                vScroll: !0,
                disableUpdatePosition: !0,
                content: {
                    control: n,
                    cssClass: "mh5_InfoContainer",
                    children: ["contentHeader", "contentText", "contentList"],
                    contentHeader: {
                        control: n,
                        cssClass: "mh5_InfoHeader",
                        children: ["title", "closeIndicator"],
                        title: {
                            control: m,
                            rootHtmlElementName: "h1",
                            cssClass: "mh5_title",
                            innerHTML: a("maps.CVD.title")
                        },
                        closeIndicator: {
                            control: m,
                            cssClass: "mh5_InfoDialogClose",
                            onClick: function() {
                                b._closeDialog()
                            }
                        }
                    },
                    contentText: {
                        control: n,
                        cssClass: "mh5_InfoDialogText",
                        innerHTML: a("maps.CVD.rangeOfDetails")
                    },
                    contentList: {
                        control: n,
                        rootHtmlElementName: "ul",
                        innerHTML: "<li><img src='lcapp/img/maps/infodialog/view1.png'><h3>" + a("maps.CVD.world") + "</h3><img src='lcapp/img/maps/infodialog/detailbar1.png'><div>" + a("maps.CVD.worldDesc") + "</div></li><li><img src='lcapp/img/maps/infodialog/view2.png'><h3>" + a("maps.CVD.country") + "</h3><img src='lcapp/img/maps/infodialog/detailbar2.png'><div>" + a("maps.CVD.countryDesc") + "</div></li><li><img src='lcapp/img/maps/infodialog/view3.png'><h3>" + a("maps.CVD.city") + "</h3><img src='lcapp/img/maps/infodialog/detailbar3.png'><div>" + a("maps.CVD.cityDesc") + "</div></li><li><img src='lcapp/img/maps/infodialog/view4.png'><h3>" + a("maps.CVD.district") + "</h3><img src='lcapp/img/maps/infodialog/detailbar4.png'><div>" + a("maps.CVD.districtDesc") + "</div></li><li><img src='lcapp/img/maps/infodialog/view5.png'><h3>" + a("maps.CVD.street") + "</h3><img src='lcapp/img/maps/infodialog/detailbar5.png'><div>" + a("maps.CVD.streetDesc") + "</div></li>"
                    }
                }
            });
            return b
        },
        _saveOfflineMap: function() {
            var a = this,
                b = this._map,
                c = b.bbox;
            c[0] = b.geoToPoint(c[0]);
            c[0].y += 50;
            c[0] = b.pointToGeo(c[0]);
            if (this._progressObject = this.map.storeTiles({
                box: c,
                hold: !0
            })) {
                nokia.mh5.maps.analytics.log({
                    gn: "map download started",
                    c32: "map download started",
                    ev: "event32",
                    c33: "lat0:" + c[0].latitude + ",lon0:" + c[0].longitude + ",lat1:" + c[1].latitude + ",lon1:" + c[1].longitude,
                    v33: "~c33"
                });
                this.content.visible = !1;
                var d = new nokia.mh5.maps.SaveProgressDialog({
                    progressObject: this._progressObject,
                    onFinish: function() {
                        nokia.mh5.maps.analytics.log(d.isSuccess ? {
                            gn: "map download completed",
                            c32: "map download completed",
                            ev: "event35"
                        } : {
                            gn: "map download failed",
                            c32: "map download failed",
                            ev: "event33"
                        });
                        j.set("hasOfflineMaps", d.isSuccess);
                        a.content.visible = !0;
                        a._closeDialog()
                    },
                    onCancel: function() {
                        nokia.mh5.maps.analytics.log({
                            gn: "map download canceled by user",
                            c32: "map download canceled by user",
                            ev: "event34"
                        });
                        a._progressObject = null;
                        a.content.visible = !0
                    },
                    mapState: {
                        zoom: {
                            high: this._maxDetailLevelZoom,
                            low: this.map.zoom
                        },
                        box: this.map.box,
                        center: this.map.center,
                        schema: this.map.schema
                    }
                })
            } else nokia.mh5.maps.analytics.log({
                gn: "map download failed",
                c32: "map download failed",
                ev: "event33"
            }), nokia.mh5.platform.offlineStorageSupported ? Function("", "alert('Error while starting to save. You may not have enough space on your device.');")() : Function("", "alert('Error while starting to save. Your device may not support this feature.');")()
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.SpringBoard");
nokia.mh5.maps.SpringBoard = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a = nokia.mh5.i18n,
        b = nokia.mh5.components.settings,
        c = nokia.mh5.ui.Button,
        e = nokia.mh5.ui.Container,
        i = nokia.mh5.ui.Control,
        h = nokia.mh5.event,
        d = nokia.mh5.sso,
        j = nokia.mh5.dom;
    return {
        cssClass: "mh5_modal mh5_SpringBoard",
        content: {
            control: e,
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            children: ["sso", "dialogBottom"],
            cssClass: "mh5_Dialog",
            sso: {
                visible: !nokia.mh5.platform.wphone,
                control: e,
                layout: {
                    type: nokia.mh5.ui.ColumnLayout
                },
                cssClass: "mh5_ssoContainer",
                children: ["title", "signin", "signout"],
                title: {
                    control: i,
                    cssClass: "mh5_title mh5_no_callout",
                    rootHtmlElementName: "h1",
                    build: function() {
                        var b = function() {
                                var b = d.getUserData("greetingname");
                                return b ? a("hi", {
                                    name: b
                                }) : j.createHyperlinkHTML({
                                    href: "http://here.com/news/",
                                    target: "_blank"
                                }, a("welcome"))
                            };
                        this.root.innerHTML = b();
                        h.add(nokia.mh5.win, ["sso_signin", "sso_signout"], function() {
                            this.root.innerHTML = b()
                        }.bind(this))
                    },
                    onClick: function(a) {
                        a.stopPropagation()
                    }
                },
                signin: {
                    control: i,
                    cssClass: "mh5_action mh5_SpringBoardSignIn mh5_baseColor",
                    build: function() {
                        var a = !1,
                            b = function(b) {
                                nokia.mh5.maps.analytics.log({
                                    gn: "springboard:signin",
                                    c32: "sign in",
                                    v32: "~c32"
                                });
                                b.stopPropagation();
                                if (a) return a = !1;
                                a = !! d.login()
                            };
                        h.add(this.root, "down", b);
                        this.root.onclick = b;
                        if (d.isAuthenticated()) this.visible = !1
                    },
                    innerHTML: a("signin")
                },
                signout: {
                    control: i,
                    cssClass: "mh5_action mh5_SpringBoardSignOut mh5_baseColor",
                    innerHTML: a("signout"),
                    visible: !1,
                    build: function() {
                        if (d.isAuthenticated()) this.visible = !0;
                        this.root["on" + (h.isTouch ? "touchstart" : "click")] = function() {
                            if (!this.disabled) this.disabled = !0, j.addClass(this.root, "mh5_disabled"), nokia.mh5.maps.analytics.log({
                                gn: "springboard:signout",
                                c32: "sign out",
                                v32: "~c32"
                            }), d.logout(function() {
                                this.disabled = !1;
                                j.removeClass(this.root, "mh5_disabled")
                            }.bind(this))
                        }.bind(this)
                    },
                    onClick: function(a) {
                        a.stopPropagation()
                    }
                }
            },
            dialogBottom: {
                control: e,
                children: ["icons", "saveOfflineMaps", "gotoOfflineMaps"],
                layout: {
                    type: nokia.mh5.ui.RowLayout
                },
                cssClass: "mh5_SpringBoardBottom",
                icons: {
                    control: e,
                    cssClass: "mh5_DialogActions",
                    layout: {
                        type: nokia.mh5.ui.ColumnLayout
                    },
                    children: ["home", "routing", "collections", "feedback", "about"],
                    home: {
                        control: c,
                        text: a("search"),
                        target: "_blank",
                        cssClass: "mh5_action mh5_SpringBoardHome mh5_baseColor",
                        onClick: function() {
                            this.parent.parent.parent.parent._closeDialog();
                            "search" !== nokia.mh5.app.controller.current.name && nokia.mh5.app.controller.switchTo("search", {
                                mapMode: !0
                            })
                        }
                    },
                    routing: {
                        control: c,
                        text: a("route"),
                        target: "_blank",
                        cssClass: "mh5_action mh5_SpringBoardRouting mh5_baseColor",
                        onClick: function() {
                            var a = nokia.mh5.app.controller.current,
                                b = a.page.model,
                                c = a.page.map,
                                a = a.name,
                                c = c ? {
                                    zoom: c.zoom,
                                    center: c.center
                                } : {};
                            this.parent.parent.parent.parent._closeDialog();
                            if ("route" != a) {
                                if ("search" == a && b.selection && !b.selection.incident) c.to = b.selection;
                                nokia.mh5.app.controller.switchTo("route", c)
                            }
                        }
                    },
                    collections: {
                        visible: !nokia.mh5.platform.wphone,
                        control: c,
                        text: a("collections"),
                        target: "_blank",
                        cssClass: "mh5_action mh5_SpringBoardFavourites mh5_baseColor",
                        onClick: function() {
                            this.parent.parent.parent.parent._closeDialog();
                            "collectionList" !== nokia.mh5.app.controller.current.name && (nokia.mh5.maps.analytics.log({
                                gn: "springboard:collections",
                                c32: "collections open",
                                v32: "~c32"
                            }), nokia.mh5.app.controller.switchTo("collectionList", {
                                modeMap: !1
                            }))
                        }
                    },
                    feedback: {
                        control: c,
                        text: a("feedback"),
                        target: "_blank",
                        cssClass: "mh5_action mh5_SpringBoardFeedback mh5_baseColor",
                        onClick: function() {
                            this.parent.parent.parent.parent._closeDialog();
                            "nokia.mh5.maps.NPSPage" !== nokia.mh5.app.controller.current.name && nokia.mh5.app.controller.switchTo("nokia.mh5.maps.NPSPage")
                        }
                    },
                    about: {
                        control: c,
                        text: a("about"),
                        target: "_blank",
                        cssClass: "mh5_action mh5_SpringBoardAbout mh5_baseColor",
                        onClick: function() {
                            var a = nokia.mh5.platform.webview ? "nokia.mh5.maps.AboutPageNative" : "nokia.mh5.maps.AboutPage";
                            this.parent.parent.parent.parent._closeDialog();
                            nokia.mh5.app.controller.current.name !== a && nokia.mh5.app.controller.switchTo(a)
                        }
                    }
                },
                saveOfflineMaps: {
                    control: nokia.mh5.ui.Button,
                    visible: !1,
                    text: a("maps.SB.saveMap"),
                    onClick: function() {
                        this.parent.parent.parent._showSaveOfflineMaps();
                        nokia.mh5.maps.analytics.log({
                            gn: "springboard:save map",
                            c32: "save map button clicked",
                            ev: "event31"
                        })
                    }
                },
                gotoOfflineMaps: {
                    control: nokia.mh5.ui.Button,
                    visible: !1,
                    text: a("maps.SB.viewMap"),
                    onClick: function() {
                        this.parent.parent.parent._showOfflineMaps();
                        nokia.mh5.maps.analytics.log({
                            gn: "springboard:show saved map",
                            c32: "view saved map button clicked",
                            ev: "event36"
                        })
                    }
                }
            }
        },
        constructor: function(a, c) {
            a = a || {};
            a.closeOnTap = !0;
            g.constructor.call(this, a, c);
            var e = nokia.mh5.platform,
                i = new Date,
                i = i.getFullYear() + "-" + (1 + i.getMonth()) + "-" + i.getDate();
            this.content.dialogBottom.icons.feedback.disabled = nokia.mh5.win.localStorage["feedback-provided1.8"] === i;
            nokia.mh5.ui.Control.watch(b.current, "hasOfflineMaps", this);
            var j = this.content.sso;
            h.add(nokia.mh5.win, ["sso_signin", "sso_signout"], function() {
                var a = d.isAuthenticated();
                j.signin.visible = !a;
                j.signout.visible = a
            });
            if (e.offlineStorageSupported) this.content.dialogBottom.saveOfflineMaps.visible = !0;
            nokia.mh5.maps.analytics.log({
                gn: "springboard opened",
                c32: "springboard opened",
                ev: "event30"
            })
        },
        hasOfflineMapsDidChange: function() {
            this.content.dialogBottom.gotoOfflineMaps.visible = b.get("hasOfflineMaps")
        },
        _resetSchema: function() {
            "normal.day" !== b.get("mapSchema") && b.set("mapSchema", "normal.day")
        },
        _showSaveOfflineMaps: function() {
            var a = nokia.mh5.app.controller.getMap(),
                a = a && a._map,
                c = {};
            this._closeDialog();
            if (!a && nokia.mh5.app.controller.current.page.details) a = nokia.mh5.app.controller.current.page.details.map;
            if (a) c.oldMap = a, c.oldSchema = b.get("mapSchema");
            this._resetSchema();
            new nokia.mh5.maps.CameraViewDialog(c)
        },
        _showOfflineMaps: function() {
            var a = this,
                c = nokia.mh5.app.controller,
                d = c.getMap();
            d ? d.showStoredTiles(function() {
                a._closeDialog();
                d.tracking = !1
            }, function() {
                b.set("hasOfflineMaps", !1)
            }) : (c.switchTo("search", {
                mapMode: !0
            }), a._showOfflineMaps())
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.SpringBoardButton");
nokia.mh5.maps.SpringBoardButton = new nokia.mh5.Class(nokia.mh5.ui.Button, function(g) {
    return {
        cssClass: "mh5_Button mh5_spring",
        onClick: function(a) {
            g.constructor.prototype.onClick.call(this, a);
            var b = this.root;
            nokia.mh5.dom.addClass(b, "mh5_open");
            new nokia.mh5.maps.SpringBoard({
                onClose: function() {
                    nokia.mh5.dom.removeClass(b, "mh5_open")
                }
            })
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.Header");
nokia.mh5.maps.Header = new nokia.mh5.Class(nokia.mh5.ui.Container, {
    children: ["caption", "back", "brandLogo", "fillup", "spring"],
    rootHtmlElementName: "header",
    secondLevel: !0,
    cssClass: "mh5_header mh5_baseBackgroundColor",
    ignorePlatformBackSettings: !1,
    layout: {
        type: nokia.mh5.ui.ColumnLayout,
        align: "stretch"
    },
    caption: {
        control: nokia.mh5.ui.Control,
        cssClass: "mh5_caption",
        visible: !1
    },
    back: {
        control: nokia.mh5.ui.Button,
        visible: !1,
        cssClass: "mh5_Button mh5_back",
        onClick: function() {
            nokia.mh5.app.controller.back.call(nokia.mh5.app.controller)
        },
        visibleDidChange: function(g, a) {
            if (g && !nokia.mh5.platform.backButton && !this.parent.ignorePlatformBackSettings) g = this.visible = !1;
            if (this.parent.brandLogo) this.parent.brandLogo.visible = !g;
            this.constructor.prototype.visibleDidChange.call(this, g, a)
        }
    },
    brandLogo: {
        control: nokia.mh5.ui.Control,
        cssClass: "mh5_brandLogo"
    },
    fillup: {
        control: nokia.mh5.ui.Control,
        cssClass: "mh5_fillup"
    },
    spring: {
        control: nokia.mh5.maps.SpringBoardButton
    },
    titleDidChange: function(g) {
        this.caption.visible = !! g;
        (this.caption.root || this.caption).innerHTML = g || ""
    }
});
nokia.mh5.provide("nokia.mh5.maps.collections.ui.CollectionsBar");
nokia.mh5.maps.collections.ui.CollectionsBar = new nokia.mh5.Class(nokia.mh5.maps.Header, function() {
    return {
        children: "caption,back,brandLogo,fillup,switchMode,spring".split(","),
        switchMode: {
            visible: !1,
            control: nokia.mh5.ui.Button,
            cssClass: "mh5_modeToggle mh5_ListMode mh5_Button",
            onClick: function() {
                var g = nokia.mh5.dom.hasClass(this.root, "mh5_MapMode");
                nokia.mh5.event.fire(this.parent, "switchmode", {
                    map: !g
                });
                g ? (nokia.mh5.dom.removeClass(this.root, "mh5_MapMode"), nokia.mh5.dom.addClass(this.root, "mh5_ListMode")) : (nokia.mh5.dom.removeClass(this.root, "mh5_ListMode"), nokia.mh5.dom.addClass(this.root, "mh5_MapMode"))
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.collections.Page");
(function() {
    nokia.mh5.maps.collections.Page = nokia.mh5.Class(nokia.mh5.ui.Page, function(g) {
        return {
            cssClass: "mh5_Page mh5_CollectionPage",
            control: nokia.mh5.ui.Container,
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            header: {
                control: nokia.mh5.maps.collections.ui.CollectionsBar,
                listeners: {
                    switchmode: function(a) {
                        var a = a.data.map,
                            b = this.parent;
                        b.model.modeMap = b.map.visible = a;
                        nokia.mh5.app.controller.updateHistoryEntry();
                        if (a) if (nokia.mh5.dom.addClass(b.root, "mh5_modeMap"), b.map.pois = b.getFavourites(), !b.map.size.width || !b.map.size.height) nokia.mh5.event.one(b.map, "sizechange", function() {
                            this.box = this.pois
                        });
                        else b.map.box = b.map.pois;
                        else nokia.mh5.dom.removeClass(b.root, "mh5_modeMap")
                    }
                }
            },
            map: {
                control: nokia.mh5.components.Map,
                visible: !1,
                traffic: !0,
                listeners: {
                    poiclick: function(a) {
                        var b = a.data && a.data[0];
                        a.defaultPrevented || b && b.infoBubble && !b.data.incident && this.parent.switchToPlaceDetails(b.data)
                    }
                }
            },
            traffic: {
                control: nokia.mh5.components.Traffic,
                visible: !1
            },
            model: {
                modeMap: !1
            },
            setModel: function(a) {
                g.setModel.apply(this, arguments);
                if ( !! a.modeMap !== this.map.visible) this.header.switchMode.onClick()
            },
            visibleDidChange: function(a) {
                g.visibleDidChange.apply(this, arguments);
                this.model.modeMap && this.map.visibleDidChange.apply(this.map, arguments);
                !a && this.model.lazy && (delete this.model.lazy, nokia.mh5.app.controller.updateHistoryEntry())
            },
            getFavourites: function() {
                return nokia.mh5.components.favourites.get()
            },
            switchToPlaceDetails: function(a) {
                var b = {
                    latitude: a.latitude,
                    longitude: a.longitude
                };
                if (nokia.mh5.utils.isPlace(a)) b.placeId = a.placeId;
                nokia.mh5.app.controller.details(b)
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.components.collections");
(function() {
    var g = nokia.mh5.components.sync,
        a = nokia.mh5.components.favourites,
        b = g.synchronize,
        c = function(a, b) {
            if (Array.isArray(a)) a.forEach(function(a, c) {
                b(a, c)
            });
            else for (var c in a) a.hasOwnProperty(c) && b(a[c], c)
        },
        e = function(a, b) {
            var c = a,
                d;
            if (b) {
                var c = {},
                    f;
                for (f in a) if (a.hasOwnProperty(f) && (d = b(a[f]))) c[d] || (c[d] = !0)
            }
            return nokia.mh5.components.favourites.get().filter(function(a) {
                return c[a.id]
            })
        },
        i = function(a) {
            var b = k.get();
            a && (b = b.filter(function(b) {
                return (b.id + "").split(d, 2)[+a.favorites] === a.key
            }));
            return b
        },
        h = function(a) {
            var b = i(a);
            return !a ? void 0 : b.map(function(b) {
                return (b.id + "").split(d, 2)[+!a.favorites]
            })
        },
        d = "<~>",
        j = function(b, c, d) {
            k.forId(b, function(b, f) {
                var e = k.getId(b, f),
                    g = k.getState()[e],
                    h = function() {
                        c.call(k, {
                            error: !0
                        })
                    };
                g ? "add" == d && (!n.getState(b) || !a.getState(f)) ? (delete k.getState()[e], k.updateState(), h()) : k.callServer({
                    action: ("add" == d ? "add_to_collection=" : "remove_from_collection=") + encodeURIComponent(f + "," + b),
                    objectTypes: k.itemType + "," + n.objectTypes
                }, function(b) {
                    b.id && !b.error ? (a._takeFromServer(b, f, a.getState()), a.updateState(), c.call(k, g)) : h()
                }.bind(k)) : h()
            })
        },
        f = function(a, b, c, d) {
            var f = this,
                a = k.getId(a, b);
            d.call(k, {
                id: a,
                itemType: f.itemType
            }, function(a) {
                c && c.call(f, a)
            })
        },
        k = g.extend({
            objectType: "favoriteInCollection",
            itemType: "favoritePlace",
            prefix: "FC",
            reSync: function() {
                a.clear();
                a.setSyncTimestamp(null);
                n.clear();
                n.setSyncTimestamp(null);
                n.synchronize()
            },
            resetState: function(b) {
                var c = function(c) {
                        a.setSyncTimestamp(null);
                        n.setSyncTimestamp(null);
                        c.synchronize(function() {
                            c.deleteFromServer(b)
                        })
                    };
                c(a);
                c(nokia.mh5.components.collections);
                this.clear()
            },
            forId: function(a, b) {
                if (a) {
                    var c = (a + "").split(d, 2);
                    return b.call(this, c[0], c[1])
                }
            },
            getId: function(a, b) {
                return a + d + b
            },
            getSyncedAssociations: function(b) {
                var c = this;
                return i({
                    key: b,
                    favorites: !0
                }).filter(function(b) {
                    return c.forId(b.id, function(c, d) {
                        var f = n.getState()[c] && n.getState()[c].inSync,
                            e = a.getState()[d] && a.getState()[d].inSync;
                        if (f && e) return b.inSync
                    })
                }).map(function(a) {
                    return c.forId(a.id, function(a) {
                        return a
                    })
                })
            },
            getCollections: function(a) {
                return h({
                    key: a,
                    favorites: !0
                })
            },
            getFavourites: function(a) {
                return h({
                    key: a,
                    favorites: !1
                })
            },
            getFavouritesWithNoAssociations: function() {
                var b = k.get().filter(function(a) {
                    return !a.deleted
                }).map(function(a) {
                    return (a.id + "").split(d, 2)[1]
                });
                return e(a.getState(), function(a) {
                    a = a.id;
                    if (!~b.indexOf(a)) return a
                })
            },
            updateServerObj: function() {},
            addServerObj: function(a, b) {
                j.call(this, a.id, b, "add")
            },
            removeServerObj: function(a, b) {
                j.call(this, a, b, "remove")
            },
            listServerObjs: function(b) {
                var d = {
                    data: []
                },
                    f = this,
                    e = k.getState(),
                    g = a.getState();
                c(g, function(a) {
                    c(a.collectionIds, function(b) {~b.indexOf("Cd") || d.data.push({
                            id: f.getId(b, a.id),
                            updatedTime: a.updatedTime
                        })
                    })
                });
                c(e, function(a, b) {
                    k.forId(b, function(a, c) {
                        g[c] || delete e[b]
                    })
                });
                k.updateState();
                b.call(this, d)
            },
            fixRelations: function(a) {
                var b = k.getState(),
                    d = a.data.oldId,
                    f = a.data.newId;
                c(b, function(a, c) {
                    if (~c.indexOf(d)) {
                        var e = c.replace(d, f);
                        a.id = e;
                        b[e] = a;
                        delete b[c]
                    }
                })
            },
            removeRelation: function(a) {
                var b = k.getState(),
                    d = a.data.objectType,
                    f = a.data.id;
                c(b, function(a, c) {
                    if (~c.indexOf(f)) "favoritePlace" == d ? delete b[c] : (b[c].deleted = !0, b[c].inSync = !1)
                })
            },
            mapServerToClient: function(a) {
                return a
            },
            mapClientToServer: function() {
                throw "this object should not be directly persisted";
            }
        }),
        m = {
            id: null,
            name: "",
            type: "collection",
            description: "",
            image: "",
            imageIcon: "",
            listItems: []
        };
    nokia.mh5.components.collections = g.extend({
        objectType: "collections",
        objectTypes: "collection",
        prefix: "CL",
        relations: k,
        clear: function(b) {
            var c = function(a) {
                    g.clear.call(a, b);
                    a.setSyncTimestamp(null)
                };
            c(k);
            c(a);
            c(this)
        },
        createCollection: function(a, b, c) {
            var d = this,
                f = function(a, c) {
                    var f = [];
                    !b || 0 == b.length ? c && c() : b.forEach(function(e) {
                        d.addToCollection(a, e, function() {
                            f.push(d.relations.getId(a, e));
                            f.length == b.length && c && c()
                        })
                    })
                };
            this.setAsyncMode();
            this.add(a, function(a) {
                a = d.getState()[a.id];
                f(a.id, function() {
                    c && c.call(d, a)
                })
            })
        },
        addToCollection: function(a, b, c) {
            f(a, b, c, k.add)
        },
        removeFromCollection: function(a, b, c) {
            f(a, b, c, k.remove)
        },
        get: function(b) {
            b = g.get.call(this, b);
            b.sort(a.sortFunction);
            return b
        },
        getFromCollection: function(a) {
            var b = e(k.get(), function(b) {
                var c = (b.id + "").split(d, 2);
                if (c[0] === a && !b.deleted) return c[1]
            });
            b.sort(b.sortFunction);
            return b
        },
        getUngrouped: function() {
            var a = k.getFavouritesWithNoAssociations();
            a && a.sort(a.sortFunction);
            return a
        },
        synchronize: function(a) {
            var c = this;
            nokia.mh5.components.favourites.synchronize(function() {
                b.call(c, function() {
                    k.synchronize(a)
                })
            })
        },
        setTempCollection: function(a, b) {
            if (a) m.id = null, m.name = "", m.itemsCount = "", m.description = "", m.image = "", m.imageIcon = "", m.listItems = [];
            if (!b) return !1;
            m.id = b.id || null;
            m.name = b.name || null;
            m.itemsCount = b.itemsCount || null;
            m.description = b.description || null;
            m.image = b.image || null;
            m.imageIcon = b.imageIcon || null;
            m.listItems = b.listItems || null
        },
        getTempCollection: function() {
            return m
        },
        mapServerToClient: function(a) {
            return {
                id: a.id,
                name: a.name ? nokia.mh5.utils.escapeHTML(a.name) : "",
                image: a.landscapeImageUrl,
                imageIcon: a.portraitImageUrl,
                updatedTime: a.updatedTime,
                description: a.description ? nokia.mh5.utils.escapeHTML(a.description) : ""
            }
        },
        mapClientToServer: function(a) {
            return {
                id: a.id,
                name: a.name,
                landscapeImageUrl: a.image,
                portraitImageUrl: a.imageIcon,
                description: a.description
            }
        },
        getJarLevel: function(a) {
            return 99 < a ? 3 : 24 < a ? 2 : 0 < a ? 1 : 0
        },
        updateCollection: function(a, b, c) {
            var d = this.getFromCollection(a),
                f = {},
                e = this;
            if (0 === (d.length === b.length)) c && c();
            else {
                for (var g = 0; g < d.length; g++) f[d[g].id] = -1;
                for (g = 0; g < b.length; g++) f[b[g]] = (f[b[g]] || 0) + 1;
                nokia.mh5.each(f, function(a, b) {
                    0 === a && delete f[b]
                });
                this._asyncSeqFor(f, function(b, c, d) {
                    1 === c ? e.addToCollection(a, b, d) : -1 === c && e.removeFromCollection(a, b, d)
                }, c)
            }
        },
        updateFavourite: function(a, b, c) {
            for (var d = [], f = {}, e = this.get(), g = this, h = 0; h < e.length; h++) for (var i = this.getFromCollection(e[h].id), k = 0; k < i.length; k++) i[k].id == a && d.push(e[h].id);
            if (0 === (d.length === b.length)) c && c();
            else {
                for (h = 0; h < d.length; h++) f[d[h]] = -1;
                for (h = 0; h < b.length; h++) f[b[h]] = (f[b[h]] || 0) + 1;
                nokia.mh5.each(f, function(a, b) {
                    0 === a && delete f[b]
                });
                this._asyncSeqFor(f, function(b, c, d) {
                    1 === c ? g.addToCollection(b, a, d) : -1 === c && g.removeFromCollection(b, a, d)
                }, c)
            }
        },
        _asyncSeqFor: function(a, b, c) {
            var d = [],
                f, e, g = !1;
            "object" === nokia.mh5.type(a) ? (g = !0, nokia.mh5.each(a, function(a, b) {
                d.push({
                    v: a,
                    k: b
                })
            })) : d = a;
            (function s(a) {
                a >= d.length ? c && c() : (f = g ? d[a].k : a, e = g ? d[a].v : d[a], b(f, e, function() {
                    s(a + 1)
                }))
            })(0)
        }
    });
    var n = nokia.mh5.components.collections;
    [n, a].forEach(function(a) {
        nokia.mh5.event.add(a, "object_created", n.relations.fixRelations);
        nokia.mh5.event.add(a, "object_deleted", n.relations.removeRelation)
    });
    nokia.mh5.event.add(nokia.mh5.win, ["sso_signout"], function(a) {
        "sso_signout" === a.type && n.clear()
    });
    nokia.mh5.event.add(nokia.mh5.win, ["sso_signin", "sso_signout"], function() {
        nokia.mh5.components.collections.synchronize(function() {})
    }.bind(this))
})();
nokia.mh5.provide("nokia.mh5.maps.collections.ui.CollectionListItem");
nokia.mh5.maps.collections.ui.CollectionListItem = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    return {
        rootHtmlElementName: "li",
        cssClass: "mh5_CollectionListItem mh5_standardBackgroundColorDark",
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            this.prepareDidChangeNotifications();
            this.update(b.items.length)
        },
        createCollectionContent: function() {
            var a = document.createElement("div");
            a.className = "mh5_CollectionContent mh5_RowLayout";
            this.itemsCount = nokia.mh5.components.collections.getFromCollection(this.id).length;
            var b = document.createElement("div");
            b.className = "mh5_CollectionItemCount mh5_standardColorDark mh5_CollectionJar" + nokia.mh5.components.collections.getJarLevel(this.itemsCount);
            b.innerHTML = this.itemsCount;
            a.appendChild(b);
            var c = document.createElement("div");
            c.className = "mh5_CollectionName";
            c.innerHTML = this.name;
            a.appendChild(c);
            c = document.createElement("div");
            c.className = "mh5_CollectionDescription";
            c.innerHTML = this.description || "";
            a.appendChild(c);
            return {
                container: a,
                itemsCount: b
            }
        },
        update: function() {
            this.root.appendChild(this.createCollectionContent().container);
            if (!0 === this.parent.checkbox) {
                var a = document.createElement("span");
                a.className = "mh5_FavoriteCheckbox";
                this.root.appendChild(a);
                this.selectedDidChange()
            }
        },
        selectedDidChange: function() {
            var a = nokia.mh5.dom,
                b = a.query(".mh5_FavoriteCheckbox", this.root)[0];
            b && (this.selected ? a.addClass(b, "selected") : a.removeClass(b, "selected"))
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.collections.ui.FavouriteListItem");
nokia.mh5.maps.collections.ui.FavouriteListItem = new nokia.mh5.Class(nokia.mh5.components.PlaceListItem, function(g) {
    return {
        cssClass: "mh5_FavouriteListItem mh5_ListItem",
        constructor: function(a, b) {
            delete this.distance;
            g.constructor.apply(this, arguments);
            if (this.parent.edit) this.editButton = this.root.querySelector(".mh5_FavouriteListEdit");
            else if (this.parent.checkbox) this.checkbox = this.root.querySelector(".mh5_FavoriteCheckbox")
        },
        _generateInnerHTML: function() {
            var a = g._generateInnerHTML.call(this);
            this.parent.edit ? a += '<div class="mh5_FavouriteListEdit"><div></div></div>' : this.parent.checkbox && (a += '<div class="mh5_FavoriteCheckboxWrapper"><div class="mh5_FavoriteCheckbox"></div></div>');
            return a
        },
        selectedDidChange: function() {
            var a = nokia.mh5.dom,
                b = this.parent.selectedFavourites;
            this.checkbox && (this.selected ? (a.addClass(this.checkbox, "selected"), b.push(this.id || this)) : (a.removeClass(this.checkbox, "selected"), a = b.indexOf(this.id || this), b.splice(a, 1)))
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.collections.ui.FavouriteList");
(function() {
    var g = nokia.mh5.dom;
    nokia.mh5.maps.collections.ui.FavouriteList = new nokia.mh5.Class(nokia.mh5.ui.List, function(a) {
        return {
            constructor: function(b) {
                a.constructor.apply(this, arguments);
                if (!0 === b.checkbox) this.selectedFavourites = []
            },
            cssClass: "mh5_FavouriteList",
            itemClass: nokia.mh5.maps.collections.ui.FavouriteListItem,
            listeners: {
                tap: function(a) {
                    var c = a && a.data && a.data.originalEvent && a.data.originalEvent.target,
                        e = this.renderedItems[a.data.index],
                        i = g.query(".mh5_FavouriteListEdit", e.root)[0];
                    !0 === this.edit && i && g.contains(i, c) ? nokia.mh5.event.fire(this, "edit", a.data.item) : !0 === this.checkbox ? e.selected = !e.selected : nokia.mh5.event.fire(this, "view", a.data.item)
                }
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.maps.collections.List");
nokia.mh5.maps.collections.List = new nokia.mh5.Class(nokia.mh5.maps.collections.Page, function(g) {
    var a = nokia.mh5.i18n,
        b = nokia.mh5.sso,
        c = nokia.mh5.ui.Control,
        e = nokia.mh5.ui.Button,
        i = nokia.mh5.ui.Container,
        h = nokia.mh5.ui.RowLayout,
        d = nokia.mh5.components.collections;
    return {
        children: ["header", "firstTimeUser", "collectionSection", "itemSection"],
        header: {
            control: nokia.mh5.maps.Header,
            children: "caption,back,brandLogo,fillup,sync,spring".split(","),
            title: a("collections.CollectionListPage.title"),
            sync: {
                control: e,
                cssClass: "mh5_sync mh5_Button",
                build: function() {
                    this.visible = b.isAuthenticated()
                },
                onClick: function() {
                    d.synchronize()
                }
            }
        },
        firstTimeUser: {
            visible: !1,
            control: i,
            children: ["signInFooter", "createButtonSection", "introTextSection", "introImageSection"],
            cssClass: "mh5_CollectionsFTUX",
            layout: {
                type: h
            },
            introTextSection: {
                control: i,
                cssClass: "mh5_CollectionsFTUIntro"
            },
            introImageSection: {
                control: i,
                cssClass: "mh5_CollectionsFTUSection mh5_CollectionsFTUImage"
            },
            signInFooter: {
                control: i,
                cssClass: "mh5_CollectionListItem mh5_collections_whiteButton",
                children: ["signInButton"],
                signInButton: {
                    control: e,
                    iconClass: "mh5_signInIcon",
                    text: a("collections.CollectionListPage.ftu.signIn"),
                    build: function() {
                        var a = !1,
                            c = function() {
                                if (a) return a = !1;
                                a = !! b.login()
                            };
                        nokia.mh5.event.add(this.root, "down", c);
                        this.root.onclick = c
                    }
                }
            },
            createButtonSection: {
                control: i,
                cssClass: "mh5_CollectionListItem mh5_collections_whiteButton",
                children: ["createButton"],
                createButton: {
                    control: e,
                    iconClass: "mh5_createIcon",
                    text: a("collections.CollectionListPage.ftu.button.create"),
                    onClick: function() {
                        nokia.mh5.app.controller.switchTo("collectionManage", {
                            collectionAction: "addItemsForCreate"
                        })
                    }
                }
            }
        },
        collectionSection: {
            visible: !1,
            control: i,
            children: ["createNewCollection", "introTextSection", "collectionSeparator", "collectionList"],
            cssClass: "mh5_ListItemContainer",
            layout: {
                type: h
            },
            createNewCollection: {
                control: i,
                cssClass: "mh5_CollectionListItem mh5_collections_whiteButton",
                children: ["collectionCreateButton"],
                collectionCreateButton: {
                    control: e,
                    iconClass: "mh5_createIcon",
                    text: a("collections.common.button.create"),
                    onClick: function() {
                        nokia.mh5.app.controller.switchTo("collectionManage", {})
                    }
                }
            },
            introTextSection: {
                control: i,
                cssClass: "mh5_CollectionsFTUIntro"
            },
            collectionSeparator: {
                control: c,
                cssClass: "mh5_CollectionListSeparator",
                innerHTML: a("collections.CollectionsBar.myCollections")
            },
            collectionList: {
                visible: !0,
                control: nokia.mh5.ui.List,
                cssClass: "mh5_CollectionListItemContainer",
                itemClass: nokia.mh5.maps.collections.ui.CollectionListItem,
                onClick: function(a) {
                    nokia.mh5.app.controller.switchTo("collectionDetails", {
                        collection: this.items[a],
                        modeMap: !1
                    })
                }
            }
        },
        itemSection: {
            visible: !1,
            control: i,
            children: ["ungroupedSeparator", "ungroupedList"],
            cssClass: "mh5_ListItemContainer",
            layout: {
                type: h
            },
            ungroupedSeparator: {
                control: c,
                cssClass: "mh5_CollectionListSeparator",
                innerHTML: a("collections.CollectionListPage.unsortedItems")
            },
            ungroupedList: {
                control: nokia.mh5.maps.collections.ui.FavouriteList,
                edit: !0,
                listeners: {
                    view: function(a) {
                        this.parent.parent.switchToPlaceDetails(a.data);
                        var b = nokia.mh5.maps.analytics;
                        b.log({
                            gn: "collections:place",
                            v32: "open place",
                            v44: b.getPlaceId(a.data)
                        })
                    },
                    edit: function(a) {
                        nokia.mh5.app.controller.switchTo("favouriteManage", {
                            place: a.data
                        })
                    }
                }
            }
        },
        constructor: function() {
            this.checkLazy = this.checkLazy.bind(this);
            this.draw = this.draw.bind(this);
            g.constructor.apply(this, arguments)
        },
        fetchCollectionList: function() {
            var a = d.get();
            a && 0 < a.length ? (this.firstTimeUser.visible = !1, this.collectionSection.visible = !0, this.collectionSection.collectionSeparator.visible = !0, this.collectionSection.collectionList.items = a) : (this.firstTimeUser.visible = !0, this.collectionSection.visible = !1, this.collectionSection.collectionSeparator.visible = !1, this.collectionSection.collectionList.items = [])
        },
        fetchUngrouped: function() {
            var b = d.getUngrouped();
            this.itemSection.visible = !! b.length;
            this.itemSection.ungroupedList.items = b;
            this.itemSection.ungroupedSeparator.visible = !! b.length;
            this.collectionSection.introTextSection.root.innerHTML = this.firstTimeUser.introTextSection.root.innerHTML = a("collections.CollectionListPage.ftu.intro.signedIn." + (b.length ? "hasUngrouped" : "hasNoUngrouped"));
            b.length && !this.collectionSection.collectionList.items.length ? (this.collectionSection.introTextSection.visible = !0, this.firstTimeUser.visible = !1, this.collectionSection.visible = !0, this.collectionSection.createNewCollection.visible = !0, this.collectionSection.createNewCollection.collectionCreateButton.text = a("collections.CollectionListPage.ftu.button.create"), this.collectionSection.collectionSeparator.visible = !1) : this.collectionSection.createNewCollection.collectionCreateButton.text = a("collections.common.button.create")
        },
        draw: function() {
            this.collectionSection.visible = !1;
            this.collectionSection.introTextSection.visible = !1;
            this.itemSection.visible = !1;
            b.isAuthenticated() ? (this.header.sync.visible = !0, this.firstTimeUser.visible = !1, this.firstTimeUser.signInFooter.visible = !1, this.firstTimeUser.createButtonSection.visible = !0, nokia.mh5.dom.removeClass(this.firstTimeUser.introImageSection.root, "mh5_anonymous"), this.fetchCollectionList(), this.fetchUngrouped()) : (this.header.sync.visible = !1, this.firstTimeUser.introTextSection.root.innerHTML = a("collections.CollectionListPage.ftu.intro.signedOut"), this.firstTimeUser.visible = !0, this.firstTimeUser.signInFooter.visible = !0, this.firstTimeUser.createButtonSection.visible = !1, nokia.mh5.dom.addClass(this.firstTimeUser.introImageSection.root, "mh5_anonymous"))
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.apply(this, arguments);
            a ? (this.draw(), nokia.mh5.event.add(nokia.mh5.win, "sso_signin", this.checkLazy), nokia.mh5.event.add(nokia.mh5.components.collections.relations, "synchronized", this.draw)) : (nokia.mh5.event.remove(nokia.mh5.win, "sso_signin", this.checkLazy), nokia.mh5.event.remove(nokia.mh5.components.collections.relations, "synchronized", this.draw))
        },
        checkLazy: function() {
            if (this.model.lazy) {
                var a = this.model.lazy;
                this.model.lazy = null;
                nokia.mh5.app.controller.updateHistoryEntry();
                nokia.mh5.app.controller.switchTo("favouriteManage", {
                    place: a
                })
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.ui.Confirm");
nokia.mh5.ui.Confirm = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a, b = nokia.mh5.win,
        c = nokia.mh5.doc,
        e = nokia.mh5.i18n,
        i = function() {
            this.update()
        },
        h = function(a) {
            a.preventDefault()
        };
    return {
        cssClass: "mh5_Confirm mh5_modal mh5_modalBg",
        disableUpdatePosition: !0,
        allowScrolling: !0,
        message: e("confirm.message"),
        confirm: e("ok"),
        cancel: e("cancel"),
        onConfirm: null,
        onCancel: null,
        content: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_ConfirmWrapper",
            children: ["message", "buttonContainer"],
            message: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_ConfirmMessage"
            },
            buttonContainer: {
                control: nokia.mh5.ui.Container,
                cssClass: "mh5_Confirm_Buttons",
                children: ["cancel", "confirm"],
                cancel: {
                    control: nokia.mh5.ui.Button,
                    onClick: function() {
                        var b = this.getRootOwnerByClass(a);
                        if (b.onCancel) b.onCancel(b);
                        g._closeDialog.call(b)
                    }
                },
                confirm: {
                    control: nokia.mh5.ui.Button,
                    onClick: function() {
                        var b = this.getRootOwnerByClass(a);
                        if (b.onConfirm) b.onConfirm(b);
                        g._closeDialog.call(this.getRootOwnerByClass(a))
                    }
                }
            }
        },
        cancelDidChange: i,
        confirmDidChange: i,
        messageDidChange: i,
        update: function() {
            this.content.message.root.innerHTML = this.message;
            this.content.buttonContainer.cancel.text = this.cancel;
            this.content.buttonContainer.confirm.text = this.confirm
        },
        constructor: a = function(a, b) {
            g.constructor.call(this, a, b)
        },
        visibleDidChange: function(a) {
            if (a) this.root.style.top = (void 0 !== b.pageYOffset ? b.pageYOffset : (c.documentElement || c.body.parentNode || c.body).scrollTop) + "px";
            this._scrollEnabler(a);
            g.visibleDidChange.apply(this, arguments)
        },
        _scrollEnabler: function(a) {
            nokia.mh5.dom[a ? "addClass" : "removeClass"](c.body, "mh5_overflow_hidden");
            nokia.mh5.event[a ? "add" : "remove"](c.body, "down", h)
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.collections.ui.ManageBar");
(function() {
    var g = nokia.mh5.ui.Control,
        a = nokia.mh5.ui.Container,
        b = nokia.mh5.i18n,
        c = nokia.mh5.ui.Button;
    nokia.mh5.maps.collections.ui.ManageBar = new nokia.mh5.Class(a, function() {
        return {
            rootHtmlElementName: "header",
            cssClass: "mh5_header mh5_standardBackgroundColorDark",
            layout: {
                type: nokia.mh5.ui.ColumnLayout,
                align: "stretch"
            },
            control: a,
            children: ["cancel", "separator", "name", "done"],
            cancel: {
                control: c,
                text: b("cancel"),
                visible: !0,
                onClick: function() {
                    this.disabled = !0;
                    nokia.mh5.event.fire(this.parent.parent, "cancel")
                }
            },
            separator: {
                control: g,
                cssClass: "mh5_collections_title_separator"
            },
            name: {
                control: g,
                cssClass: "mh5_collections_title"
            },
            done: {
                control: c,
                text: b("done"),
                visible: !0,
                onClick: function() {
                    this.disabled = !0;
                    nokia.mh5.event.fire(this.parent.parent, "done")
                }
            },
            titleDidChange: function(a) {
                this.name.root.innerHTML = a || ""
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.maps.collections.ManageCollection");
nokia.mh5.maps.collections.ManageCollection = new nokia.mh5.Class(nokia.mh5.ui.Page, function(g) {
    var a = nokia.mh5.components.collections,
        b = nokia.mh5.components.favourites,
        c = nokia.mh5.i18n,
        e = nokia.mh5.event,
        i = nokia.mh5.ui.Button,
        h = nokia.mh5.ui.Container,
        d = nokia.mh5.ui.RowLayout;
    return {
        control: h,
        cssClass: "mh5_Page mh5_CollectionPage",
        layout: {
            type: d
        },
        children: "titleBar,details,otherFavouriteItemsSeparator,otherFavouriteItemsList,ungroupedSeparator,favouriteItemsList,emptyList,removeAction".split(","),
        titleBar: {
            control: nokia.mh5.maps.collections.ui.ManageBar
        },
        details: {
            children: ["name", "description", "actions"],
            control: h,
            cssClass: "mh5_collectionCreateForm",
            layout: {
                type: d
            },
            name: {
                control: nokia.mh5.ui.TextInput,
                cssClass: "mh5_TextInput mh5_CollectionTextInput",
                placeholder: c("collections.CreateCollection.collectionName.placeholder"),
                valueDidChange: function(a) {
                    this.constructor.prototype.valueDidChange.apply(this, arguments);
                    this.parent.parent.titleBar.done.disabled = 0 === a.trim().length
                }
            },
            description: {
                control: nokia.mh5.ui.TextArea,
                id: "personalizeInput",
                placeholder: c("collections.CreateCollection.personalize.placeholder")
            },
            actions: {
                control: h,
                cssClass: "mh5_collectionActions",
                layout: {
                    type: nokia.mh5.ui.ColumnLayout
                },
                children: ["addFavourites", "separator"],
                addFavourites: {
                    visible: !1,
                    control: i,
                    text: c("collections.CollectionEdit.addItems"),
                    iconClass: "mh5_ButtonIcon mh5_addMoreIcon",
                    onClick: function() {
                        e.fire(this.parent.parent.parent, "add")
                    }
                },
                separator: {
                    control: nokia.mh5.ui.Control,
                    cssClass: "mh5_collections_ButtonSeparator"
                }
            }
        },
        ungroupedSeparator: {
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_CollectionListSeparator"
        },
        favouriteItemsList: {
            control: nokia.mh5.maps.collections.ui.FavouriteList,
            checkbox: !0
        },
        otherFavouriteItemsSeparator: {
            visible: !1,
            control: nokia.mh5.ui.Control,
            cssClass: "mh5_CollectionListSeparator",
            innerHTML: c("collections.CollectionEdit.allCollectedItems")
        },
        otherFavouriteItemsList: {
            visible: !1,
            control: nokia.mh5.maps.collections.ui.FavouriteList,
            checkbox: !0
        },
        emptyList: {
            visible: !1,
            control: h,
            cssClass: "mh5_ListItemContainer",
            children: ["ungroupedSeparator", "introText"],
            layout: {
                type: d
            },
            ungroupedSeparator: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_CollectionListSeparator",
                innerHTML: c("collections.CollectionEdit.noCollectedItems")
            },
            introText: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_CollectionsFTUIntro",
                innerHTML: c("collections.CollectionEdit.noCollectedItems.intro")
            }
        },
        removeAction: {
            control: h,
            cssClass: "mh5_collectionActions mh5_collectionActionsPadding",
            layout: {
                type: nokia.mh5.ui.ColumnLayout
            },
            children: ["button", "separator"],
            separator: {
                control: nokia.mh5.ui.Control,
                cssClass: "mh5_collections_ButtonSeparator"
            },
            button: {
                visible: !1,
                control: i,
                text: c("collections.common.button.delete"),
                iconClass: "mh5_ButtonIcon mh5_deleteCollectionIcon",
                onClick: function(a) {
                    a.preventDefault();
                    this.disabled = !0;
                    setTimeout(function() {
                        this.parent.parent.removeCollection()
                    }.bind(this), 250)
                }
            }
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.apply(this, arguments);
            a ? (this.isEditMode() ? this.modeEdit() : this.modeCreate(), this.otherFavouriteItemsSeparator.visible = this.otherFavouriteItemsList.visible = !1, this.titleBar.cancel.disabled = !1, this.titleBar.done.disabled = 0 === this.details.name.value.trim().length, this.removeAction.button.disabled = !1, this.details.actions.addFavourites.disabled = !1) : (e.remove(this, "done", this.saveCollection), e.remove(this, "done", this.applyAddMoreFavourites), e.remove(this, "done", this.createCollection), e.remove(this, "cancel", this.cancel), e.remove(this, "add", this.showAddMoreFavourites))
        },
        isEditMode: function() {
            return this.model && "object" === nokia.mh5.type(this.model.collection)
        },
        modeEdit: function() {
            var a = this.model;
            this.titleBar.title = c("collections.details.manage");
            this.ungroupedSeparator.root.innerHTML = c("collections.CollectionEdit.itemsTitle");
            this.id = a.collection.id;
            this.details.name.value = a.collection.name;
            this.details.description.value = a.collection.description;
            this.favouriteItemsList.items = nokia.mh5.components.collections.getFromCollection(a.collection.id);
            this.checkAddMore();
            nokia.mh5.each(this.favouriteItemsList.renderedItems, function(a) {
                a.selected = !0
            });
            e.add(this, "add", this.showAddMoreFavourites);
            e.add(this, "done", this.saveCollection);
            e.add(this, "cancel", this.cancel)
        },
        modeCreate: function(a) {
            a = this.model;
            this.titleBar.title = c("collections.details.create");
            this.ungroupedSeparator.root.innerHTML = c("collections.CollectionEdit.selectItems");
            this.id = null;
            this.details.name.value = "";
            this.details.description.value = "";
            this.favouriteItemsList.items = b.get();
            if (a && "array" === nokia.mh5.type(a.places)) {
                var d = this.favouriteItemsList;
                nokia.mh5.each(a.places, function(a) {
                    if (!b.get(a)) d.items = [a].concat(d.items)
                });
                nokia.mh5.each(a.places, function(a) {
                    var c = b.get(a),
                        e = "id",
                        g = d.items;
                    c || (c = a, e = "placeId");
                    for (var h = 0, i = g.length; h < i; h++) if (a = g[h], a[e] === c[e]) {
                        g.unshift(g.splice(h, 1)[0]);
                        d.items = g;
                        d.renderedItems[0].selected = !0;
                        break
                    }
                })
            }
            this.checkAddMore();
            e.add(this, "cancel", this.cancel);
            e.add(this, "done", this.createCollection)
        },
        checkAddMore: function() {
            this.emptyList.visible = !this.favouriteItemsList.items.length;
            this.emptyList.introText.visible = !a.get().length;
            this.ungroupedSeparator.visible = !! this.favouriteItemsList.items.length;
            this.details.actions.addFavourites.visible = this.favouriteItemsList.items.length < nokia.mh5.components.favourites.get().length;
            this.removeAction.button.visible = this.isEditMode();
            this.titleBar.title = c("collections.details." + (this.isEditMode() ? "manage" : "create"))
        },
        showAddMoreFavourites: function() {
            this.titleBar.title = c("collections.CollectionEdit.addItems");
            this.details.visible = !1;
            this.emptyList.visible = !1;
            this.favouriteItemsList.visible = !1;
            this.ungroupedSeparator.visible = !1;
            this.removeAction.button.visible = !1;
            this.otherFavouriteItemsSeparator.visible = this.otherFavouriteItemsList.visible = !0;
            e.remove(this, "done", this.saveCollection);
            e.add(this, "done", this.applyAddMoreFavourites);
            var a = nokia.mh5.components.favourites.get(),
                b = this.favouriteItemsList.renderedItems,
                d = this.otherFavouriteItemsList;
            setTimeout(function() {
                d.items = a.filter(function(a) {
                    for (var c = !1, d = 0, e = b.length; d < e; d++) if (a.id === b[d].id) {
                        c = !0;
                        break
                    }
                    return !c
                })
            }, 0)
        },
        applyAddMoreFavourites: function(a) {
            this.details.visible = !0;
            this.otherFavouriteItemsSeparator.visible = this.otherFavouriteItemsList.visible = !1;
            if (!a || !0 !== a) {
                var b = this.otherFavouriteItemsList.selectedFavourites.concat([]),
                    c = this.favouriteItemsList.selectedFavourites.concat([]),
                    a = nokia.mh5.components.favourites.get().filter(function(a) {
                        return ~b.indexOf(a.id)
                    }),
                    a = this.favouriteItemsList.items.concat(a);
                this.favouriteItemsList.items = a;
                nokia.mh5.each(this.favouriteItemsList.renderedItems, function(a) {
                    if (~c.indexOf(a.id) || ~b.indexOf(a.id)) a.selected = !0
                })
            }
            this.otherFavouriteItemsList.items = [];
            this.favouriteItemsList.visible = !0;
            this.ungroupedSeparator.visible = !0;
            e.remove(this, "done", this.applyAddMoreFavourites);
            e.add(this, "done", this.saveCollection);
            this.titleBar.done.disabled = this.titleBar.cancel.disabled = !1;
            this.checkAddMore()
        },
        validateData: function() {
            var a = this.details,
                a = {
                    name: a.name.value.trim(),
                    description: a.description.value ? a.description.value.trim() : null
                };
            if (!a.name) return !1;
            if (this.id) a.id = this.id;
            return a
        },
        saveCollection: function(c) {
            var d = this.validateData(),
                e = this.favouriteItemsList.selectedFavourites,
                g = [];
            if (d) {
                for (var h = 0, i = e.length; h < i; h++) if ("string" !== nokia.mh5.type(e[h]) && !b.get(e[h])) return b.add(e[h], this.saveCollection.bind(this, c)), !1;
                h = 0;
                for (i = e.length; h < i; h++) {
                    var o = e[h],
                        o = "string" === nokia.mh5.type(o) ? o : b.get(o).id;
                    g.push(o)
                }
                a.update(d, function(b) {
                    "function" !== typeof c && (c = function() {
                        nokia.mh5.app.controller.back()
                    });
                    a.updateCollection(b.id, g, function() {
                        a.synchronize(c)
                    })
                })
            }
        },
        createCollection: function() {
            var b = this.validateData(),
                c = this.model;
            b && a.createCollection(b, [], function(a) {
                this.id = a.id;
                this.saveCollection(function() {
                    c && c.places && c.places.length ? (nokia.mh5.utils.isPlace(c.places[0]), nokia.mh5.history.go(-2)) : nokia.mh5.app.controller.back()
                })
            }.bind(this))
        },
        removeCollection: function() {
            var b = this;
            new nokia.mh5.ui.Confirm({
                message: c("collections.common.confirmation.delete"),
                confirm: c("delete"),
                cancel: c("cancel"),
                onConfirm: function() {
                    b.titleBar.done.disabled = b.removeAction.button.disabled = b.details.actions.addFavourites.disabled = !0;
                    var c = b.id,
                        d = a.getFromCollection(c);
                    nokia.mh5.each(d, function(b) {
                        a.removeFromCollection(c, b.id)
                    });
                    a.remove({
                        id: b.id
                    }, function() {
                        a.synchronize(function() {
                            nokia.mh5.app.controller.switchTo("collectionList", {
                                modeMap: !1
                            })
                        })
                    })
                },
                onCancel: function() {
                    b.removeAction.button.disabled = !1
                }
            })
        },
        cancel: function() {
            this.otherFavouriteItemsList.visible ? this.applyAddMoreFavourites(!0) : nokia.mh5.app.controller.back()
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.collections.Details");
(function() {
    var g = nokia.mh5.ui.Button,
        a = nokia.mh5.i18n;
    nokia.mh5.maps.collections.Details = new nokia.mh5.Class(nokia.mh5.maps.collections.Page, function(b) {
        var c = nokia.mh5.ui.Container,
            e = nokia.mh5.ui.Control,
            i = nokia.mh5.components.collections;
        return {
            children: ["header", "collectionDetails", "map", "traffic"],
            collectionDetails: {
                children: ["collectionListItem", "itemsList"],
                control: c,
                cssClass: "mh5_CollectionDetails",
                collectionListItem: {
                    children: ["name", "description", "collectionCount", "collectionManage"],
                    control: c,
                    cssClass: "mh5_CollectionListItem",
                    layout: {
                        type: nokia.mh5.ui.RowLayout
                    },
                    name: {
                        control: e,
                        cssClass: "mh5_CollectionName"
                    },
                    description: {
                        control: e,
                        cssClass: "mh5_CollectionDescription mh5_CollectionContentPadding"
                    },
                    collectionCount: {
                        control: e,
                        cssClass: "mh5_CollectionItemCount mh5_standardColorDark"
                    },
                    collectionManage: {
                        control: c,
                        cssClass: "mh5_collectionActions",
                        layout: {
                            type: nokia.mh5.ui.ColumnLayout
                        },
                        children: ["editCollection", "separator"],
                        editCollection: {
                            control: g,
                            text: a("collections.details.manage"),
                            iconClass: "mh5_ButtonIcon mh5_editCollectionIcon",
                            onClick: function() {
                                nokia.mh5.app.controller.switchTo("collectionManage", this.parent.parent.parent.parent.model)
                            }
                        },
                        separator: {
                            control: e,
                            cssClass: "mh5_collections_ButtonSeparator"
                        }
                    }
                },
                itemsList: {
                    control: nokia.mh5.maps.collections.ui.FavouriteList,
                    edit: !0,
                    listeners: {
                        view: function(a) {
                            this.parent.parent.switchToPlaceDetails(a.data)
                        },
                        edit: function(a) {
                            nokia.mh5.app.controller.switchTo("favouriteManage", {
                                place: a.data
                            })
                        }
                    }
                },
                update: function(a) {
                    var b = this.collectionListItem;
                    b.name.root.innerHTML = a.name;
                    b.description.root.innerHTML = a.description || "";
                    this.itemsList.items = this.parent.getFavourites();
                    var c = this.itemsList.items.length;
                    this.updateCount(c);
                    nokia.mh5.dom[a.description ? "removeClass" : "addClass"](b.root, "mh5_NoDescription");
                    this.parent.header.switchMode.visible = !! c
                },
                updateCount: function(a) {
                    var b = this.collectionListItem.collectionCount.root;
                    b.innerHTML = a;
                    b.className = "mh5_CollectionItemCount mh5_standardColorDark mh5_CollectionJar" + nokia.mh5.components.collections.getJarLevel(a)
                }
            },
            build: function() {
                this.header.back.visible = this.header.ignorePlatformBackSettings = !0;
                this.traffic.map = this.map;
                b.build.apply(this, arguments)
            },
            setModel: function(a) {
                b.setModel.apply(this, arguments);
                this.collectionDetails.update(this.model.collection)
            },
            visibleDidChange: function(c) {
                b.visibleDidChange.apply(this, arguments);
                this.header.title = a("collections.details.title");
                c ? (this.map.geometry = {
                    top: this.header.root.offsetHeight + this.collectionDetails.collectionListItem.name.root.offsetHeight,
                    left: 0
                }, nokia.mh5.event.add(nokia.mh5.win, ["sso_signin", "sso_signout"], this.gotoOverview.bind(this))) : nokia.mh5.event.remove(nokia.mh5.win, ["sso_signin", "sso_signout"], this.gotoOverview.bind(this))
            },
            gotoOverview: function() {
                nokia.mh5.app.controller.switchTo("collectionList", {
                    modeMap: !1
                })
            },
            getFavourites: function() {
                return i.getFromCollection(this.model.collection.id)
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.maps.collections.ManageFavourite");
(function() {
    var g = nokia.mh5.components.favourites;
    nokia.mh5.maps.collections.ManageFavourite = new nokia.mh5.Class(nokia.mh5.ui.Page, function(a) {
        var b = nokia.mh5.i18n,
            c = nokia.mh5.ui.Container,
            e = nokia.mh5.ui.RowLayout,
            i = nokia.mh5.components.collections,
            h = nokia.mh5.ui.Button;
        return {
            cssClass: "mh5_Page mh5_ManageFavouritePage",
            control: c,
            layout: {
                type: e
            },
            children: ["titleBar", "placeSummary", "listCollectionSection", "removeAction"],
            titleBar: {
                control: nokia.mh5.maps.collections.ui.ManageBar
            },
            placeSummary: {
                control: nokia.mh5.components.PlaceSummary
            },
            listCollectionSection: {
                control: c,
                children: ["collectionSeparator", "collectionListAddition", "collectionList"],
                layout: {
                    type: e
                },
                collectionSeparator: {
                    control: nokia.mh5.ui.Control,
                    cssClass: "mh5_CollectionListSeparator",
                    innerHTML: b("collections.favourite.edit.collectionsListTitle")
                },
                collectionListAddition: {
                    control: c,
                    cssClass: "mh5_CollectionListItem mh5_collections_whiteButton",
                    children: ["collectionCreateButton"],
                    collectionCreateButton: {
                        control: nokia.mh5.ui.Button,
                        iconClass: "mh5_createIcon",
                        text: b("collections.common.button.create"),
                        onClick: function() {
                            nokia.mh5.app.controller.switchTo("collectionManage", {
                                places: [this.parent.parent.parent.model.place]
                            })
                        }
                    }
                },
                collectionList: {
                    visible: !0,
                    checkbox: !0,
                    control: nokia.mh5.ui.List,
                    cssClass: "mh5_CollectionListItemContainer",
                    itemClass: nokia.mh5.maps.collections.ui.CollectionListItem,
                    onClick: function(a) {
                        a = this.renderedItems[a];
                        a.selected = !a.selected
                    }
                }
            },
            removeAction: {
                control: c,
                cssClass: "mh5_collectionActions mh5_collectionActionsPadding",
                layout: {
                    type: nokia.mh5.ui.ColumnLayout
                },
                children: ["button", "separator"],
                separator: {
                    control: nokia.mh5.ui.Control,
                    cssClass: "mh5_collections_ButtonSeparator"
                },
                button: {
                    control: h,
                    cssClass: "mh5_Button",
                    text: b("collections.favourite.edit.delete"),
                    iconClass: "mh5_ButtonIcon mh5_deleteCollectionIcon",
                    onClick: function(a) {
                        a.preventDefault();
                        this.disabled = !0;
                        setTimeout(function() {
                            this.parent.parent.removeFavourite()
                        }.bind(this), 250)
                    }
                }
            },
            visibleDidChange: function(c) {
                a.visibleDidChange.apply(this, arguments);
                if (c) {
                    var e = i.get() || [],
                        f = this.model.place,
                        h = g.get(f);
                    f.categoryTitle = f.categoryTitle || f.categoryGroup;
                    this.placeSummary.update(f);
                    f = this.listCollectionSection.collectionList;
                    f.items = e;
                    if (h) {
                        var m = i.relations.getCollections(h.id);
                        nokia.mh5.each(f.renderedItems, function(a) {
                            a.selected = !! ~m.indexOf(a.id)
                        })
                    }
                    h ? (this.titleBar.title = b("collections.favourite.edit.manage"), this.removeAction.visible = !0, this.removeAction.button.disabled = !1) : (this.titleBar.title = b("collections.favourite.edit.collect"), this.removeAction.visible = !1);
                    this.titleBar.done.disabled = this.titleBar.cancel.disabled = !1;
                    this._visibleDidChangeHandle = this._visibleDidChangeHandle || this.visibleDidChange.bind(this, !0);
                    nokia.mh5.event.add(i, "synchronized", this._visibleDidChangeHandle);
                    nokia.mh5.event.add(this, "done", this.saveFavourite);
                    nokia.mh5.event.add(this, "cancel", this.cancel)
                } else this._visibleDidChangeHandle && nokia.mh5.event.remove(i, "synchronized", this._visibleDidChangeHandle), nokia.mh5.event.remove(this, "done", this.saveFavourite), nokia.mh5.event.remove(this, "cancel", this.cancel)
            },
            saveFavourite: function(a) {
                var b = this.listCollectionSection.collectionList.renderedItems,
                    c = this.model.place,
                    e = g.get(c);
                if (!e && !0 !== a) g.add(c, this.saveFavourite.bind(this, !0)), b = nokia.mh5.maps.analytics, b.log({
                    gn: "manage place",
                    v32: "collect place",
                    v44: b.getPlaceId(c)
                });
                else {
                    var h = function() {
                            !0 === a ? nokia.mh5.app.controller.switchTo("search") : nokia.mh5.app.controller.back()
                        };
                    if (e) {
                        var n = [];
                        nokia.mh5.each(b, function(a) {
                            a.selected && n.push(a.id)
                        });
                        i.updateFavourite(e.id, n, function() {
                            i.synchronize(h)
                        })
                    } else i.synchronize(h)
                }
            },
            removeFavourite: function() {
                var a = this,
                    c = g.get(this.model.place),
                    c = i.relations.getCollections(c.id);
                new nokia.mh5.ui.Confirm({
                    message: b("collections.common.confirmation.favourite.delete" + (1 < c.length ? ".collections" : "")),
                    confirm: b("delete"),
                    cancel: b("cancel"),
                    onConfirm: function() {
                        a.titleBar.done.disabled = a.removeAction.button.disabled = !0;
                        var b = a.model.place;
                        i.relations.removeRelation({
                            data: {
                                objectType: "favoritePlace",
                                id: b.id
                            }
                        });
                        i.relations.synchronize(function() {
                            g.remove(b, function() {
                                g.synchronize(function() {
                                    nokia.mh5.app.controller.back()
                                })
                            })
                        });
                        var c = nokia.mh5.maps.analytics;
                        c.log({
                            gn: "manage place",
                            v32: "remove place",
                            v44: c.getPlaceId(a.model.place)
                        })
                    },
                    onCancel: function() {
                        a.removeAction.button.disabled = !1
                    }
                })
            },
            cancel: function() {
                nokia.mh5.app.controller.back()
            }
        }
    })
})();
nokia.mh5.provide("nokia.mh5.maps.NavigationDisclaimerDialog");
nokia.mh5.maps.NavigationDisclaimerDialog = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a = nokia.mh5,
        b = a.i18n,
        c, e = a.ui.Container,
        i = a.ui.Control,
        h = a.ui.Button,
        d = a.event,
        j = a.platform,
        f = a.dom.query(".mh5_audio")[0],
        k, m = a.platform.firefox ? ".ogg" : ".mp3";
    return {
        cssClass: "mh5_NavigationDisclaimerDialog mh5_modal mh5_modalBg",
        control: e,
        allowScrolling: !0,
        children: ["contents"],
        contents: {
            control: e,
            layout: {
                type: a.ui.RowLayout
            },
            children: ["header", "content", "buttonContainer"],
            header: {
                control: e,
                children: ["headline"],
                cssClass: "mh5_dialogHeader",
                headline: {
                    control: e,
                    rootHtmlElementName: "h1",
                    cssClass: "mh5_title",
                    innerHTML: b("maps.Nav.disclaimerTitle") + " <label>(" + b("beta") + ")</label>"
                }
            },
            content: {
                control: e,
                cssClass: "mh5_content",
                children: ["instructions", "successText", "spinner"],
                instructions: {
                    control: i,
                    cssClass: "mh5_instructions mh5_primaryColorDark",
                    innerHTML: "<ul><li>" + b("maps.Nav.disclaimerPoint1") + "</li><li>" + b("maps.Nav.disclaimerPoint2") + "</li><li>" + b("maps.Nav.disclaimerPoint3") + "</li><li>" + b("maps.Nav.disclaimerPoint4") + "</li></ul>"
                },
                successText: {
                    control: i,
                    visible: !1,
                    cssClass: "mh5_actionText",
                    innerHTML: b("maps.Nav.success")
                },
                spinner: {
                    control: i,
                    visible: !1,
                    cssClass: "mh5_spinner_big_bright"
                }
            },
            buttonContainer: {
                control: e,
                cssClass: "mh5_screenContainer",
                children: ["buttons"],
                buttons: {
                    control: e,
                    cssClass: "mh5_buttonContainer",
                    children: ["cancelButton", "downloadButton", "startButton"],
                    cancelButton: {
                        control: h,
                        cssClass: "mh5_Button mh5_textButton",
                        text: b("cancel"),
                        onClick: function() {
                            c.visible = !1
                        }
                    },
                    downloadButton: {
                        control: h,
                        cssClass: "mh5_Button mh5_textButton",
                        text: b("maps.Nav.load")
                    },
                    startButton: {
                        control: h,
                        cssClass: "mh5_Button mh5_textButton",
                        visible: !1,
                        text: b("maps.Nav.start"),
                        onClick: function() {
                            c._startJourney()
                        }
                    }
                }
            }
        },
        disableUpdatePosition: !0,
        build: function() {
            c = this;
            d.add(c.root, "touchmove", function(a) {
                a.stopPropagation();
                a.preventDefault();
                return !1
            });
            f && f.readyState === HTMLMediaElement.HAVE_ENOUGH_DATA && ~f.currentSrc.indexOf(a.components.settings.get("unitSystem") + "_audio" + m) ? (c._readyToStart(), c.contents.content.successText.visible = !1) : d.add(c.contents.buttonContainer.buttons.downloadButton.root, "down", c._downloadAudio);
            if (c.enOnly) {
                var e = b("maps.Nav.disclaimerTitle") + " <label>(" + b("beta") + " - " + b("maps.Nav.englishOnlyAudio") + ")</label>";
                c.contents.header.headline.root.innerHTML = e
            }
            g.build.call(this)
        },
        _downloadAudio: function() {
            var b = c.contents.content,
                e = c.contents.buttonContainer.buttons.downloadButton,
                g = a.components.settings.get("unitSystem"),
                h = f && !~f.currentSrc.indexOf(g + "_audio" + m),
                i = 5,
                v;
            if (!f || h) h && f.parentNode.removeChild(f), f = a.doc.createElement("audio"), f.src = j.webview ? "http://m.maps.nokia.com/fw/audio/" + g + "_audio" + m : a.assetsPath + "audio/" + g + "_audio" + m, a.dom.addClass(f, "mh5_audio"), a.doc.body.appendChild(f);
            d.add(f, "canplaythrough", function t() {
                d.remove(f, "canplaythrough", t);
                a.win.clearTimeout(k);
                if (j.firefox) f.pause(), f.volume = v;
                c._readyToStart()
            });
            d.add(f, "error", function q() {
                if (i--) j.firefox ? f.play() : f.load();
                else if (d.remove(f, "error", q), i = 5, c._showError(), j.firefox) f.volume = v
            });
            k = a.win.setTimeout(c._showError, 15E3);
            b.spinner.visible = e.disabled = !0;
            if (f.readyState === HTMLMediaElement.HAVE_ENOUGH_DATA) c._readyToStart();
            else if (j.ios && f.readyState === HTMLMediaElement.HAVE_NOTHING) f.load();
            else if (j.firefox) v = f.volume, f.volume = 1.0E-8, f.play()
        },
        _showError: function() {
            var d = c.contents.content,
                e = c.contents.buttonContainer.buttons.downloadButton;
            d.spinner.visible = e.disabled = !1;
            e.text = b("retry");
            d.successText.root.innerHTML = b("maps.Nav.tryAgain");
            d.successText.visible = !0;
            a.win.clearTimeout(k)
        },
        _readyToStart: function() {
            var a = c.contents.content,
                b = c.contents.buttonContainer.buttons;
            a.spinner.visible = b.downloadButton.visible = !1;
            a.successText.visible = b.startButton.visible = !0
        },
        _startJourney: function() {
            c._closeDialog();
            if (c.onFinish) c.onFinish()
        }
    }
});
nokia.mh5.provide("nokia.mh5.app.commonLayout");
(function(g) {
    var a = Math.PI,
        b = a / 2,
        c = 3 * b,
        e, i = nokia.mh5.maps.analytics,
        h = function(a) {
            var b, c;
            j(a);
            if (a == nokia.mh5.app.controller.current.page.details && a != a.parent._shadowDetails) b = a.parent.map, (c = b.getPois(a.place, !0)) && b.moveTo(a.getMapCenterToShowPoiInGap(c, -c.image.height / 2))
        },
        d = function(a) {
            var b = nokia.mh5.maps.analytics;
            b.log({
                gn: "infobubble:place details",
                c44: b.getPlaceId(a),
                v44: "~c44",
                c19: b.getContext(a),
                v19: "~c19",
                c32: "infobubble click",
                v32: "~c32",
                ev: "prodView",
                v34: a.ownerContent ? "prime" : "not prime"
            })
        },
        j = function(a) {
            "_resizeTimeout" in a && (g.clearTimeout(a._resizeTimeout), delete a._resizeTimeout)
        },
        f = function(a) {
            return this == "routeInfo" in a.data
        },
        k = nokia.mh5.dom,
        m = nokia.mh5.event,
        n = nokia.mh5.geolocation,
        l = nokia.mh5.i18n,
        o = nokia.mh5.platform,
        u = nokia.mh5.utils,
        w = nokia.mh5.components.settings,
        v = nokia.mh5.math,
        y = function(a, b, c, d, e) {
            var c = d.geoToPoint(d.center),
                f = d.retina ? d.size.width : d.size.width / 2,
                g = d.retina ? d.size.height : d.size.height / 2,
                a = d.geoToPoint(a);
            return d.pointToGeo({
                x: c.x - ((d.retina ? d.size.width : d.size.width / 2) - (f - (c.x - a.x))),
                y: c.y - ((e.offsetTop + e.offsetHeight / 2) * (d.retina ? 2 : 1) - (g - (c.y - a.y))) + b / 2
            })
        },
        t = l("currentLocation"),
        q = {
            map: function() {
                return this.parent.parent.parent.parent.map
            }
        },
        s = function(d, f, g, h, i) {
            e.beginPath();
            e.moveTo(56 * d, f * (30 + i));
            e.lineTo(d * (36 + i + h), f * (30 + i));
            e.arc(d * (36 + i + h), f * (30 + i + h), h, 0 < f ? c : b, 0 < d ? a : 0, 0 < d * f);
            e.lineTo(d * (36 + i), f * g)
        },
        x = function(d, f, g) {
            var h = g.time,
                i = g.distance,
                k = w.current.unitSystem,
                j = d.size,
                l = d.geoToPoint(f),
                m = d.geoToPoint(d.box[0]),
                f = {
                    summary: g,
                    latitude: f.latitude,
                    longitude: f.longitude,
                    routeInfo: !0,
                    locationX: l.x - m.x < 160 * (d.retina ? 2 : 1) && l.x - m.x < (d.retina ? j.width : j.width / 2) ? 0 : 1,
                    locationY: (d.retina ? 2 * j.height : j.height) - (l.y - m.y) <= 50 * (d.retina ? 2 : 1) ? 1 : 0
                },
                g = nokia.mh5.extend({
                    background: !1,
                    renderOnly: !0,
                    privilegeLevel: 0
                }, d.infoBubbleParams);
            i && h ? h = u.formatDistance(i, k) + ", " + u.formatTime(h) : (h = 600 * Math.ceil(h / 600), h = Math.floor(h / 3600) + "hr " + h / 60 % 60 + "min");
            var l = h,
                h = document.createElement("canvas"),
                n = m = 0,
                o = 0,
                i = Math.round(64 / 12),
                t = Math.round(32 / 12),
                r = Math.round(320 / 12),
                q = 0,
                k = f.locationX,
                j = f.locationY,
                v, x;
            e = h.getContext("2d");
            o += r + 9;
            e.font = "20pt Arial";
            e.textBaseline = "bottom";
            e.fillStyle = "rgb(255,255,255)";
            q = Math.max(q, e.measureText(l || " ").width);
            n += q + 32;
            o = o - 9 + 20;
            h.width = n + 32;
            h.height = o + 28;
            e.save();
            e.translate(k ? 0 : 32, j ? 0 : 28);
            r = t / 2;
            q = i + r;
            v = n - q;
            x = o - q;
            e.fillStyle = "rgba(0,15,26,0.85)";
            e.lineWidth = t;
            e.lineCap = "round";
            e.moveTo(q, r);
            n = [v, r, v, q, i, c, 0, n - r, x, v, x, i, 0, b, q, o - r, q, x, i, b, a, r, q, q, q, i, a, c];
            o = 0;
            for (t = n.length; o < t;) e.lineTo(n[o++], n[o++]), e.arc(n[o++], n[o++], n[o++], n[o++], n[o++]);
            e.fill();
            e.textBaseline = "top";
            e.fillStyle = "#FFFFFF";
            e.font = "20pt Arial";
            e.fillText(l, m + 16, 8);
            e.restore();
            l = k ? -1 : 1;
            m = j ? -1 : 1;
            e.translate(h.width * k, h.height * j);
            s(l, m, h.height, i, -1);
            e.strokeStyle = "rgb(255,255,255)";
            e.stroke();
            s(l, m, h.height, i, 0);
            e.lineTo(0, 0);
            e.closePath();
            e.fillStyle = "rgba(0,15,26,0.85)";
            e.fill();
            g.image = h;
            d.showInfoBubble(f, g)
        },
        r = function(a, b) {
            nokia.mh5.dom.removeClass(b.root, "mh5_hidden");
            var c = document.body.clientHeight - (b.mapoffset || b.filler).root.scrollHeight - b._scroll.y;
            if (document.styleSheets[1]) return document.styleSheets[1].insertRule("." + a + "{-webkit-transform: translateY(" + c + "px);-moz-transform: translateY(" + c + "px);transform: translateY(" + c + "px);}", 0), document.styleSheets[1].cssRules[0]
        },
        J = function(a) {
            document.styleSheets[1] && document.styleSheets[1].deleteRule(Array.prototype.indexOf.call(document.styleSheets[1].cssRules, a))
        },
        F = {
            control: nokia.mh5.components.IncidentDetails,
            visible: !1,
            detailsPoi: null,
            visibleDidChange: function(a, b) {
                var c = this,
                    d = c.parent,
                    e = d.map;
                if (a) e.passive = !0, e.hideInfoBubble(e.infoBubbles.filter(f, !1)), c.detailsPoi = e.createPoi(c.incident.icon, c.incident), c.detailsPoi.privileged = !0, g.setTimeout(function() {
                    var f = "mh5_dynamic_translate_showing_" + +new Date;
                    c._transitionClass = f;
                    c._ruleRef = r(f, c);
                    k.transition({
                        node: c.root,
                        transitionClass: "mh5_transition_DC_in",
                        fromTransformClass: f,
                        toTransformClass: "mh5_transition_middle"
                    }, function() {
                        k.removeClass(c.root, "mh5_transition_DC_in", "mh5_transition_middle");
                        e.moveTo(y(c.detailsPoi, -c.detailsPoi.image.height / 2, c.getRootOwnerByClass(nokia.mh5.ui.Page), e, c.filler.root));
                        g.setTimeout(function() {
                            if (d.incidentDetails.visible) d.detailsClose.visible = !0
                        }, 400)
                    });
                    c.constructor.prototype.visibleDidChange.call(c, a, b)
                }, 0);
                else if (b) {
                    j(c);
                    if (c.detailsPoi) e.removePoi(c.detailsPoi), c.detailsPoi = null;
                    d.detailsClose.visible = !1;
                    g.setTimeout(function() {
                        k.transition({
                            node: c.root,
                            transitionClass: "mh5_transition_DC_out",
                            toTransformClass: c._transitionClass
                        }, function() {
                            J(c._ruleRef);
                            c.constructor.prototype.visibleDidChange.call(c, a, b);
                            k.removeClass(c.root, "mh5_transition_DC_out");
                            if (c === d.incidentDetails) {
                                e.passive = !1;
                                var f = c.parent.model.selection;
                                if (f) {
                                    var f = e.getPois(f, !0),
                                        g = nokia.mh5.extend({
                                            renderOnly: !0,
                                            left: f.data.icon
                                        }, e.infoBubbleParams);
                                    g.content = ["title", "description"];
                                    e.showInfoBubble(f, g)
                                }
                            }
                        })
                    }, 0)
                } else c.constructor.prototype.visibleDidChange.call(c, a, b)
            }
        },
        H = new nokia.mh5.Class(nokia.mh5.ui.Control, function() {
            return {
                rootHtmlElementName: "li",
                cssClass: "noresults"
            }
        });
    nokia.mh5.app.commonLayout = {
        pages: "search,route,share,collectionList,collectionDetails,collectionManage,favouriteManage,navigation".split(","),
        controller: nokia.mh5.app.controller,
        search: {
            children: "header,map,list,traffic,detailsClose,details,incidentDetails,notification".split(","),
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            model: {
                query: "",
                data: [],
                selection: null,
                searchCenter: null,
                reset: function(a) {
                    this.query = a && a.query || "";
                    this.data = [];
                    this.selection = null;
                    this.searchCenter = a && a.searchCenter || null
                }
            },
            adapter: nokia.mh5.adapters.Search,
            unitSystemBinding: "nokia.mh5.components.settings#current.unitSystem",
            onlineStatusBinding: "nokia.mh5.components.settings#current.isOnline",
            header: {
                control: nokia.mh5.ui.Container,
                layout: {
                    type: nokia.mh5.ui.ColumnLayout,
                    align: "stretch"
                },
                rootHtmlElementName: "header",
                cssClass: "mh5_baseBackgroundColor",
                search: {
                    control: nokia.mh5.components.Search,
                    input: {
                        cssClass: "mh5_TextInput mh5_secondaryColorBrightPH mh5_secondaryColorBright",
                        placeholder: l("searchPlaces")
                    },
                    parameters: {
                        map: function() {
                            return this.parent.parent.map
                        }
                    },
                    listeners: {
                        beforesearch: function() {
                            var a = this.parent.parent,
                                b = a.model;
                            a.map.hideInfoBubble();
                            b.reset({
                                searchCenter: a.map.center,
                                query: this.query
                            });
                            a.details.visible = !1;
                            a.incidentDetails.visible = !1;
                            a.showNotification(w.get("isOnline") ? l("searching") + "..." : l("Notification.goOnline"))
                        },
                        success: function(a) {
                            var b = a.data.results,
                                a = a.data.box,
                                c = this.parent.parent;
                            c.resetNotification();
                            0 < b.length ? (c.model.data = b, c.model.selection = b[0], c.map.hideInfoBubble(), c.map.showInfoBubble(c.map.getPois(b[0], !0)), c.map.box = a || b, nokia.mh5.app.controller.updateHistoryEntry(), c.map.save(), nokia.mh5.maps.analytics.log({
                                gn: c.map.visible ? "map:search results" : "list:search results",
                                c36: c.model.query,
                                c37: c.model.data.length,
                                v39: "+1",
                                c32: "search performed",
                                ev: "event14"
                            })) : c.map.visible && c.showNotification(l("Notification.noResultFound"), nokia.mh5.ui.Notification.TIMEOUT_DEFAULT)
                        },
                        error: function() {
                            var a = this.parent.parent;
                            a.resetNotification();
                            a.showNotification(l("Notification.searchProblem"))
                        },
                        clear: function() {
                            var a = this.parent.parent,
                                b = a.details;
                            a.model.reset();
                            a.map.hideInfoBubble();
                            a.resetNotification();
                            b.visible = !1
                        }
                    }
                }
            },
            detailsClose: {
                control: nokia.mh5.ui.Control,
                visible: !1,
                cssClass: "mh5_showDetails"
            },
            map: {
                control: nokia.mh5.components.Map,
                infoBubble: {
                    content: ["title"],
                    listeners: {
                        click: function() {
                            var a = this.parent.parent,
                                b = nokia.mh5.app.controller;
                            d(this.data);
                            a.model.mapMode = !0;
                            b.updateHistoryEntry();
                            (this.data.incident ? a.incidentDetails : a.details).visible = !0;
                            b.pushHistoryEntry("search", a.getNavigationState(), a.getHash())
                        }
                    }
                },
                listeners: {
                    poiclick: function(a) {
                        a = a.data[0];
                        a.infoBubble || i.log({
                            gn: "map:infobubble",
                            c44: i.getPlaceId(a.data),
                            v44: "~c44",
                            c19: i.getContext(a.data),
                            v19: "~c19",
                            c32: "poi click",
                            ev: "event47",
                            v32: "~c32"
                        });
                        this.parent.model.selection = a.data;
                        nokia.mh5.app.controller.updateHistoryEntry()
                    },
                    maplongpress: function(a) {
                        this.parent.model.selection = a.data;
                        nokia.mh5.app.controller.updateHistoryEntry()
                    },
                    mapclick: function() {
                        var a = this.parent.model;
                        if (a.selection) a.selection = null, nokia.mh5.app.controller.updateHistoryEntry()
                    }
                }
            },
            traffic: {
                control: nokia.mh5.components.Traffic,
                visible: !1
            },
            list: {
                control: nokia.mh5.ui.List,
                visible: !1,
                cssClass: "mh5_List mh5_searchResults"
            },
            openDetailsTracking: function(a) {
                var b = nokia.mh5.maps.analytics;
                b.log({
                    gn: "list:place details",
                    c44: b.getPlaceId(a),
                    v44: "~c44",
                    c19: b.getContext(a),
                    v19: "~c19",
                    c32: "list item click",
                    v32: "~c32",
                    ev: "prodView",
                    v34: a.ownerContent ? "prime" : "not prime"
                })
            },
            details: {
                control: nokia.mh5.components.PlaceDetails,
                visible: !1,
                customContent: [{
                    name: "mapoffset",
                    cssClass: "mh5_PlaceDetailsMapOffset",
                    before: "summary",
                    onClick: function() {
                        this.parent.visible = !1
                    }
                }],
                resize: function() {
                    this.constructor.prototype.resize.apply(this, arguments);
                    if (this.visible) j(this), this._resizeTimeout = g.setTimeout(h, 1E3, this)
                },
                listeners: {
                    dial: function(a) {
                        i.log({
                            gn: "place:contact",
                            c44: i.getPlaceId(a.data),
                            v44: "~c44",
                            c19: i.getContext(a.data),
                            v19: "~c19",
                            c32: "place contact click",
                            ev: "event21"
                        });
                        nokia.mh5.platform.firefox_mobile && a.data.phone && new MozActivity({
                            name: "dial",
                            data: {
                                type: "webtelephony/number",
                                number: a.data.phone
                            }
                        })
                    },
                    nearby: function(a) {
                        var b = a.data.place,
                            c = a.data.index,
                            d = this.getRootOwnerByClass(nokia.mh5.ui.Page),
                            e = d.map,
                            f = d.model,
                            c = this.recommendations.list.renderedItems[c];
                        i.log({
                            gn: "place:place",
                            c44: i.getPlaceId(b),
                            v44: "~c44",
                            c19: i.getContext(b),
                            v19: "~c19",
                            c32: "open nearby place",
                            v32: "~c32"
                        });
                        j(this);
                        if (d.transitionBetweenDetails) {
                            if (!c.distance) c.distance = 1, c.update();
                            k.query(".mh5_ListItem_distance", c.root)[0].innerHTML = '<span class="mh5_spinner"></span>'
                        }
                        a.preventDefault();
                        f.reset();
                        0 < e.getPois().length && e.removePoi(d.map.getPois());
                        f.data = [b];
                        f.selection = b;
                        nokia.mh5.app.controller.pushHistoryEntry("search", d.getNavigationState(), d.getHash())
                    },
                    share: function(a) {
                        i.log({
                            gn: "place:share",
                            c44: i.getPlaceId(a.data),
                            v44: "~c44",
                            c19: i.getContext(a.data),
                            v19: "~c19",
                            c32: "place share click",
                            v32: "~c32",
                            ev: "event22"
                        });
                        nokia.mh5.app.controller.updateHistoryEntry();
                        nokia.mh5.app.controller.share({
                            data: a.data,
                            metadata: {}
                        })
                    },
                    route: function(a) {
                        i.log({
                            gn: "place:directions",
                            c44: i.getPlaceId(a.data),
                            v44: "~c44",
                            c19: i.getContext(a.data),
                            v19: "~c19",
                            c32: "place directions click",
                            v32: "~c32",
                            ev: "event24"
                        });
                        nokia.mh5.app.controller.route({
                            from: n.available && {
                                name: t,
                                latitude: n.latitude,
                                longitude: n.longitude
                            },
                            to: a.data
                        })
                    },
                    website: function(a) {
                        i.log({
                            gn: "place:website",
                            c44: i.getPlaceId(a.data),
                            v44: "~c44",
                            c19: i.getContext(a.data),
                            v19: "~c19",
                            c32: "place website click",
                            v32: "~c32",
                            ev: "event25"
                        })
                    },
                    collect: function(a) {
                        i.log({
                            gn: "place:manage place",
                            c32: "manage place",
                            v32: "~c32",
                            c44: i.getPlaceId(a.data),
                            v44: "~c44"
                        })
                    },
                    error: function(a) {
                        this.parent.showNotification(a.data.message, nokia.mh5.ui.Notification.TIMEOUT_DEFAULT)
                    }
                },
                getMapCenterToShowPoiInGap: function(a, b) {
                    var c = this.getRootOwnerByClass(nokia.mh5.ui.Page);
                    return y(a, b, c, c.map, c.details.mapoffset.root)
                },
                visibleDidChange: function(a, b) {
                    var c, d, e = this,
                        f;
                    a ? (c = this.parent, d = c.map, d.passive = !0, d.hideInfoBubble(), c.traffic.hideIncidents(), d.removePoi(d.getPois()), f = d.createPoi(u.place.getCategoryIcon(e.place), e.place), g.setTimeout(function() {
                        var h = "mh5_dynamic_translate_showing_" + +new Date;
                        e._transitionClass = h;
                        e._ruleRef = r(h, e);
                        k.transition({
                            node: e.root,
                            transitionClass: "mh5_transition_DC_in",
                            fromTransformClass: h,
                            toTransformClass: "mh5_transition_middle"
                        }, function() {
                            k.removeClass(e.root, "mh5_transition_DC_in", "mh5_transition_middle");
                            d.moveTo(e.getMapCenterToShowPoiInGap.call(e, f, -f.image.height / 2));
                            g.setTimeout(function() {
                                c.details.visible && k.removeClass(c.detailsClose.root, "mh5_hidden")
                            }, 400)
                        });
                        e.constructor.prototype.visibleDidChange.call(e, a, b)
                    }, 0)) : b ? (c = e.parent, d = c.map, j(e), k.addClass(c.detailsClose.root, "mh5_hidden"), g.setTimeout(function() {
                        k.transition({
                            node: e.root,
                            transitionClass: "mh5_transition_DC_out",
                            toTransformClass: e._transitionClass
                        }, function() {
                            J(e._ruleRef);
                            e.constructor.prototype.visibleDidChange.call(e, a, b);
                            k.removeClass(e.root, "mh5_transition_DC_out", e._transitionClass);
                            if (e === c.details) {
                                d.passive = !1;
                                var f = e.parent.model,
                                    g = f.selection;
                                d.removePoi(d.getPois());
                                f.data.forEach(function(a) {
                                    d.createPoi(u.place.getCategoryIcon(a), a)
                                });
                                w.get("trafficIncidentsEnabled") && c.traffic.showIncidents();
                                g && d.showInfoBubble(!~f.data.indexOf(g) ? g : d.getPois(g, !0), nokia.mh5.extend({
                                    renderOnly: !0
                                }, g.infoBubbleParams || d.infoBubbleParams))
                            }
                        })
                    }, 0)) : this.constructor.prototype.visibleDidChange.apply(this, arguments)
                }
            },
            incidentDetails: F,
            notification: {
                control: nokia.mh5.ui.Notification,
                visible: !1
            },
            showNotification: function(a, b) {
                var c = this.notification;
                c.text = a;
                c.timeout = b || nokia.mh5.ui.Notification.TIMEOUT_INFINITY;
                c.visible = !0
            },
            resetNotification: function() {
                var a = this.notification;
                a.timeout = nokia.mh5.ui.Notification.TIMEOUT_DEFAULT;
                a.visible = !1
            },
            build: function() {
                this.constructor.prototype.build.call(this);
                if (this.transitionBetweenDetails) this._shadowDetails = new nokia.mh5.components.PlaceDetails(nokia.mh5.app.layout.search.details, this), this._shadowDetails.prepareBindings(), this._shadowDetails.prepareDidChangeNotifications();
                nokia.mh5.ui.Control.watch(this.model, "query", this, function(a) {
                    if (null !== a && void 0 !== a && this.header && this.header.search) this.header.search.query = a
                });
                this.traffic.map = this.map
            },
            setModel: function(a) {
                function b() {
                    var f = e.parent.details,
                        g;
                    f.visible && a.showDetails ? (d.passive = !0, d.hideInfoBubble(), d.removePoi(d.getPois()), g = d.createPoi(u.place.getCategoryIcon(a.selection || c.selection), a.selection || c.selection), d.moveTo(f.getMapCenterToShowPoiInGap(g, -g.image.height / 2))) : f.visible = !! a.showDetails
                }
                var c = this.model,
                    d = this.map,
                    e = this.details,
                    f = a.searchCenter,
                    g = c.searchCenter;
                if (a && a.hasOwnProperty("mapMode")) this.mapMode = a.mapMode || a.showDetails;
                if (a.data && (!(a.data instanceof Array) || a.data.length) && c.data !== a.data) c.reset(), c.data = a.data;
                if (f && (!g || g.longitude != f.longitude || g.latitude != f.latitude)) d.center = c.searchCenter = a.searchCenter;
                if (a.box && d.box !== a.box) d.box = a.box;
                if (a.query && c.query !== a.query) c.query = a.query, !a.data && this.header && this.header.search && this.header.search.search();
                if (!a.query && a.selection && c.selection !== a.selection) 0 > c.data.indexOf(a.selection) ? (c.reset(), e.adapter.fetch(a.selection, null, function(a) {
                    c.data = [a];
                    c.selection = a;
                    d.zoom = 17;
                    b()
                }, function() {
                    c.selection = a.selection;
                    b()
                })) : (c.selection = a.selection, b());
                else if (a.selection && c.selection !== a.selection) c.selection = a.selection, b();
                if (a.selection && a.selection.longitude && a.selection.latitude && !e.visible) d.center = a.selection;
                (c.selection && a.showDetails || e.visible) && b()
            },
            unitSystemDidChange: function() {
                this.list.update()
            },
            onlineStatusDidChange: function(a) {
                if (this.header && this.header.search) {
                    var b = this.header.search;
                    if (a) {
                        if (this._onlinePlaceHolder) b.input.placeholder = this._onlinePlaceHolder;
                        this.resetNotification()
                    } else b.query = "", this._onlinePlaceHolder = b.input.placeholder, b.input.placeholder = l("Notification.goOnlinePlaceHolder"), this.model.reset(), this.map.hideInfoBubble()
                }
            },
            onFavouritesChanged: function(a) {
                if (a) {
                    var b = this.map.getPois(a, !0),
                        c = new Image;
                    if (b) c.src = u.place.getCategoryIcon(a), b.infoBubble ? b.originalImage = c : c.onload = function() {
                        b.image = c
                    }, this.list.update()
                }
            },
            _onFavouritesSynchronized: function() {
                var a = nokia.mh5.components.favourites;
                nokia.mh5.each(this.map.pois, function(b) {
                    var c = b.data,
                        d = a.get(c);
                    c.favourite = !! d;
                    var e = new Image,
                        c = u.place.getCategoryIcon(d || c);
                    e.src = c;
                    b.infoBubble ? b.originalImage = e : e.onload = function() {
                        b.image = e
                    }
                });
                this.list.update()
            },
            _updateDetails: function(a) {
                var b = this;
                if (a.incident) b.incidentDetails.incident = a;
                else if (b.details.visible && b._shadowDetails) {
                    var c = function() {
                            var a = b.details;
                            m.remove(b._shadowDetails, "done", c);
                            b.getContentRoot().insertBefore(b._shadowDetails.root, a.root.nextSibling);
                            b.details = b._shadowDetails;
                            b.details._selectedNearbyCategory = a._selectedNearbyCategory;
                            b._shadowDetails = a;
                            b._shadowDetails.visible = !1;
                            b.details.visible = !0
                        };
                    m.add(b._shadowDetails, "done", c);
                    b._shadowDetails.place = a
                } else b.details.place = a
            },
            getNavigationState: function() {
                var a = this.constructor.prototype.getNavigationState.call(this);
                a.showDetails = this.details.visible;
                return a
            },
            visibleDidChange: function(a, b) {
                this.constructor.prototype.visibleDidChange.call(this, a);
                nokia.mh5.ui.Control[a ? "watch" : "removeBinding"](nokia.mh5.components.favourites, "changedFavourite", this, this.onFavouritesChanged);
                if (a && !this.onFavouritesSynchronized) this.onFavouritesSynchronized = this._onFavouritesSynchronized.bind(this), nokia.mh5.event.add(nokia.mh5.components.favourites, "synchronized", this.onFavouritesSynchronized);
                a && this.details.visible ? this.details.resize() : j(this.details);
                a && !b && this.traffic.reloadIncidents()
            }
        },
        route: {
            model: {
                from: null,
                to: null,
                parameters: {
                    mode: "walk"
                },
                selection: null,
                data: [],
                reset: function() {
                    this.selection = this.to = this.from = null;
                    this.data = []
                }
            },
            children: "header,map,traffic,maneuversContainer,detailsClose,incidentDetails,notification".split(","),
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            header: {
                control: nokia.mh5.ui.Container,
                rootHtmlElementName: "header",
                cssClass: "mh5_baseBackgroundColor",
                children: ["route"],
                route: {
                    control: nokia.mh5.components.Route,
                    children: ["inputs", "border", "mode", "fromList", "toList"],
                    border: {
                        control: nokia.mh5.ui.Control,
                        cssClass: "mh5_border mh5_standardBorder"
                    },
                    inputs: {
                        from: {
                            parameters: q
                        },
                        to: {
                            parameters: q
                        }
                    },
                    mode: {
                        children: ["button", "timetravel", "toggle", "go"],
                        cssClass: "mh5_bottomPart",
                        layout: {
                            type: nokia.mh5.ui.ColumnLayout
                        },
                        timetravel: {
                            control: nokia.mh5.ui.Container,
                            cssClass: "mh5_box-flex1"
                        },
                        toggle: {
                            control: nokia.mh5.ui.Button,
                            cssClass: "mh5_Button mh5_maneuvers",
                            visible: !1,
                            onClick: function() {
                                var a = this.getRootOwnerByClass(nokia.mh5.ui.Page),
                                    b = a.maneuversContainer,
                                    a = a.map,
                                    c = {
                                        type: "fade",
                                        mode: b.visible ? "out" : "in",
                                        node: b.root,
                                        persistence: !0,
                                        callback: b.visible &&
                                        function() {
                                            b.visible = !1;
                                            k.removeClass(this.root, "mh5_ListMode");
                                            m.fire(g, "hideAddressBar")
                                        }.bind(this)
                                    };
                                nokia.mh5.maps.analytics.log({
                                    gn: "directions:maneuvers",
                                    c32: b.visible ? "close maneuvers" : "show maneuvers",
                                    v32: "~c32"
                                });
                                k.doTransition(c);
                                b.visible ? a.visible = !0 : (a.visible = !1, b.visible = !0, k.addClass(this.root, "mh5_ListMode"))
                            },
                            index: 0
                        },
                        go: {
                            control: nokia.mh5.ui.Button,
                            cssClass: "mh5_Button mh5_navigation",
                            visible: !1,
                            onClick: function() {
                                var a = this.getRootOwnerByClass(nokia.mh5.ui.Page),
                                    b = this.parent.parent;
                                if (n.available && 5E4 < v.pointDistance(n.coords, b.to)) {
                                    var c = w.current.unitSystem;
                                    a.showNotification(l("Error.tooLongWalkingDistance", {
                                        maxWalkingDistance: ("mi" == c ? 30 : 50) + c
                                    }))
                                } else c = o.webview ? "http://m.maps.nokia.com/fw/audio/" : nokia.mh5.assetsPath + "audio/", c += "languages.js?r=" + Math.round(1E3 * Math.random()), nokia.mh5.jsonp(c, function(c) {
                                    var d = l.language,
                                        c = -1 === c.indexOf(d) && c.indexOf(d.substr(0, 2));
                                    new nokia.mh5.maps.NavigationDisclaimerDialog({
                                        enOnly: c,
                                        onFinish: function() {
                                            var b = this.from;
                                            nokia.mh5.app.controller.navigate(this.to, (!("name" in b) || b.name == t) && {
                                                shape: a.map.route,
                                                maneuvers: a.maneuversContainer.maneuvers.items
                                            });
                                            nokia.mh5.maps.analytics.log({
                                                gn: "disclaimer",
                                                c32: "start navigation",
                                                v32: "~c32"
                                            })
                                        }.bind(b)
                                    });
                                    nokia.mh5.maps.analytics.log({
                                        gn: "directions:disclaimer",
                                        c32: "disclaimer shown",
                                        v32: "~c32"
                                    })
                                }, null, "CB_AudioLanguages")
                            }
                        }
                    },
                    fromList: {
                        visibleDidChange: function(a) {
                            this.constructor.prototype.visibleDidChange.apply(this, arguments);
                            var b = this.parent.parent.parent;
                            if (b) k[a ? "addClass" : "removeClass"](b.header.root, "mh5_suggestionListVisible"), k[a ? "addClass" : "removeClass"](b.notification.root, "mh5_listmode"), b.map.visible = !a
                        }
                    },
                    toList: {
                        visibleDidChange: function(a) {
                            this.constructor.prototype.visibleDidChange.apply(this, arguments);
                            var b = this.parent.parent.parent;
                            if (b) k[a ? "addClass" : "removeClass"](b.header.root, "mh5_suggestionListVisible"), k[a ? "addClass" : "removeClass"](b.notification.root, "mh5_listmode"), b.map.visible = !a
                        }
                    }
                }
            },
            map: {
                control: nokia.mh5.components.Map,
                addressLookup: !1,
                moveToUserPosition: !1,
                infoBubble: {
                    content: ["title"],
                    listeners: {
                        click: function() {
                            var a = nokia.mh5.app.controller,
                                b = this.data;
                            b.incident ? (b = this.parent.parent, a.updateHistoryEntry(), b.incidentDetails.visible = !0, a.pushHistoryEntry("route", b.getNavigationState(), b.getHash())) : b.routeInfo || (d(b), a.details(b))
                        }
                    }
                },
                listeners: {
                    poiclick: function(a) {
                        var b = this.parent.model,
                            c = a.data[0];
                        c.data.routeInfo && a.data[1] && (c = a.data[1]);
                        b.selection = c.data;
                        nokia.mh5.app.controller.updateHistoryEntry();
                        a.defaultPrevented || (a.preventDefault(), c.infoBubble || (this.hideInfoBubble(this.infoBubbles.filter(f, !1)), c.data.name ? this.showInfoBubble(c) : this._triggerReverseGeoCoding(c)))
                    },
                    maplongpress: function(a) {
                        this.parent.model.selection = a.data;
                        nokia.mh5.app.controller.updateHistoryEntry();
                        this.hideInfoBubble(this.infoBubbles.filter(f, !1));
                        a.preventDefault()
                    },
                    mapclick: function(a) {
                        var b = this.parent.model;
                        if (b.selection) b.selection = null, nokia.mh5.app.controller.updateHistoryEntry();
                        this.hideInfoBubble(this.infoBubbles.filter(f, !1));
                        a.preventDefault()
                    },
                    mapzoomchange: function(a) {
                        var a = a.data,
                            b = this.parent;
                        a.newValue > a.oldValue && b._zoom && a.newValue - 2 >= b._zoom && g.setTimeout(function() {
                            b.map.route = b._shape;
                            delete b._zoom;
                            delete b._shape
                        }, 1)
                    }
                },
                _triggerReverseGeoCoding: function(a) {
                    var b = this,
                        c = nokia.mh5.adapters.Search,
                        d = a.data;
                    c.reverseGeoCode(d, {
                        appId: this.appId,
                        appCode: this.appCode
                    }, function(e) {
                        c.merge(d, e);
                        b.showInfoBubble(a, void 0)
                    })
                }
            },
            traffic: {
                control: nokia.mh5.components.Traffic,
                visible: !1
            },
            unitSystemBinding: "nokia.mh5.components.settings#current.unitSystem",
            onlineStatusBinding: "nokia.mh5.components.settings#current.isOnline",
            unitSystemDidChange: function() {
                var a = this.model,
                    b = this.map.infoBubbles.filter(f, !0)[0];
                b && (this.map.hideInfoBubble(b), x(this.map, a.to, b.data.summary));
                this.maneuversContainer.maneuvers.renderedItems.forEach(function(a) {
                    a.update && a.update()
                })
            },
            onlineStatusDidChange: function(a, b) {
                a && !1 === b ? this.resetNotification() : b && this.showNotification(l("Notification.goOnline"))
            },
            maneuversContainer: {
                children: ["maneuvers", "disclaimer"],
                control: nokia.mh5.ui.Container,
                cssClass: "mh5_ManeuversContainer",
                visible: !1,
                maneuvers: {
                    control: nokia.mh5.ui.List,
                    cssClass: "mh5_List mh5_Maneuvers",
                    itemClass: nokia.mh5.components.RouteListItem
                },
                disclaimer: {
                    control: nokia.mh5.ui.Control,
                    cssClass: "mh5_pt_disclaimer mh5_primaryColorBright",
                    visible: !1
                }
            },
            detailsClose: {
                control: nokia.mh5.ui.Control,
                visible: !1,
                cssClass: "mh5_showDetails"
            },
            incidentDetails: F,
            notification: {
                control: nokia.mh5.ui.Notification,
                visible: !1
            },
            _pushSearchResultListToHistory: !0,
            cssClass: "mh5_Page mh5_RoutePage mh5_TrafficPage",
            build: function() {
                var a = m.add,
                    b = m.remove,
                    c = this,
                    d = c.map,
                    e = c.header.route.inputs,
                    h = e.from,
                    i = e.to,
                    j = h.input,
                    r = i.input,
                    q = c.header.route,
                    e = n.status,
                    s = function() {
                        b(c.map.root, "down", this._inputBlurBound, !0);
                        b(c.maneuversContainer.root, "down", this._inputBlurBound, !0)
                    },
                    u = function(b) {
                        var d = this,
                            e = q.inputs,
                            f = r == b.target ? "to" : "from",
                            g = "from" == f ? "to" : "from",
                            h = d.value === t && n.available;
                        c.map.tracking = !1;
                        e[g].visible = !1;
                        k.removeClass(d.root.firstChild, h ? "mh5_current" : "mh5_" + f);
                        this._inputBlurBound = this._inputBlurBound ||
                        function() {
                            h = d.value === t && n.available;
                            e[g].visible = !0;
                            d.value && k.addClass(d.root.firstChild, h ? "mh5_current" : "mh5_" + f);
                            d.blur()
                        };
                        a(c.map.root, "down", this._inputBlurBound, !0);
                        a(c.maneuversContainer.root, "down", this._inputBlurBound, !0)
                    },
                    y = function(a) {
                        c.incidentDetails.visible = !1;
                        h == a.target && a.data.query == t ? (a.preventDefault(), i.visible = !0) : w.get("isOnline") ? c.showNotification(l("searching") + "...") : (a.preventDefault(), (i == a.target ? h : i).visible = !0, c.showNotification(l("Notification.goOnline")))
                    },
                    F = function(a) {
                        c._shape = a
                    },
                    M = function(a) {
                        var b = "from" == (i == a.target ? "to" : "from") ? "to" : "from",
                            a = 0 < a.data.results.length;
                        c.listMode = c.listMode || c.maneuversContainer.visible;
                        c.resetNotification();
                        if (a) {
                            if (c._pushSearchResultListToHistory) nokia.mh5.app.controller.pushHistoryEntry("route", c.getNavigationState(), c.getHash()), c._pushSearchResultListToHistory = !1;
                            c.map.visible = !0;
                            c.maneuversContainer.visible = !1
                        } else c.showNotification(l("Notification.noResultFound"), nokia.mh5.ui.Notification.TIMEOUT_DEFAULT), q.inputs[b].visible = !0
                    },
                    J = function(a) {
                        var b = q.toList == a.target ? "to" : "from",
                            e = c.model;
                        q.mode.toggle.visible = c.maneuversContainer.visible = c.listMode;
                        c.map.visible = !c.maneuversContainer.visible;
                        c.listMode = !1;
                        k.addClass(q.inputs[b].input.root.firstChild, "mh5_" + b);
                        q.inputs["to" == b ? "from" : "to"].visible = !0;
                        c[b + "Poi"] && d.removePoi(c[b + "Poi"]);
                        c[b + "Poi"] = d.createPoi(nokia.mh5.assetsPath + "img/" + b + ".png", a.data.item);
                        c[b + "Poi"].privilegeLevel = 1;
                        if (!n.available) e[b] = q[b], e.parameters = q.parameters, nokia.mh5.app.controller.updateHistoryEntry()
                    };
                c.constructor.prototype.build.call(this);
                a(j, "focus", u);
                a(j, "blur", s);
                a(r, "focus", u);
                a(r, "blur", s);
                a(h, "beforesearch", y);
                a(i, "beforesearch", y);
                a(h, "success", M);
                a(i, "success", M);
                a(q, "beforeroute", function(a) {
                    var b = a.data,
                        e = q.mode,
                        f = this.inputs.from.input,
                        g = this.inputs.to.input,
                        h = b.from,
                        i = b.to,
                        j = b.parameters.mode,
                        A = c.model,
                        n = d.hasLayer("timeTravelTraffic");
                    switch (j) {
                    case "pt":
                        this.originalMapSchema = w.get("mapSchema");
                        w.set("mapSchema", "normal.day.grey");
                        n && d.removeLayer("timeTravelTraffic");
                        break;
                    case "walk":
                        this.originalMapSchema ? (w.set("mapSchema", this.originalMapSchema), this.originalMapSchema = null) : n && (d.removeLayer("timeTravelTraffic"), w.set("mapSchema", "normal.day.traffic"));
                        break;
                    case "drive":
                        if (this.originalMapSchema) w.set("mapSchema", this.originalMapSchema), this.originalMapSchema = null
                    }
                    d.box = [h, i];
                    d.route = [];
                    d.hideInfoBubble();
                    delete c._shape;
                    delete c._zoom;
                    delete this.parameters.updateCallback;
                    if ("drive" === j) this.parameters.zoom = c._zoom = d.zoom, this.parameters.updateCallback = F;
                    c.fromPoi && d.removePoi(c.fromPoi);
                    c.toPoi && d.removePoi(c.toPoi);
                    k.removeClass(f.root.firstChild, "mh5_from", "mh5_current");
                    k.removeClass(g.root.firstChild, "mh5_to");
                    c.fromPoi = d.createPoi(nokia.mh5.assetsPath + "img/from.png", h);
                    c.toPoi = d.createPoi(nokia.mh5.assetsPath + "img/to.png", i);
                    c.fromPoi.privilegeLevel = c.toPoi.privilegeLevel = 1;
                    k.addClass(f.root.firstChild, h.name ? "mh5_from" : "mh5_current");
                    k.addClass(g.root.firstChild, "mh5_to");
                    A.from = h;
                    A.to = i;
                    A.parameters = b.parameters;
                    c.visible && nokia.mh5.app.controller.updateHistoryEntry();
                    c.traffic && c.traffic.reloadIncidents();
                    "walk" == j && 5E4 < v.pointDistance(h, i) ? (b = w.current.unitSystem, c.showNotification(l("Error.routeTooLong", {
                        maxWalkingDistance: ("mi" == b ? 30 : 50) + b
                    })), e.toggle.visible = e.go.visible = !1, a.preventDefault()) : c.showNotification(l("Notification.routeCalculation"))
                });
                a(q, "success", function(a) {
                    var b = this.parameters.mode,
                        e = q.mode,
                        h = q.inputs,
                        a = a.data,
                        i = c.model,
                        j = d.infoBubbles.filter(f, !0)[0],
                        A;
                    A = a.shape;
                    c.timeTraveling ? c.showNotification(l("Notification.trafficInBeta"), nokia.mh5.ui.Notification.TIMEOUT_DEFAULT) : c.resetNotification();
                    nokia.mh5.dom["pt" == b && a.summary.disclaimers ? "addClass" : "removeClass"](c.maneuversContainer.root, "mh5_pt_disclaimer");
                    "pt" == b ? (c.maneuversContainer.disclaimer.root.innerHTML = l("RA.disclaimer"), a.summary.disclaimers && a.summary.disclaimers.forEach(function(a) {
                        c.maneuversContainer.disclaimer.root.innerHTML += k.createHyperlinkHTML({
                            href: a.link,
                            target: "_blank"
                        }, a.name)
                    }), c.maneuversContainer.disclaimer.visible = !! a.summary.disclaimers) : c.maneuversContainer.disclaimer.visible = "pt" == b;
                    c.maneuversContainer.maneuvers.items = a.maneuvers;
                    e.toggle.visible = h.from.visible = h.to.visible = !0;
                    q.mode.go.visible = !(o.android && 2.2 >= o.android.version) && "walk" == b && n.available;
                    d.box = a.box || A;
                    g.setTimeout(function() {
                        d.route = A
                    }, 1);
                    j && d.hideInfoBubble(j);
                    x(d, i.to, a.summary);
                    c._pushSearchResultListToHistory = !0;
                    nokia.mh5.maps.analytics.log({
                        gn: "directions",
                        c32: "route displayed",
                        ev: "event26",
                        c35: b,
                        v35: "~c35"
                    })
                });
                a(q, "error", function(a) {
                    var b = q.mode;
                    nokia.mh5.dom.removeClass(c.maneuversContainer.root, "mh5_pt_disclaimer");
                    b.toggle.visible = c.listMode || c.maneuversContainer.visible;
                    b.go.visible = !1;
                    q.inputs.from.visible = q.inputs.to.visible = !0;
                    c.maneuversContainer.disclaimer.visible = !1;
                    c.showNotification(a.data.message || l("Notification.noRoutingService"), nokia.mh5.ui.Notification.TIMEOUT_DEFAULT);
                    c.maneuversContainer.maneuvers.items = [{
                        itemClass: H
                    }];
                    c._pushSearchResultListToHistory = !0
                });
                a(q, "clear", function() {
                    var a = q.inputs,
                        b = q.mode,
                        e = c.model,
                        g = c.maneuversContainer,
                        h = d.infoBubbles.filter(f, !0)[0];
                    q.from || d.removePoi(c.fromPoi);
                    q.to || d.removePoi(c.toPoi);
                    d.route = [];
                    d.hideInfoBubble(h);
                    g.maneuvers.items = [];
                    d.visible = a.from.visible = a.to.visible = !0;
                    g.visible = b.go.visible = b.toggle.visible = !1;
                    k.removeClass(b.toggle.root, "mh5_ListMode");
                    e.from = q.from;
                    e.to = q.to;
                    e.parameters = q.parameters;
                    nokia.mh5.app.controller.updateHistoryEntry()
                });
                a(q.fromList, "tap", J);
                a(q.toList, "tap", J);
                a(n, "positionactivate", function() {
                    var a = q.mode.go,
                        b = !(o.android && 2.2 >= o.android.version) && "walk" == q.parameters.mode;
                    q.to || c.resetNotification();
                    if (!c.fromPoi) c.fromPoi = d.createPoi(nokia.mh5.assetsPath + "img/from.png", {
                        latitude: n.latitude,
                        longitude: n.longitude,
                        name: t
                    });
                    c.fromPoi.privilegeLevel = 1;
                    j.value == t || "" === j.value ? (k.addClass(j.root.firstChild, "mh5_current"), a.visible = b && !! q.to && 5E4 > v.pointDistance(n.coords, q.to)) : a.visible = b && !(!q.to || !q.from)
                });
                a(n, ["positionerror", "positionlost", "positiondeactivate"], function() {
                    q.mode.go.visible = !1;
                    q.from || c.showNotification(l("Notification.cantFindLocation"))
                });
                nokia.mh5.ui.Control.watch(this.model, "selection", this, function(a) {
                    c.incidentDetails.incident = a && a.incident ? a : null
                });
                if (("inactive" == e || "waiting" == e || "error" == e) && (!q.from || !q.from.latitude || !q.from.longitude)) c.showNotification(l("Notification.lookingForCurrentPosition")), ("inactive" == e || "error" == e) && n.activate();
                this.traffic.map = d
            },
            showNotification: function(a, b) {
                var c = this.notification;
                c.timeout = b || nokia.mh5.ui.Notification.TIMEOUT_INFINITY;
                c.text = a;
                c.visible = !0
            },
            resetNotification: function() {
                var a = this.notification;
                a.timeout = nokia.mh5.ui.Notification.TIMEOUT_DEFAULT;
                a.visible = !1
            },
            visibleDidChange: function(a, b) {
                var c = this.header.route,
                    d = c.inputs,
                    e = d.from.input,
                    f = e.root.firstChild,
                    d = d.to.input.root.firstChild,
                    g = this.map;
                nokia.mh5.maps.analytics.logIfVisible(this, {
                    gn: "directions",
                    c32: "directions"
                });
                (g.visible = a) && !b && this.traffic.reloadIncidents();
                if (n.available && ("" === e.value || e.value == t)) {
                    if (!this.fromPoi) this.fromPoi = g.createPoi(nokia.mh5.assetsPath + "img/from.png", n.coords);
                    this.fromPoi.privilegeLevel = 1;
                    e.value = t;
                    k.addClass(f, "mh5_current")
                } else k.removeClass(f, "mh5_from", "mh5_current"), k.removeClass(d, "mh5_to"), c.from && k.addClass(f, "mh5_from"), c.to && k.addClass(d, "mh5_to")
            },
            setModel: function(a) {
                function b() {
                    if (20 > f.size.width) g.setTimeout(b, 5);
                    else {
                        if (a.parameters && e.parameters != a.parameters) e.parameters = d.parameters = a.parameters;
                        if (a.from && e.from != a.from) e.from = d.from = a.from;
                        if (a.to && e.to != a.to) e.to = d.to = a.to;
                        var h = d.inputs.from.input.value == t;
                        d.inputs.from.input.value = e.from && e.from.name || (n.available ? t : "");
                        e.from && (h = d.inputs.from.input.value == t, k.addClass(d.inputs.from.input.root.firstChild, h ? "mh5_current" : "mh5_from"));
                        e.to ? (d.inputs.to.input.value = e.to.name || "", k.addClass(d.inputs.to.input.root.firstChild, "mh5_to"), c.toPoi && f.removePoi(c.toPoi), c.toPoi = f.createPoi(nokia.mh5.assetsPath + "img/to.png", e.to)) : d.inputs.to.input.value = "";
                        f._ipLookupRequest && (f._ipLookupRequest.cancel(), delete f._ipLookupRequest);
                        if ((!a.from && !n.available || !a.to) && a.zoom && a.center) f.zoom = a.zoom, f.center = a.center;
                        else if ((a.from || n.available) && a.to) f.box = [a.from || n.coords, a.to]
                    }
                }
                var c = this,
                    d = c.header.route,
                    e = c.model,
                    f = c.map,
                    h = c.traffic,
                    i = m.add;
                if (a.traffic && !e.traffic) e.traffic = d.traffic = !0, e.parameters = d.parameters = {
                    mode: "drive"
                }, w.isFirstTime = !1, i(n, "positionactivate", function() {
                    f.zoom = 11
                }), i(n, ["positionerror", "positionlost", "positiondeactivate"], function() {
                    f.zoom = 9
                }), m.one(f, "ready", function() {
                    h.enableTraffic()
                });
                if (!a.showDetails && c.incidentDetails.visible) c.incidentDetails.visible = !1;
                c._pushSearchResultListToHistory = !0;
                d.fromList.visible = d.toList.visible = !1;
                d.inputs.from.visible = d.inputs.to.visible = !0;
                if (c.listMode) c.maneuversContainer.visible = !0, c.map.visible = !1;
                if (f.isReady) b();
                else m.one(f, "ready", b)
            }
        },
        share: {
            children: ["storyCreator"],
            model: {
                data: null
            },
            storyCreator: {
                control: nokia.mh5.connectors.story.StoryCreator
            },
            setModel: function(a) {
                this.model.data = a.data;
                this.storyCreator.update(a.data)
            },
            visibleDidChange: function(a) {
                this.constructor.prototype.visibleDidChange.call(this, a);
                this.storyCreator.visible = a
            }
        },
        collectionList: nokia.mh5.maps.collections.List,
        collectionDetails: nokia.mh5.maps.collections.Details,
        collectionManage: nokia.mh5.maps.collections.ManageCollection,
        favouriteManage: nokia.mh5.maps.collections.ManageFavourite,
        navigation: {
            model: {
                to: null
            },
            children: ["navigation"],
            cssClass: "mh5_Page mh5_NavigationPage",
            navigation: {
                control: nokia.mh5.components.Navigation
            },
            setModel: function(a) {
                this.model.to = a.to;
                this.navigation.update(a.to, a._route)
            },
            visibleDidChange: function(a) {
                this.constructor.prototype.visibleDidChange.call(this, a);
                this.navigation.visible = a
            }
        }
    }
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.components.PlaceTabletListItem");
nokia.mh5.components.PlaceTabletListItem = new nokia.mh5.Class(nokia.mh5.ui.Control, function(g) {
    return {
        rootHtmlElementName: "li",
        cssClass: "mh5_ListItem",
        constructor: function(a, b) {
            g.constructor.call(this, a, b);
            this.update()
        },
        update: function() {
            var a, b = !(!this.distance || !this.ratingValue),
                c = /(\d+(\.\d+)?)(\w+)/;
            a = '<div class="mh5_ImgWrapper">' + ('<img src="' + nokia.mh5.utils.place.getCategoryIcon(this) + '"></img>');
            a = a + '</div><div class="mh5_RowLayout"><div class="mh5_ListItem_name">' + (!this.placeId && this.name ? this.name.split(",")[0] : this.name);
            a += "</div>";
            this.address && (a = a + '<div class="mh5_ListItem_address">' + (this.address.replace(/(.*?)\,\ (.*)/, '$1,<br><span class="mh5_ellipsis">$2</span>') + "</div>"));
            b && (a += '<div class="mh5_ColumnLayout">');
            if (this.ratingValue) this._rating = this._rating || new nokia.mh5.ui.Rating, this._rating.value = this.ratingValue, a += this._rating.root.outerHTML;
            this.distance && (c = nokia.mh5.utils.formatDistance(this.distance, nokia.mh5.components.settings.current.unitSystem).match(c), a += '<div class="mh5_ListItem_distance"><span>' + c[1] + "</span>" + c[3] + "</div>");
            b && (a += "</div>");
            this.root.innerHTML = a
        }
    }
});
nokia.mh5.provide("nokia.mh5.app.tabletLayout");
(function() {
    nokia.mh5.app.tabletLayout = {
        search: {
            cssClass: "mh5_Page mh5_SearchPage",
            header: {
                children: ["search"]
            },
            list: {
                layout: {
                    type: nokia.mh5.ui.ColumnLayout
                },
                itemClass: nokia.mh5.components.PlaceTabletListItem,
                hScroll: !0,
                itemsDidChange: function(a) {
                    this.constructor.prototype.itemsDidChange.call(this, a);
                    this.visible = 0 < a.length ? !0 : !1;
                    this.parent.map.resize()
                },
                listeners: {
                    tap: function(a) {
                        var a = a.data.item,
                            b = this.parent,
                            c = b.map,
                            e = nokia.mh5.app.controller;
                        b.model.selection !== a ? (this.parent.model.selection = a, e.updateHistoryEntry(), c.hideInfoBubble(), c.showInfoBubble(c.getPois(a, !0))) : (b.details.visible = !0, e.pushHistoryEntry("search", b.getNavigationState(), b.getHash()), b.openDetailsTracking(a))
                    }
                }
            },
            build: function() {
                nokia.mh5.app.commonLayout.search.build.call(this);
                var a = this.header;
                if (a && a.search) {
                    var b = a.search.input,
                        c = nokia.mh5.event.add;
                    c(b, "focus", function() {
                        this.map.tracking = !1;
                        if (!this._mapTapEventHandler) this._mapTapEventHandler = function() {
                            b.blur();
                            if (nokia.mh5.platform.android) {
                                var a = document.createElement("input");
                                a.setAttribute("type", "text");
                                document.body.appendChild(a);
                                setTimeout(function() {
                                    a.focus();
                                    setTimeout(function() {
                                        a.setAttribute("style", "display:none;");
                                        document.body.removeChild(a)
                                    }, 5)
                                }, 5)
                            }
                        }, c(this.map.root, "down", this._mapTapEventHandler);
                        c(this.map.root, "down", this._mapTapEventHandler);
                        c(this.list.root, "down", this._mapTapEventHandler)
                    }.bind(this));
                    c(b, "blur", function() {
                        nokia.mh5.event.remove(this.map.root, "down", this._mapTapEventHandler);
                        nokia.mh5.event.remove(this.list.root, "down", this._mapTapEventHandler)
                    }.bind(this))
                }
                nokia.mh5.ui.Control.watch(this.model, "selection", this, function(a, b) {
                    var c = this.list;
                    if (b) {
                        var d = c.items.indexOf(b);
                        0 <= d && (nokia.mh5.dom.removeClass(c.renderedItems[d].root, "mh5_selected"), nokia.mh5.dom.removeClass(c.root, "mh5_selected"))
                    }
                    if (a) {
                        this._updateDetails(a);
                        var g = c.items.indexOf(a);
                        if (0 <= g && (nokia.mh5.dom.addClass(c.renderedItems[g].root, "mh5_selected"), nokia.mh5.dom.addClass(c.root, "mh5_selected"), c._scroll)) {
                            var d = c.root.offsetLeft,
                                f = c.root.offsetWidth,
                                k = d + f,
                                m = c.renderedItems[g].root.offsetLeft,
                                g = c.renderedItems[g].root.offsetWidth,
                                n = m + g,
                                l = c._scroll.x;
                            m + l < d ? c.scrollTo(-m + g / 2, 0) : n + l > k && c.scrollTo(-m + f - 3 * g / 2, 0)
                        }
                    }
                });
                nokia.mh5.ui.Control.watch(this.model, "data", this, function(a, b) {
                    if (0 < a.length) this.list.items = a, a.forEach(function(a) {
                        this.map.createPoi(nokia.mh5.utils.place.getCategoryIcon(a), a)
                    }.bind(this));
                    else if (b && 0 !== b.length) this.list.items = [], nokia.mh5.components.Traffic.removeNonTrafficPois(this.map)
                })
            },
            onFavouritesChanged: function(a) {
                nokia.mh5.app.commonLayout.search.onFavouritesChanged.call(this, a);
                a = this.list.items.indexOf(this.model.selection);
                0 <= a && nokia.mh5.dom.addClass(this.list.renderedItems[a].root, "mh5_selected")
            },
            unitSystemDidChange: function() {
                nokia.mh5.app.commonLayout.search.unitSystemDidChange.call(this);
                var a = this.list;
                if (this.model.selection) {
                    var b = a.items.indexOf(this.model.selection);
                    0 <= b && (nokia.mh5.dom.addClass(a.renderedItems[b].root, "mh5_selected"), nokia.mh5.dom.addClass(a.root, "mh5_selected"))
                }
            },
            visibleDidChange: function(a) {
                nokia.mh5.app.commonLayout.search.visibleDidChange.apply(this, arguments);
                this.map.visible = a
            }
        }
    };
    var g = {};
    nokia.mh5.extendDeep(g, nokia.mh5.app.commonLayout);
    nokia.mh5.extendDeep(g, nokia.mh5.app.tabletLayout);
    g.controller = nokia.mh5.app.commonLayout.controller;
    nokia.mh5.app.tabletLayout = g
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.app.phoneLayout");
(function() {
    var g = nokia.mh5.i18n;
    nokia.mh5.app.phoneLayout = {
        search: {
            children: "header,map,traffic,detailsClose,list,details,incidentDetails,noResults,notification".split(","),
            cssClass: "mh5_Page mh5_SearchPage",
            noResults: {
                cssClass: "mh5_noresults",
                control: nokia.mh5.ui.Control,
                innerHTML: '<div class="mh5_noresultstxt">' + g("Notification.noResult") + "</div>",
                visible: !1
            },
            mapMode: !0,
            mapModeDidChange: function(a, b) {
                if (void 0 !== b) {
                    var c = this,
                        e = c.map,
                        g = c.details,
                        h = c.model,
                        d = 0 < h.data.length ? c.list : c.noResults,
                        j = {
                            type: "fade",
                            mode: c.mapMode ? "out" : "in",
                            node: d.root,
                            persistence: !0
                        };
                    if (c.header) nokia.mh5.dom[a ? "removeClass" : "addClass"](c.header.toggle.root, "mh5_ListMode");
                    c.mapMode ? (j.callback = function() {
                        e.resize();
                        d.visible = !1;
                        if (c._showDetailsAfterListFading && h.selection) g.visible = !0, c._showDetailsAfterListFading = !1
                    }, e.visible = !0, nokia.mh5.event.fire(nokia.mh5.win, "hideAddressBar", {}, !0, !0)) : (j.callback = function() {
                        e.visible = !1
                    }, d.visible = !0);
                    nokia.mh5.dom.doTransition(j)
                }
            },
            header: {
                children: ["search", "toggle"],
                layout: {
                    type: nokia.mh5.ui.ColumnLayout
                },
                search: {
                    listeners: {
                        clear: function() {
                            nokia.mh5.app.commonLayout.search.header.search.listeners.clear.call(this);
                            var a = this.parent.parent;
                            if (!a.mapMode) a.mapMode = !0, a.header.toggle.visible = !1;
                            nokia.mh5.app.controller.updateHistoryEntry()
                        }
                    }
                },
                toggle: {
                    control: nokia.mh5.ui.Button,
                    cssClass: "mh5_Button mh5_modeToggle",
                    visible: !1,
                    onClick: function() {
                        var a = this.parent.parent;
                        nokia.mh5.maps.analytics.log({
                            gn: a.mapMode ? "map:list" : "list:map",
                            c32: a.mapMode ? "list toggle" : "map toggle",
                            v32: "~c32"
                        });
                        a.mapMode = !a.mapMode
                    }
                }
            },
            list: {
                itemClass: nokia.mh5.components.PlaceListItem,
                itemsDidChange: function(a) {
                    this.constructor.prototype.itemsDidChange.call(this, a);
                    var b = this.parent,
                        c = b.header && b.header.toggle,
                        a = 0 < a.length;
                    b.mapMode ? c && !b.details.visible && (c.visible = a) : (this.visible = a, b.noResults.visible = !a)
                },
                listeners: {
                    tap: function(a) {
                        var a = a.data.item,
                            b = this.parent,
                            c = b.map,
                            e = nokia.mh5.app.controller;
                        if (b.model.selection !== a) b.model.selection = a, c.hideInfoBubble(), c.showInfoBubble(c.getPois(a, !0));
                        b.model.mapMode = !1;
                        e.updateHistoryEntry();
                        e.pushHistoryEntry("search", b.getNavigationState(), b.getHash());
                        b._showDetailsAfterListFading = b.mapMode = !0;
                        b.openDetailsTracking(a)
                    }
                }
            },
            details: {
                visibleDidChange: function(a) {
                    var b = this.parent;
                    if (b && this !== b._shadowDetails) {
                        var c = b.header && b.header.toggle;
                        c && (c.visible = !a && 0 < b.model.data.length)
                    }
                    nokia.mh5.app.commonLayout.search.details.visibleDidChange.apply(this, arguments)
                }
            },
            incidentDetails: {
                visibleDidChange: function(a) {
                    var b = this.parent,
                        c = b.header && b.header.toggle;
                    if (c) c.visible = !a && 0 < b.model.data.length;
                    nokia.mh5.app.commonLayout.search.incidentDetails.visibleDidChange.apply(this, arguments)
                }
            },
            build: function() {
                nokia.mh5.app.commonLayout.search.build.call(this);
                var a = this.header;
                if (a && a.search) {
                    var b = a.search.input,
                        c = nokia.mh5.event.add;
                    c(b, "focus", function() {
                        this.map.tracking = !1;
                        a.toggle.visible = !1;
                        if (!this._mapTapEventHandler) this._mapTapEventHandler = function() {
                            b.blur();
                            if (nokia.mh5.platform.android) {
                                var a = document.createElement("input");
                                a.setAttribute("type", "text");
                                document.body.appendChild(a);
                                setTimeout(function() {
                                    a.focus();
                                    setTimeout(function() {
                                        a.setAttribute("style", "display:none;");
                                        document.body.removeChild(a)
                                    }, 5)
                                }, 5)
                            }
                        }, c(this.map.root, "down", this._mapTapEventHandler)
                    }.bind(this));
                    c(b, "blur", function() {
                        nokia.mh5.event.remove(this.map.root, "down", this._mapTapEventHandler);
                        this._mapTapEventHandler = null;
                        a.toggle.visible = !(!this.model.data.length && this.mapMode || this.details.visible)
                    }.bind(this))
                }
                nokia.mh5.ui.Control.watch(this.model, "data", this, function(a, b) {
                    if (0 < a.length) this.list.items = a, a.forEach(function(a) {
                        this.map.createPoi(nokia.mh5.utils.place.getCategoryIcon(a), a)
                    }.bind(this));
                    else if (b && 0 !== b.length) this.list.items = [], nokia.mh5.components.Traffic.removeNonTrafficPois(this.map)
                });
                nokia.mh5.ui.Control.watch(this.model, "selection", this, function(a) {
                    a && this._updateDetails(a)
                })
            },
            visibleDidChange: function(a) {
                nokia.mh5.app.commonLayout.search.visibleDidChange.apply(this, arguments);
                if (this.mapMode) this.map.visible = a
            }
        }
    };
    g = {};
    nokia.mh5.extendDeep(g, nokia.mh5.app.commonLayout);
    nokia.mh5.extendDeep(g, nokia.mh5.app.phoneLayout);
    g.controller = nokia.mh5.app.commonLayout.controller;
    nokia.mh5.app.phoneLayout = g
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.app.configurator");
(function() {
    var g = nokia.mh5.resolve,
        a = nokia.mh5.components.settings,
        b = Object.prototype.hasOwnProperty,
        c = {
            search: {
                searchAdapter: "header.search",
                placeholder: "header.search.input"
            }
        },
        e = ["phone", "tablet"],
        i = ["from", "to"];
    nokia.mh5.app.configure = function(h, d) {
        var j, f, k, m, n = h.phoneLayout,
            l = h.tabletLayout,
            o = nokia.mh5.extendDeep,
            u = d.details && d.details.customContent;
        d.distanceUnit && a.set("unitSystem", d.distanceUnit);
        d.positionDisabled && nokia.mh5.geolocation.disable();
        if (d.details && (delete d.details.customContent, k = n.search.details, m = l.search.details, o(k, d.details), o(m, d.details), u)) k.customContent = [].concat(k.customContent).concat(u), m.customContent = [].concat(m.customContent).concat(u), d.details.customContent = u;
        if (b.call(d, "search") && !d.search) n.search.header = l.search.header = null;
        if (d.map) {
            d.map.schema && a.set("mapSchema", d.map.schema);
            k = n.search.map;
            m = l.search.map;
            j = n.route.map;
            f = l.route.map;
            if (b.call(d.map, "positionButton") && !d.map.positionButton) k.positionButton = m.positionButton = j.positionButton = f.positionButton = null;
            if (b.call(d.map, "settingsButton") && !d.map.settingsButton) k.settingsButton = m.settingsButton = j.settingsButton = f.settingsButton = null
        }
        if (d.route) for (k = 0; m = e[k]; k++) for (o = 0; u = i[o]; o++) if (f = d.route[u + "Placeholder"]) j = h[m + "Layout"].route.header.route.inputs[u], j.input = j.input || {}, j.input.placeholder = f;
        for (j in c) if (b.call(d, j) && d[j]) for (f in c[j]) b.call(d[j], f) && (k = g(c[j][f], n[j]), m = g(c[j][f], l[j]), k[f] = m[f] = d[j][f])
    }
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.app.Application");
(function() {
    var g = nokia.mh5.i18n,
        a = nokia.mh5.components.settings;
    nokia.mh5.app.Application = new nokia.mh5.Class(function() {
        return {
            layouts: ["phoneLayout", "tabletLayout"],
            phoneLayout: nokia.mh5.app.phoneLayout,
            tabletLayout: nokia.mh5.app.tabletLayout,
            constructor: function(a) {
                nokia.mh5.extendDeep(this, a);
                if (this.appId) nokia.mh5.appId = this.appId;
                if (this.appCode) nokia.mh5.appCode = this.appCode;
                if (!nokia.mh5.appId || !nokia.mh5.appCode) throw Error(g("Error.applicationCredential"));
                this.configuration && nokia.mh5.app.configure(this, this.configuration);
                var c = nokia.mh5.app.layoutName = this.getLayoutName(),
                    e = nokia.mh5.app.layout = this[c],
                    i = nokia.mh5.app.controller = e.controller;
                i.manipulateUrl = a.manipulateUrl || !1;
                i.browserHistory = void 0 === this.browserHistory ? !0 : this.browserHistory;
                this.hideAddressBar && (nokia.mh5.dom.addEvent(nokia.mh5.win, "load", nokia.mh5.platform.hideAddressBar, !1), nokia.mh5.dom.addEvent(nokia.mh5.win, "hideAddressBar", nokia.mh5.platform.hideAddressBar, !1), nokia.mh5.dom.addEvent(nokia.mh5.win, "orientationchange", nokia.mh5.platform.hideAddressBar, !1), nokia.mh5.event.fire(nokia.mh5.win, "orientationchange", {}, !0, !0));
                i.domNode = this.domNode ? nokia.mh5.doc.querySelector(this.domNode) : nokia.mh5.doc.body;
                this.bindIsOnline();
                nokia.mh5.sso.init();
                nokia.mh5.dom.addClass(i.domNode, "mh5_app");
                nokia.mh5.dom.addClass(i.domNode, "mh5_" + c);
                nokia.mh5.dom.addClass(i.domNode, "mh5_language_" + g.language);
                "default" === nokia.mh5.platform.android.browser && 4 <= nokia.mh5.platform.android.version && nokia.mh5.dom.addClass(i.domNode, "mh5_android4");
                nokia.mh5.platform.ios && nokia.mh5.dom.addClass(i.domNode, "mh5_ios");
                i.setConfiguration(e);
                if (!e.pages || !e.pages.length) throw Error("no pages are defined in " + c);
                if (!~e.pages.indexOf(e.initialPage)) e.initialPage = e.pages[0];
                i.switchTo(e.initialPage, this.startParams || {}, {
                    replaceLastHistoryEntry: !0
                });
                this.checkForOfflineMaps()
            },
            checkForOfflineMaps: function() {
                function b(b) {
                    a.set("hasOfflineMaps", !! b)
                }
                var c = nokia.mh5,
                    e = c.app.controller.getMap(),
                    g = e && e.schema;
                c.platform.offlineStorageSupported ? "normal.day" == g && !a.current.isOnline && e.showStoredTiles(b, b) : setTimeout(b, 0, 0)
            },
            bindIsOnline: function() {
                function b(b) {
                    a.set("isOnline", "online" == b.type)
                }
                a.set("isOnline", nokia.mh5.win.navigator.onLine);
                nokia.mh5.win.addEventListener("online", b, !1);
                nokia.mh5.win.addEventListener("offline", b, !1)
            },
            getLayoutName: function() {
                return 1 == this.layouts.length ? this.layouts[0] : nokia.mh5.platform.phone ? "phoneLayout" : "tabletLayout"
            }
        }
    });
    nokia.mh5.app.embed = function(a) {
        return new nokia.mh5.app.Application(a)
    }
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.maps.AboutPage");
nokia.mh5.maps.AboutPage = new nokia.mh5.Class(nokia.mh5.ui.Page, function(g) {
    var a = nokia.mh5.dom;
    return {
        cssClass: "mh5_Page mh5_AboutPage",
        children: ["header", "title", "content"],
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        header: {
            control: nokia.mh5.maps.Header,
            title: nokia.mh5.i18n("about")
        },
        content: {
            control: nokia.mh5.ui.Container,
            layout: {
                type: nokia.mh5.ui.RowLayout
            },
            cssClass: "mh5_about mh5_primaryColorBright",
            innerHTML: "".concat('<div class="content mh5_no_callout">', '<h1 class="mh5_title">HERE Maps</h1>', '<div class="description">Version: 1.8.44</div>', '<div class="description">Copyright &copy; ', (new Date).getFullYear(), " Nokia. All rights reserved</div>", '<div class="description version">', "<h2>Help make HERE Maps even better</h2>", "Got a great idea or want to report a problem?", "<br />Visit the forum at " + a.createHyperlinkHTML({
                href: "https://betalabs.nokia.com/apps/nokia-maps-for-mobile-web/forum",
                "class": "forumlink",
                target: "_blank"
            }, "Nokia Beta Labs") + ". ", "Your feedback is important and very much appreciated.", "</div>", '<div class="description">', "<h2>Platforms it works on</h2>", '<ul class="mh5_platforms">', "<li>iOS 4.3+</li>", "<li>Android 2.2, 2.3</li>", "<li>Nokia N9 (experimental)</li>", "<li>WebOs (experimental)</li>", "<li>Blackberry 7.0+ (experimental)</li>", "</ul>", "<h2>Have you tried the latest features?</h2>", '<ul class="mh5_changelog">', "<li>- High resolution tiles,</li><li>- Faster routing calls,</li><li>- Better search suggestions</li><li></li>", "</ul>", "</div>", '<div class="help">', '<div class="description">', "For info and tips about how to use ", "HERE for mobile Web visit our ", a.createHyperlinkHTML({
                href: "http://here.com/help",
                target: "_blank",
                id: "helpPage"
            }, "Help pages") + ".", "</div>", "</div>", '<div class="terms">', '<iframe src="tnc_links.html" frameborder="0" scrolling="no">', "</iframe>", "</div>", "</div>")
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.call(this, a);
            nokia.mh5.maps.analytics.logIfVisible(this, {
                gn: "terms of use"
            })
        },
        build: function() {
            g.build.call(this);
            var b = nokia.mh5.components.settings,
                c = this.root.querySelector("#analytics_enable_cbx");
            if (c) c.checked = b.get("analyticsEnabled"), a.addEvent(c, "change", function() {
                b.set("analyticsEnabled", c.checked)
            });
            var e = this.root.querySelector("#helpPage");
            a.addEvent(e, "touchstart", function() {
                nokia.mh5.maps.analytics.log({
                    gn: "about",
                    c32: "help clicked"
                })
            })
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.traffic");
(function() {
    var g = nokia.mh5.maps.traffic,
        a = nokia.mh5.i18n,
        b = [a("day.sunday"), a("day.monday"), a("day.tuesday"), a("day.wednesday"), a("day.thursday"), a("day.friday"), a("day.saturday")],
        c = "00:00,00:30,01:00,01:30,02:00,02:30,03:00,03:30,04:00,04:30,05:00,05:30,06:00,06:30,07:00,07:30,08:00,08:30,09:00,09:30,10:00,10:30,11:00,11:30,12:00,12:30,13:00,13:30,14:00,14:30,15:00,15:30,16:00,16:30,17:00,17:30,18:00,18:30,19:00,19:30,20:00,20:30,21:00,21:30,22:00,22:30,23:00,23:30".split(","),
        e = a("today"),
        i = a("now"),
        h = e,
        d = function(a) {
            var b = a.getDate(),
                c = a.getMonth() + 1;
            return a.getFullYear() + "-" + (9 < c ? "" : "0") + c + "-" + (9 < b ? "" : "0") + b
        };
    g._days = function() {
        for (var a = b[(new Date).getDay()], c = b.slice(0);;) {
            if (c[0] === a) return c[0] = e, c;
            c.push(c.shift())
        }
    };
    g._dayToDate = function(a) {
        var b = new Date,
            a = g._days().indexOf(a);
        return 0 < a ? d(new Date(b.getTime() + 864E5 * a)) : g._today()
    };
    g._currentTime = function() {
        var a = new Date,
            b = a.getMinutes(),
            a = a.getHours();
        return (10 > a ? "0" : "") + a + ":" + (10 > b ? "0" : "") + b
    };
    g._nearestHalf = function() {
        if (h === e) return i;
        var a = new Date,
            b = a.getMinutes(),
            a = a.getHours();
        if (0 <= b && 15 > b) return (10 > a ? "0" : "") + a + ":00";
        if (15 <= b && 45 > b) return (10 > a ? "0" : "") + a + ":30";
        if (45 <= b && 59 >= b && 23 === a) return "";
        if (45 <= b && 59 >= b) return (10 > a + 1 ? "0" : "") + (a + 1) + ":00"
    };
    g._nearestFutureHalf = function() {
        var a = new Date,
            b = a.getMinutes(),
            a = a.getHours();
        if (0 <= b && 30 > b) return (10 > a ? "0" : "") + a + ":30";
        if (30 <= b && 59 >= b && 23 === a) return "";
        if (30 <= b && 59 >= b) return (10 > a + 1 ? "0" : "") + (a + 1) + ":00"
    };
    g._today = function() {
        return d(new Date)
    };
    g._times = function(a) {
        var b = c.slice(0);
        if (a && a === e) {
            var a = g._nearestFutureHalf(),
                d = b.indexOf(a);
            if ("" === a) return [i];
            b.splice(0, d);
            b.splice(0, 0, i)
        }
        return b
    };
    g._correctTimeSelectionAfterDayChanged = function(a, b, c) {
        return a === c ? b : c === e && b <= g._currentTime() ? i : b === i ? g._nearestFutureHalf() : b
    };
    g._shortenDay = function(a) {
        return a !== e ? a.substring(0, 3) + "." : a
    };
    g._nowOrTime = function(a) {
        return a === i ? g._currentTime() : a
    };
    g._getTimestamp = function(a, b, c) {
        b = b || (a || "").split("T")[0] || g._today();
        c = c || (a || "").split("T")[1] || g._currentTime();
        6 > c.length && (c += ":00");
        return b + "T" + c
    };
    g._departureChanged = function(a, b) {
        var c = a.split("T"),
            d = c[0].split("-"),
            e = c[1].split(":"),
            d = new Date(d[0], d[1] - 1, d[2], e[0], e[1]);
        g._today() === c[0] && g._currentTime() + ":00" === c[1] ? (b.resetNotification(), b.timeTraveling = !1, b.traffic && b.traffic.disableTimeTravelTraffic()) : (b.timeTraveling = !0, b.traffic && b.traffic.enableTimeTravelTraffic(d));
        c = b.header.route;
        c.parameters.departure = d;
        c.route()
    };
    g._setDay = function(a, b) {
        var c = a.input,
            d = g._dayToDate(b);
        a.dayNav.root.value = b;
        a.day.text = g._shortenDay(b);
        c.value = a.timeNav.root.value !== i ? g._getTimestamp(c.value, d, null) : g._getTimestamp(c.value, d, g._currentTime())
    };
    g._setTime = function(a, b) {
        var c = a.input,
            d = g._nowOrTime(b);
        a.timeNav.root.value = b;
        a.time.text = d;
        c.value = g._getTimestamp(c.value, null, d)
    };
    var j = new nokia.mh5.Class(nokia.mh5.ui.Container, function(a) {
        return {
            cssClass: "mh5_Select",
            items: [],
            renderedItems: [],
            rootHtmlElementName: "select",
            itemClass: new nokia.mh5.Class(nokia.mh5.ui.Control, function(a) {
                return {
                    rootHtmlElementName: "option",
                    cssClass: "mh5_Option",
                    constructor: function(b, c) {
                        a.constructor.call(this, b, c);
                        this.update()
                    },
                    update: function() {
                        this.root.value = this.root.innerHTML = this.text;
                        this.selected && this.root.setAttribute("selected", "selected")
                    }
                }
            }),
            constructor: function(b, c) {
                a.constructor.call(this, b, c);
                var d = this.getContentRoot();
                d.noPreventDefault = !! b.noPreventDefault;
                nokia.mh5.dom.addEvent(d, "change", function() {
                    if (this.onChange) this.onChange()
                }.bind(this), !0)
            },
            add: function(a, b, c) {
                if (void 0 === b) b = this.items.length;
                var d = [b, 0],
                    e = nokia.mh5.doc.createDocumentFragment(),
                    f, g, h = [],
                    i = this.getContentRoot();
                Array.isArray(a) || (a = [a]);
                c || (d = d.concat(a), this.items.splice.apply(this.items, d));
                for (c = 0, g = a.length; c < g; c++) f = this._createItem(a[c]), h.push(f), e.appendChild(f.root);
                i.children[b] ? i.insertBefore(e, i.children[b]) : i.appendChild(e);
                d.length = 2;
                d = d.concat(h);
                this.renderedItems.splice.apply(this.renderedItems, d)
            },
            _createItem: function(a) {
                var b = {},
                    c;
                for (c in a) a.hasOwnProperty(c) && (b[c] = a[c]);
                return b.itemClass ? new b.itemClass(b, this) : new this.itemClass(b, this)
            },
            itemsDidChange: function(a) {
                this.getContentRoot().innerHTML = "";
                this.renderedItems = [];
                this.add(a, 0, !0)
            }
        }
    }),
        a = function() {
            return {
                route: {
                    header: {
                        route: {
                            mode: {
                                children: ["button", "timetravel", "placeholder", "toggle", "go"],
                                button: {
                                    onValueChange: function(a) {
                                        var b = this.parent.parent.parent.parent,
                                            c = b.header.route,
                                            d = c.parameters,
                                            c = c.mode.timetravel;
                                        "drive" == a ? (c.visible = !0, d.mode = a, this.parent.timetravel.input.value || g._setTime(this.parent.timetravel, i), g._departureChanged(this.parent.timetravel.input.value, b)) : (b.timeTraveling = c.visible = !1, d.departure = null, nokia.mh5.components.Route.prototype.mode.button.onValueChange.apply(this, arguments))
                                    }
                                },
                                placeholder: {
                                    control: nokia.mh5.ui.Control,
                                    cssClass: "mh5_box-flex1",
                                    visible: !1
                                },
                                timetravel: {
                                    control: nokia.mh5.ui.Container,
                                    layout: {
                                        type: nokia.mh5.ui.ColumnLayout,
                                        align: "stretch"
                                    },
                                    cssClass: "mh5_timeTravel mh5_box-flex1",
                                    children: ["day", "time", "input", "dayNav", "timeNav"],
                                    visible: !1,
                                    visibleDidChange: function(a) {
                                        this.parent.placeholder.visible = !a;
                                        this.constructor.prototype.visibleDidChange.call(this, a)
                                    },
                                    day: {
                                        control: nokia.mh5.ui.Button,
                                        cssClass: "mh5_Button mh5_trafficDaySelector",
                                        text: e,
                                        backToDefault: function() {
                                            g._setDay(this.parent, e);
                                            h = e;
                                            this.parent.dayNav.onChange()
                                        }
                                    },
                                    time: {
                                        control: nokia.mh5.ui.Button,
                                        cssClass: "mh5_Button mh5_trafficTimeSelector",
                                        text: g._currentTime(),
                                        backToDefault: function() {
                                            g._setTime(this.parent, i);
                                            this.parent.timeNav.onChange()
                                        }
                                    },
                                    input: {
                                        control: nokia.mh5.ui.TextInput,
                                        type: "datetime",
                                        cssClass: "mh5_dateTimePicker"
                                    },
                                    dayNav: {
                                        control: j,
                                        cssClass: "mh5_trafficDayNav mh5_timeTravelNav",
                                        items: g._days().map(function(a) {
                                            return {
                                                text: a
                                            }
                                        }),
                                        onChange: function() {
                                            var a = this.getRootOwnerByClass(nokia.mh5.ui.Page),
                                                b = h;
                                            h = this.root.value;
                                            var c = g._correctTimeSelectionAfterDayChanged(b, this.parent.timeNav.root.value, h);
                                            this.parent.timeNav.items = g._times(h).map(function(a) {
                                                return {
                                                    text: a,
                                                    selected: a === c
                                                }
                                            });
                                            g._setTime(this.parent, c);
                                            g._setDay(this.parent, h);
                                            g._departureChanged(this.parent.input.value, a)
                                        }
                                    },
                                    timeNav: {
                                        control: j,
                                        cssClass: "mh5_trafficTimeNav mh5_timeTravelNav",
                                        items: g._times(h).map(function(a) {
                                            return {
                                                text: a,
                                                selected: a === i
                                            }
                                        }),
                                        onChange: function() {
                                            var a = this.getRootOwnerByClass(nokia.mh5.ui.Page);
                                            g._setTime(this.parent, this.root.value);
                                            g._departureChanged(this.parent.input.value, a)
                                        }
                                    }
                                }
                            }
                        }
                    },
                    visibleDidChange: function(a, b) {
                        var c = this.header.route.mode.timetravel,
                            d = "drive" == this.model.parameters.mode;
                        c.visible = a && d;
                        !a && b && d && (c.day.backToDefault(), c.time.backToDefault());
                        nokia.mh5.app.commonLayout.route.visibleDidChange.call(this, a, b)
                    }
                }
            }
        };
    g.tablet = a();
    g.phone = a()
})();
nokia.mh5.provide("nokia.mh5.maps.adapters.Ad");
(function() {
    function g(a) {
        var c, e, g, h;
        for (e = 0, h = a.length; e < h; e++) {
            var d = a[e];
            c = d.storefronts[0];
            d.isAd = !0;
            d.placeId = c.detail.placeID;
            d.name = d.adv;
            delete d.adv;
            g = c.location;
            d.latitude = g.position[0];
            d.longitude = g.position[1];
            d.phone = c.contacts.phone;
            d.website = c.contacts.weburl;
            d.storefrontid = c.detail.storefrontid;
            delete d.storefronts
        }
        return a
    }
    var a = {
        sver: "1.2",
        output: "json",
        id: nokia.mh5.components.settings.get("userId"),
        pub: "NOKIA-HTML5MAPS-PLAT",
        app: "MH5",
        seed: "rifkdjru4561wpqzc",
        token: "23 8 158 167 154 23 159 48 151 240 9 130 124 240 205 196 202 195 187 99"
    };
    nokia.mh5.maps.adapters.Ad = {
        search: function(b, c, e) {
            var i = {
                maxads: b.maxads || "1"
            };
            nokia.mh5.extend(i, a);
            if (b.box) {
                var h = b.box;
                i.rtype = "area";
                i.area = "poly";
                i.plon = [h[0].longitude, h[0].longitude, h[1].longitude, h[1].longitude].join();
                i.plat = [h[0].latitude, h[1].latitude, h[1].latitude, h[0].latitude].join();
                i.lon = b.center.longitude;
                i.lat = b.center.latitude
            } else i.rtype = "place", i.places = b.placeId, i.lon = b.longitude, i.lat = b.latitude;
            nokia.mh5.jsonp("http://lcpapi.lpaweb.net/nmg/getList?" + nokia.mh5.utils.formatURLParams(i) + "&jsonp", function(a) {
                a.error ? e && e(a.error) : c(g(a.results))
            }, 1E4)
        },
        logAction: function(b, c, e, i) {
            var h = nokia.mh5.extend({}, b, a);
            if (!b.type) h.type = "INFO";
            b = new Date;
            h.time = b.getUTCFullYear() + "." + (b.getUTCMonth() + 1) + "." + b.getUTCDate() + "." + b.getUTCHours() + "." + b.getUTCMinutes() + "." + b.getUTCSeconds();
            h.lat = c.latitude;
            h.lon = c.longitude;
            h.cid = c.tid;
            h.sid = c.storefrontid;
            c = "http://lcpapi.lpaweb.net/nmg/logAction?" + nokia.mh5.utils.formatURLParams(h);
            nokia.mh5.jsonp(c + "&jsonp", function(a) {
                a.error ? i && i(a.error) : e && e(g(a.results))
            })
        }
    }
})();
nokia.mh5.provide("nokia.mh5.maps.components.Ad");
nokia.mh5.maps.components.Ad = new nokia.mh5.Class(function() {
    function g() {
        var a = new Image;
        i = nokia.mh5.doc.createElement("CANVAS");
        i.width = i.height = 40;
        a.onload = function() {
            i.getContext("2d").drawImage(a, 120, 40, 40, 40, 0, 0, 40, 40)
        };
        a.src = nokia.mh5.assetsPath + "img/iconsheet.png"
    }
    function a(a, c, e, f) {
        for (var g = b(a, c, f); e < g;) a = a.substr(0, a.length - 2) + "\u2026", g = b(a, c, f);
        return a
    }
    function b(a, b, c) {
        var e = c.font;
        c.font = b;
        a = c.measureText(a).width;
        c.font = e;
        return a
    }
    var c = nokia.mh5.event,
        e = 0,
        i;
    return {
        disabled: !1,
        adapter: nokia.mh5.maps.adapters.Ad,
        statics: {
            MIN_ZOOM_LEVEL: 12,
            UPDATE_DELAY: 1500,
            getPoiIcon: function(a, b, c) {
                return (a.assets.brand_icon || a.assets.cat_icon).replace(".png", "_" + ((b || "56") + "x" + (c || "56")) + ".png")
            }
        },
        constructor: function(a) {
            this._updateAds = this._updateAds.bind(this);
            this._logPoiClick = this._logPoiClick.bind(this);
            nokia.mh5.extend(this, a);
            nokia.mh5.ui.Control.watch(this, "map", this, this.mapDidChange);
            (a = a.listeners) && nokia.mh5.each(a, function(a, b) {
                c.add(this, b, a)
            }, this);
            this._adPois = [];
            g()
        },
        mapDidChange: function(a, b) {
            b && (c.remove(b, "ready", this._updateAds), c.remove(b._map, "mapmoveend", this._updateAds), c.remove(b._map, "mapzoomchange", this._updateAds), c.remove(a._map, "poiclick", this._logPoiClick));
            if (a) if (c.add(a._map, "mapmoveend", this._updateAds), c.add(a._map, "mapzoomchange", this._updateAds), c.add(a._map, "poiclick", this._logPoiClick), a.isReady) this._updateAds();
            else c.one(a, "ready", this._updateAds)
        },
        hideAdsOnMap: function() {
            this.map && 0 < this._adPois.length && this.map._map.removePoi(this._adPois)
        },
        showAdsOnMap: function() {
            this.map && 0 < this._adPois.length && this.map._map.addPoi(this._adPois)
        },
        _getInfoBubbleParams: function(a) {
            for (var b, e = 0, f = a.ctas.length; e < f; e++) {
                var g = a.ctas[e];
                if (g.event && "WEBURL" === g.event.toUpperCase()) {
                    b = g.data;
                    break
                }
            }
            var m = this;
            return {
                image: m._createInfoBubbleImage.bind(m, a),
                listeners: {
                    click: function(e) {
                        e.clickedPoint.x > (!m.map._map.retina ? this.poi.image.width / 2 - i.width - 40 : this.poi.image.width - i.width - 80) ? (m.adapter.logAction({
                            detail: "urlclick"
                        }, a), c.fire(m, "website", {
                            website: b
                        })) : (m.adapter.logAction({
                            detail: "unitclick"
                        }, a), c.fire(m, "details"))
                    }
                }
            }
        },
        _updateAds: function(a) {
            function b() {
                if (0 < f.infoBubbles.length) for (var a = 0; a < f.infoBubbles.length; a++) if (f.infoBubbles[a].data.isAd) return f.infoBubbles[a]
            }
            var c = this,
                f = c.map;
            e && nokia.mh5.win.clearTimeout(e);
            if (!c.disabled) if ((a && "mapzoomchange" === a.type ? a.data.newValue : f.zoom) < nokia.mh5.maps.components.Ad.MIN_ZOOM_LEVEL) {
                var a = b(),
                    g = c._adPois;
                a ? (g.splice(g.indexOf(a.poi), 1), c._adPois = [a.poi]) : c._adPois = [];
                f._map.removePoi(g)
            } else {
                var i = nokia.mh5.platform.tablet ? 6 : 3;
                e = nokia.mh5.win.setTimeout(function() {
                    e = 0;
                    c.adapter.search({
                        box: f.box,
                        center: f.center,
                        maxads: i
                    }, function(a) {
                        var g = c.ads = Array.isArray(a) ? a : [a];
                        if (!c.disabled) {
                            var h = (a = b()) ? a.data.placeId : null;
                            if (0 < c._adPois.length) {
                                for (var k = [], w = [], a = 0, v = c._adPois.length; a < v; a++) {
                                    var y = c._adPois[a];
                                    y.data.placeId !== h && !f.covers(y.data) ? k.push(y) : w.push(y)
                                }
                                c._adPois = w;
                                f._map.removePoi(k)
                            }
                            if (!e && g && f.zoom >= nokia.mh5.maps.components.Ad.MIN_ZOOM_LEVEL) for (var t = c._adPois, q = t.length, g = g.filter(function(a) {
                                if (h && h === a.placeId) return !1;
                                for (var b = 0; b < q; b++) if (t[b].data.placeId === a.placeId) return !1;
                                return !0
                            }), k = Math.min(i - t.length, g.length), a = 0; a < k; a++) w = g[a], w.categoryIcon = nokia.mh5.maps.components.Ad.getPoiIcon(w), v = f._map.createPoi(w.categoryIcon, w), v.retina = !0, v.data.infoBubbleParams = c._getInfoBubbleParams(w), c._adPois.push(v)
                        }
                    })
                }, nokia.mh5.maps.components.Ad.UPDATE_DELAY)
            }
        },
        _createInfoBubbleImage: function(c, d) {
            var e = document.createElement("CANVAS"),
                f = e.getContext("2d"),
                g = new Image,
                m = 2 * Math.max(this.map.size.width - 50, 245),
                n = 0,
                l = 0,
                o = 0,
                u, w, v;
            g.onload = g.onerror = function() {
                var y = 20,
                    t = m;
                g.width && g.height && (n += 20 + g.width, l += 40 + g.height);
                for (var q, s = 0, x = c.ctas.length; s < x; s++) {
                    var r = c.ctas[s];
                    if (r.event && "WEBURL" === r.event.toUpperCase()) {
                        q = r.data;
                        break
                    }
                }
                q && (n += 2, n += i.width + 80, l += 34);
                t -= n;
                c.name && (u = a(c.name, "bold 32px Arial", t, f), o = b(u, "bold 32px Arial", f));
                c.adcopy.intro_text && (w = a(c.adcopy.intro_text, "32px Arial", t, f), o = Math.max(o, b(w, "32px Arial", f)));
                c.source && (v = a(nokia.mh5.i18n("Ad.adBy") + " " + c.source, "24px Arial", t, f), o = Math.max(o, b(v, "24px Arial", f)));
                n += (o ? y + o : 0) + 40;
                e.width = n;
                e.height = l;
                g.width && g.height && (f.drawImage(g, 20, 20), y += 20 + g.width);
                f.textBaseline = "top";
                t = 20;
                if (u) f.font = "bold 32px Arial", f.fillStyle = "#FFF", f.fillText(u, y, t);
                t += 42;
                if (w) f.font = "32px Arial", f.fillStyle = "#FFF", f.fillText(w, y, t);
                t += 46;
                if (v) f.font = "24px Arial", f.fillStyle = "#F7941E", f.fillText(v, 20, t);
                if (q) q = y + o + 40, f.save(), f.beginPath(), f.lineWidth = 1, f.strokeStyle = "#FFFFFF", f.moveTo(q, 30), f.lineTo(q, e.height - 30), f.stroke(), f.closePath(), f.restore(), f.drawImage(i, y + o + 80, (l - i.height) / 2);
                d(e)
            };
            g.src = nokia.mh5.maps.components.Ad.getPoiIcon(c, 80, 80)
        },
        _logPoiClick: function(a) {
            a = a.data[0];
            a.data.isAd && !a.infoBubble && (this.adapter.logAction({
                detail: "markerclick"
            }, a.data), this.adapter.logAction({
                detail: "bubbleshown"
            }, a.data))
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.components.AdDetails");
nokia.mh5.maps.components.AdDetails = new nokia.mh5.Class(nokia.mh5.ui.Control, function() {
    return {
        cssClass: "mh5_AdDetails mh5_link",
        rootHtmlElementName: "a",
        children: ["details"],
        ad: null,
        adDidChange: function(g) {
            var a = "",
                b;
            if (g) {
                a = "<div class='mh5_AdContent'>";
                g.assets.main_image && (a += "<img class='mh5_AdImage' src=" + g.assets.main_image + " />");
                for (var a = a + "<div class='mh5_AdText'>" + (g.adcopy.main_text || ""), c, e = 0, i = g.ctas.length; e < i; e++) if (c = g.ctas[e], c.event && "WEBURL" === c.event.toUpperCase()) {
                    b = c.data;
                    a += "<p>" + c.text + "</p>";
                    break
                }
                a += "</div></div>"
            }
            b ? (this.root.href = b, this.root.target = "_blank") : (this.root.removeAttribute("href"), this.root.removeAttribute("target"));
            this.root.innerHTML = a
        },
        onClick: function(g) {
            (!g || !g._fake) && nokia.mh5.maps.adapters.Ad.logAction({
                detail: "unitclick"
            }, this.ad);
            g._fake && (g.preventDefault(), g.stopPropagation())
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.SearchPage");
(function() {
    var g = nokia.mh5.app;
    nokia.mh5.maps.SearchPage = {
        transitionBetweenDetails: !0,
        build: function() {
            var a = this;
            g[g.layoutName].search.build.apply(this, arguments);
            if (nokia.mh5.maps.features.ads) this.ad = new nokia.mh5.maps.components.Ad({
                map: a.map,
                listeners: {
                    website: function(a) {
                        var c = document.createElement("a"),
                            e = document.createEvent("MouseEvent");
                        c.target = "_blank";
                        c.href = a.data.website;
                        e.initEvent("click", !0, !0);
                        c.dispatchEvent(e)
                    },
                    details: function() {
                        a.map.infoBubbleParams.listeners.click.call(a.map.infoBubbles[0])
                    }
                }
            })
        },
        header: {
            control: nokia.mh5.maps.Header,
            children: ["search", "spring"],
            search: {
                input: {
                    listeners: {
                        focus: function() {
                            var a = this.parent.parent;
                            a.spring.visible = !1;
                            a.back.visible = !1
                        },
                        blur: function() {
                            var a = this.parent.parent;
                            a.spring.visible = !0;
                            a.back.visible = 0 < nokia.mh5.history.position
                        }
                    }
                }
            }
        },
        map: {
            traffic: !0
        },
        details: {
            actions: {
                collect: !nokia.mh5.platform.wphone
            },
            customContent: [].concat(g.commonLayout.search.details.customContent, {
                name: "ad",
                control: nokia.mh5.maps.components.AdDetails,
                visible: !1,
                before: "summary"
            }),
            listeners: {
                update: function(a) {
                    var b = a.data;
                    this.ad.visible = b.isAd;
                    var c = this;
                    b.isAd ? this.ad.ad = b : nokia.mh5.maps.features.ads && nokia.mh5.maps.adapters.Ad.search(b, function(a) {
                        if (0 < a.length && c.place === b) c.ad.ad = a[0], c.ad.visible = !0
                    })
                },
                dial: function(a) {
                    a.data.isAd && nokia.mh5.maps.adapters.Ad.logAction({
                        detail: "clicktocall"
                    }, a.data);
                    g[g.layoutName].search.details.listeners.dial.apply(this, arguments)
                },
                share: function(a) {
                    a.data.isAd && nokia.mh5.maps.adapters.Ad.logAction({
                        detail: "share"
                    }, a.data);
                    g[g.layoutName].search.details.listeners.share.apply(this, arguments)
                },
                route: function(a) {
                    a.data.isAd && nokia.mh5.maps.adapters.Ad.logAction({
                        detail: "clicktoroute"
                    }, a.data);
                    g[g.layoutName].search.details.listeners.route.apply(this, arguments)
                },
                collect: function(a) {
                    nokia.mh5.sso.isAuthenticated() ? g.controller.switchTo("favouriteManage", {
                        place: a.data
                    }) : g.controller.switchTo("collectionList", {
                        lazy: a.data
                    });
                    a.data.isAd && nokia.mh5.maps.adapters.Ad.logAction({
                        detail: "favorite"
                    }, a.data);
                    g[g.layoutName].search.details.listeners.collect.apply(this, arguments)
                }
            },
            visibleDidChange: function(a) {
                if (this.parent.ad) this.parent.ad.disabled = a, this.parent.ad[a ? "hideAdsOnMap" : "showAdsOnMap"]();
                g[g.layoutName].search.details.visibleDidChange.apply(this, arguments)
            }
        },
        getHash: function() {
            var a = {},
                b = this.model.selection;
            if (b && !b.incident) b.placeId ? a.placeId = b.placeId : (a.latitude = b.latitude, a.longitude = b.longitude, a.address = b.address);
            if (this.model.query) a.query = this.model.query, a.slatitude = this.model.searchCenter.latitude, a.slongitude = this.model.searchCenter.longitude;
            return JSON.stringify(a)
        }
    }
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.maps.SearchPageTabletLayout");
nokia.mh5.maps.SearchPageTabletLayout = nokia.mh5.extend({}, nokia.mh5.maps.SearchPage);
nokia.mh5.extendDeep(nokia.mh5.maps.SearchPageTabletLayout, {
    header: {
        children: ["back", "brandLogo", "search", "fillup", "spring"]
    }
});
nokia.mh5.provide("nokia.mh5.maps.SearchPagePhoneLayout");
nokia.mh5.maps.SearchPagePhoneLayout = nokia.mh5.extend({}, nokia.mh5.maps.SearchPage);
nokia.mh5.extendDeep(nokia.mh5.maps.SearchPagePhoneLayout, {
    header: {
        children: ["back", "search", "toggle", "spring"]
    }
});
nokia.mh5.provide("nokia.mh5.maps.RoutePage");
(function() {
    var g = nokia.mh5.dom.addEvent,
        a = nokia.mh5.dom.removeEvent,
        b = nokia.mh5.components.settings,
        c = function() {
            return {
                input: {
                    listeners: {
                        blur: function() {
                            var b = this.getRootOwnerByClass(nokia.mh5.ui.Page),
                                c = b.header.route;
                            c.mode.timetravel.visible = "drive" === c.parameters.mode;
                            a(b.map.root, "down", this._springBlurBound, !0);
                            a(b.maneuversContainer.root, "down", this._springBlurBound, !0)
                        },
                        focus: function() {
                            var a = this.getRootOwnerByClass(nokia.mh5.ui.Page),
                                b = a.header,
                                c = b.spring,
                                e = b.route,
                                i = e.mode.timetravel;
                            b.back.visible = c.visible = i.visible = !1;
                            this._springBlurBound = this._springBlurBound ||
                            function() {
                                c.visible = !0;
                                b.back.visible = 0 < nokia.mh5.history.position;
                                i.visible = "drive" === e.parameters.mode
                            };
                            g(a.map.root, "down", this._springBlurBound, !0);
                            g(a.maneuversContainer.root, "down", this._springBlurBound, !0)
                        }
                    }
                },
                listeners: {
                    beforesearch: function(a) {
                        if (a.data.query === nokia.mh5.i18n("currentLocation") || !b.get("isOnline")) this.parent.parent.parent.spring.visible = !0, this.parent.parent.parent.back.visible = 0 < nokia.mh5.history.position
                    },
                    clear: function() {
                        this.parent.parent.parent.spring.visible = !0;
                        this.parent.parent.parent.back.visible = 0 < nokia.mh5.history.position
                    },
                    success: function(a) {
                        var b = this.getRootOwnerByClass(nokia.mh5.ui.Page).header;
                        if (0 === a.data.results.length) b.spring.visible = !0, b.back.visible = 0 < nokia.mh5.history.position, b.route.mode.timetravel.visible = "drive" === b.route.parameters.mode
                    },
                    error: function() {
                        this.parent.parent.parent.spring.visible = !0;
                        this.parent.parent.parent.back.visible = 0 < nokia.mh5.history.position
                    }
                }
            }
        },
        e = {
            listeners: {
                tap: function() {
                    var a = this.parent;
                    a.mode.timetravel.visible = "drive" === a.parent.parent.model.parameters.mode
                }
            },
            visibleDidChange: function(a) {
                if (!a) this.getRootOwnerByClass(nokia.mh5.ui.Page).header.spring.visible = !0;
                nokia.mh5.app.commonLayout.route.header.route.fromList.visibleDidChange.apply(this, arguments)
            }
        },
        i = function() {
            this.mode.timetravel.visible = "drive" === this.parameters.mode
        },
        i = {
            clear: i,
            success: i,
            error: i
        };
    nokia.mh5.maps.RoutePage = {
        build: function() {
            var a = this,
                b = nokia.mh5.app;
            b[b.layoutName].route.build.apply(this, arguments);
            if (nokia.mh5.maps.features.ads) this.ad = new nokia.mh5.maps.components.Ad({
                map: a.map,
                listeners: {
                    website: function(a) {
                        var b = document.createElement("a"),
                            c = document.createEvent("MouseEvent");
                        b.target = "_blank";
                        b.href = a.data.website;
                        c.initEvent("click", !0, !0);
                        b.dispatchEvent(c)
                    },
                    details: function() {
                        for (var b, c = 0; c < a.map.infoBubbles.length; c++) if (b = a.map.infoBubbles[c], b.data.isAd) {
                            a.map.infoBubbleParams.listeners.click.call(b);
                            break
                        }
                    }
                }
            })
        },
        header: {
            control: nokia.mh5.maps.Header,
            children: ["back", "route", "spring"],
            route: {
                inputs: {
                    children: ["from", "to"],
                    from: c(),
                    to: c()
                },
                fromList: e,
                toList: e
            },
            listeners: i
        },
        map: {
            traffic: !0
        },
        getHash: function() {
            var a = this.model.from,
                b = this.model.to,
                c = {
                    mode: this.model.parameters.mode
                };
            if (a && a.latitude && a.longitude && a.hasOwnProperty("name")) c.sname = a.name, c.slat = a.latitude, c.slng = a.longitude, c.sPlaceId = a.placeId;
            if (b && b.latitude && b.longitude) c.ename = b.name, c.elat = b.latitude, c.elng = b.longitude, c.ePlaceId = b.placeId;
            return JSON.stringify(c)
        }
    }
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.maps.features");
(function(g) {
    g.features = {};
    var a = nokia.mh5.win.location.search;
    0 < a.length && (a = a.substring(1));
    var b = a.split("&");
    nokia.mh5.each({
        ads: !1
    }, function(a, e) {
        Object.defineProperty(g.features, e, {
            get: function() {
                return a || -1 < b.indexOf(e + "=true")
            },
            enumerable: !0
        })
    })
})(nokia.mh5.maps);
nokia.mh5.provide("nokia.mh5.maps.Application");
(function() {
    nokia.mh5.maps.embed = function(g) {
        var a = nokia.mh5,
            b;
        b = !a.utils.getLocalStorageValue("mh5-isFirstTime");
        var c = function(b) {
                var c = [],
                    g = a.app.controller && a.app.controller.current && a.app.controller.current.page;
                if ("timeout" !== b.error && (c = b.recommendations)) a.components.favourites.favouritize(c), c.sort(function(a, b) {
                    return a.distance - b.distance
                }), c.forEach(function(a) {
                    if (a.placeId) a.id = a.placeId
                }), g.list.items = g.model.data = c, g.header.toggle ? g.header.toggle.visible = !0 : g.list.visible = !0
            };
        a.utils.setLocalStorageValue("mh5-isFirstTime", b + "");
        b && a.l10n.imperial[a.platform.language.substr(-2)] && nokia.mh5.components.settings.set("unitSystem", "mi");
        if ((!g.startParams || 0 === Object.keys(g.startParams).length) && nokia.mh5.platform.tablet) a.event.one(a.geolocation, "positionactivate", function(b) {
            var g = a.app.controller && a.app.controller.current && a.app.controller.current.page,
                h = g && g.map,
                b = b.data.coords,
                b = {
                    latitude: b.latitude,
                    longitude: b.longitude
                },
                d;
            if (g && !("search" !== a.app.controller.current.name || g.model.query)) a.event.one(g.header.search, "beforesearch", function() {
                d && d.cancel();
                nokia.mh5.components.Traffic.removeNonTrafficPois(h)
            }), h.zoom = nokia.mh5.components.Map.MAX_ZOOM_LEVEL - 4, h.moveTo(b), d = a.adapters.Search.getRecommendations(b, {
                init: !0
            }, c)
        });
        nokia.mh5.event.add(nokia.mh5.history, "historypositionchange", function(b) {
            if (a.app.controller.current.page.header && a.app.controller.current.page.header.back) a.app.controller.current.page.header.back.visible = 0 < b.data.position
        });
        b = {
            appId: "laGAr6nRKF9kgw3Wj_cA",
            appCode: "JK2oJ1CPsvhfZWX-KpbrWw",
            phoneLayout: {
                search: nokia.mh5.maps.SearchPagePhoneLayout,
                route: nokia.mh5.maps.RoutePage,
                favourites: {
                    layout: {
                        type: nokia.mh5.ui.RowLayout
                    },
                    children: ["header", "favourites"],
                    header: {
                        control: nokia.mh5.maps.Header
                    }
                }
            },
            tabletLayout: {
                search: nokia.mh5.maps.SearchPageTabletLayout,
                route: nokia.mh5.maps.RoutePage,
                favourites: {
                    layout: {
                        type: nokia.mh5.ui.RowLayout
                    },
                    children: ["header", "favourites"],
                    header: {
                        control: nokia.mh5.maps.Header
                    }
                }
            }
        };
        a.extendDeep(b.tabletLayout, nokia.mh5.maps.traffic.tablet);
        a.extendDeep(b.phoneLayout, nokia.mh5.maps.traffic.phone);
        a.extendDeep(b, g);
        return a.app.embed(b)
    }
})(nokia.mh5.win);
nokia.mh5.provide("nokia.mh5.maps.BookmarkPrompt");
nokia.mh5.maps.BookmarkPrompt = new nokia.mh5.Class(nokia.mh5.ui.Dialog, function(g) {
    var a = nokia.mh5.i18n;
    return {
        control: nokia.mh5.ui.Container,
        cssClass: "mh5_modal mh5_BookmarkPrompt",
        children: ["content", "tail"],
        withoutAnimation: !0,
        content: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_BookmarkPromptContainer",
            children: ["settingsHeader", "image", "text"],
            settingsHeader: {
                control: nokia.mh5.ui.Container,
                cssClass: "mh5_SettingsHeader",
                children: ["settingsTitle", "closeButton"],
                settingsTitle: {
                    control: nokia.mh5.ui.Control,
                    rootHtmlElementName: "h6",
                    cssClass: "mh5_title",
                    innerHTML: "HERE"
                },
                closeButton: {
                    control: nokia.mh5.ui.Control,
                    cssClass: "mh5_DialogClose"
                }
            },
            image: {
                control: nokia.mh5.ui.Container,
                cssClass: "mh5_bookmarkImage"
            },
            text: {
                control: nokia.mh5.ui.Container,
                cssClass: "mh5_bookmarkText"
            }
        },
        tail: {
            control: nokia.mh5.ui.Container,
            cssClass: "mh5_BookmarkPromptTail",
            visible: !1
        },
        allowScrolling: !0,
        closeOnTap: !0,
        _closeDialog: function() {
            this.visible && this.close()
        },
        close: function() {
            var a = nokia.mh5.dom.removeEvent;
            a(nokia.mh5.doc.body, nokia.mh5.dom.touchStart, this.close, !0);
            this.visible = !1
        },
        update: function() {
            if (bookmark) bookmark = !1, this.close = this.close.bind(this), nokia.mh5.dom.addEvent(nokia.mh5.doc.body, nokia.mh5.dom.touchStart, this.close, !0), this._updatePosition()
        },
        _updatePosition: function() {
            g._updatePosition.call(this);
            var b = nokia.mh5.platform,
                c = nokia.mh5.win.orientation,
                c = "undefined" === typeof c || 0 === c || 180 === c,
                e = b.blackberry ? 30 : b.iphone || b.ipod ? 50 : 0,
                i = a("maps.BP.bookmark"),
                h = a("maps.BP.below");
            b.ios ? (b.ipad && (h = a("maps.BP.above"), e = b.ios.io4 ? c ? 27 : 20.25 : c ? 21 : 16, nokia.mh5.dom.addClass(this.root, "mh5_ipad")), i = a("maps.BP.install", {
                dir: h
            })) : b.firefox && nokia.mh5.dom.addClass(this.root, "mh5_firefox");
            this.content.text.root.innerHTML = i;
            this.tail.root.style.left = nokia.mh5.dom.dimensions(nokia.mh5.win).width * e / 100 - 10 + "px";
            this.tail.visible = !! e
        },
        visibleDidChange: function(a) {
            g.visibleDidChange.call(this, a);
            a && delete nokia.mh5.history.catchNextOnPopState
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.adapters.NPS");
(function() {
    nokia.mh5.maps.adapters.NPS = {
        submit: function(g, a) {
            var b = {
                version: "2.0",
                crnd: Math.random()
            };
            nokia.mh5.extend(b, g);
            b = "http://m.here.com/releases/1.8.44/server/nps.php?" + nokia.mh5.utils.formatURLParams(b) + "&jsonp";
            nokia.mh5.jsonp(b, function(b) {
                b && b.error ? a("error") : b && -1 !== b.indexOf("<status>OK</status>") ? a("loaded") : a("error")
            })
        }
    }
})();
nokia.mh5.provide("nokia.mh5.maps.components.NPS");
nokia.mh5.maps.components.NPS = new nokia.mh5.Class(nokia.mh5.ui.Container, function(g) {
    var a = nokia.mh5.i18n,
        b = nokia.mh5.dom,
        c = nokia.mh5.ui,
        e = nokia.mh5.utils,
        i = c.Control,
        h = c.Container,
        d = nokia.mh5.event,
        j = function() {
            var a = new Date;
            return a.getFullYear() + "-" + (1 + a.getMonth()) + "-" + a.getDate()
        };
    return {
        children: "title,question,rating,feedbackLabel,feedback,email,privacyNotice,buttonContainer".split(","),
        layout: {
            type: c.RowLayout
        },
        cssClass: "mh5_NPS",
        title: {
            control: i,
            cssClass: "mh5_title",
            rootHtmlElementName: "h1",
            innerHTML: a("feedback")
        },
        question: {
            control: i,
            rootHtmlElementName: "label"
        },
        rating: {
            control: h,
            children: ["buttons", "labels"],
            layout: {
                type: c.RowLayout
            },
            buttons: {
                control: i,
                cssClass: "mh5_SliderButton mh5_ColumnLayout",
                index: -1,
                innerHTML: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(function(a) {
                    return "<span><span>" + a + "</span></span>"
                }).join("\n")
            },
            labels: {
                control: i,
                innerHTML: "<div><span>" + a("maps.NPS.notLikely") + "</span><span>" + a("maps.NPS.extremelyLikely") + "</span></div>"
            }
        },
        feedbackLabel: {
            control: i,
            rootHtmlElementName: "label",
            innerHTML: a("maps.NPS.why")
        },
        feedback: {
            control: c.TextArea,
            rows: 3,
            placeholder: a("maps.NPS.enterMessage")
        },
        email: {
            control: h,
            children: ["checkbox", "input"],
            cssClass: "mh5_NPSContact",
            checkbox: {
                control: i,
                rootHtmlElementName: "label",
                innerHTML: a("maps.NPS.contact"),
                onClick: function() {
                    var a = this.parent.input;
                    b[a.visible ? "removeClass" : "addClass"](this.root, "selected");
                    a.visible = !a.visible
                }
            },
            input: {
                control: c.TextInput,
                placeholder: a("maps.NPS.email"),
                type: "email",
                visible: !1
            }
        },
        privacyNotice: {
            control: i,
            rootHtmlElementName: "label",
            innerHTML: a("maps.NPS.NPP")
        },
        buttonContainer: {
            control: h,
            cssClass: "mh5_buttonContainer mh5_right",
            children: ["submitButton"],
            submitButton: {
                control: c.Button,
                text: a("send"),
                cssClass: "mh5_Button mh5_textButton",
                disabled: !0,
                onClick: function() {
                    var a = nokia.mh5.geolocation,
                        b = this.parent.parent,
                        c = b.email.input,
                        e = c.value,
                        g = {
                            rec: b.rating.buttons.index,
                            "fb-text": b.feedback.value,
                            projid: b.projId
                        },
                        h = function() {
                            nokia.mh5.maps.adapters.NPS.submit(g, b._onReportSent.bind(b))
                        };
                    if (!this.disabled) {
                        if (c.visible && e && ~e.indexOf("@")) g.email = e;
                        this.disabled = !0;
                        d.fire(b, "beforesend", {
                            recommendation: b.rating.buttons.index,
                            feedback: b.feedback.value,
                            email: b.email.input.value
                        }).defaultPrevented || (a.available ? nokia.mh5.adapters.Search.reverseGeoCode(a.coords, null, function(a) {
                            a = a.properties;
                            if (a.Country) g.country = a.Country;
                            if (a.City) g.city = a.City;
                            h()
                        }, h) : h())
                    }
                }
            }
        },
        sentAt: function() {
            return e.getLocalStorageValue(this.localStorageKey)
        },
        build: function() {
            if (!this.hasOwnProperty("projId")) throw Error("projId required");
            var a = this.rating.buttons.root,
                c = this._handler.bind(this);
            this.localStorageKey = this.localStorageKey || "feedback-provided";
            d.add(a, b.touchStart, c);
            d.add(a, b.touchMove, c);
            d.add(a, b.touchEnd, c);
            g.build.call(this)
        },
        reset: function() {
            e.setLocalStorageValue(this.localStorageKey)
        },
        _onReportSent: function(b) {
            var c = this.buttonContainer.submitButton;
            if ("loaded" === b) e.setLocalStorageValue(this.localStorageKey, j()), d.fire(this, "success", {
                recommendation: this.rating.buttons.index,
                feedback: this.feedback.value,
                email: this.email.input.value
            });
            else if ("error" === b) c.text = a("retry"), c.disabled = !1, d.fire(this, "error")
        },
        _handler: function(a) {
            if (this.sentAt() !== j()) for (var c = this.rating.buttons, d = 0, e = c.root.children, g = e.length; d < g; d++) if (b.contains(e[d], a.target) && d !== c.index) {
                -1 !== c.index && (b.removeClass(e[c.index], "selected"), b.removeClass(e[c.index].firstChild, "mh5_primaryBackgroundColorDark"));
                b.addClass(e[d], "selected");
                b.addClass(e[d].firstChild, "mh5_primaryBackgroundColorDark");
                c.index = d;
                this.buttonContainer.submitButton.disabled = !1;
                break
            }
        }
    }
});
nokia.mh5.provide("nokia.mh5.maps.NPSPage");
nokia.mh5.maps.NPSPage = new nokia.mh5.Class(nokia.mh5.ui.Page, function(g) {
    var a = nokia.mh5.i18n,
        b = nokia.mh5.maps.analytics,
        c = nokia.mh5.ui.Notification,
        e = nokia.mh5.platform;
    return {
        children: ["header", "nps", "notification"],
        cssClass: "mh5_Page mh5_NPSPage mh5_primaryColorBright",
        layout: {
            type: nokia.mh5.ui.RowLayout
        },
        header: {
            control: nokia.mh5.maps.Header,
            title: nokia.mh5.maps.components.NPS.prototype.title.innerHTML
        },
        nps: {
            control: nokia.mh5.maps.components.NPS,
            title: {
                visible: !1
            },
            question: {
                innerHTML: a("maps.NPS.recommend")
            },
            localStorageKey: "feedback-provided1.8",
            projId: function() {
                var a = 2011;
                e.android_webview && (a = 2153);
                e.ios_webview && (a = 2170);
                return a
            }(),
            listeners: {
                beforesend: function() {
                    var b = this.parent.notification;
                    b.text = a("sending") + "...";
                    b.timeout = c.TIMEOUT_INFINITY;
                    b.visible = !0
                },
                success: function(e) {
                    var g = this.parent.notification,
                        e = e.data.recommendation;
                    g.text = a("thankYou");
                    g.visible = !0;
                    b.log({
                        gn: "nps:sent",
                        c32: "sent",
                        v32: "~c32",
                        ev: "event8" + (6 >= e ? ",event28" : 9 <= e ? ",event29" : "")
                    });
                    nokia.mh5.win.setTimeout(function() {
                        nokia.mh5.app.controller.back()
                    }, c.TIMEOUT_DEFAULT)
                },
                error: function() {
                    var b = this.parent.notification;
                    b.text = a("maps.NPS.noSend");
                    b.timeout = c.TIMEOUT_DEFAULT;
                    b.visible = !0
                }
            }
        },
        notification: {
            control: c,
            visible: !1
        },
        visibleDidChange: function(a) {
            b.logIfVisible(this, {
                gn: "nps"
            });
            g.visibleDidChange.call(this, a)
        }
    }
});
var mappings = {
    search: "search",
    details: "search",
    route: "route",
    collections: "collectionList"
};
(function(g, a) {
    function b(a) {
        if ("" === i) return a;
        a = a.charAt(0).toUpperCase() + a.substr(1);
        return i + a
    }
    var c = Math,
        e = a.createElement("div").style,
        i = function() {
            for (var a = "t,webkitT,MozT,msT,OT".split(","), b, c = 0, d = a.length; c < d; c++) if (b = a[c] + "ransform", b in e) return a[c].substr(0, a[c].length - 1);
            return !1
        }(),
        h = i ? "-" + i.toLowerCase() + "-" : "",
        d = b("transform"),
        j = b("transitionProperty"),
        f = b("transitionDuration"),
        k = b("transformOrigin"),
        m = b("transitionTimingFunction"),
        n = b("transitionDelay"),
        l = /android/gi.test(navigator.appVersion),
        o = /iphone|ipad/gi.test(navigator.appVersion),
        u = /hp-tablet/gi.test(navigator.appVersion),
        w = b("perspective") in e,
        v = "ontouchstart" in g && !u,
        y = !! i,
        t = b("transition") in e,
        q = "onorientationchange" in g ? "orientationchange" : "resize",
        s = v ? "touchstart" : "mousedown",
        x = v ? "touchmove" : "mousemove",
        r = v ? "touchend" : "mouseup",
        J = v ? "touchcancel" : "mouseup",
        F = "Moz" == i ? "DOMMouseScroll" : "mousewheel",
        H;
    H = !1 === i ? !1 : {
        "": "transitionend",
        webkit: "webkitTransitionEnd",
        Moz: "transitionend",
        O: "otransitionend",
        ms: "MSTransitionEnd"
    }[i];
    var B = function() {
            return g.requestAnimationFrame || g.webkitRequestAnimationFrame || g.mozRequestAnimationFrame || g.oRequestAnimationFrame || g.msRequestAnimationFrame ||
            function(a) {
                return setTimeout(a, 1)
            }
        }(),
        D = g.cancelRequestAnimationFrame || g.webkitCancelAnimationFrame || g.webkitCancelRequestAnimationFrame || g.mozCancelRequestAnimationFrame || g.oCancelRequestAnimationFrame || g.msCancelRequestAnimationFrame || clearTimeout,
        z = w ? " translateZ(0)" : "",
        u = function(b, c) {
            var e = this,
                i;
            e.wrapper = "object" == typeof b ? b : a.getElementById(b);
            e.wrapper.style.overflow = "hidden";
            e.scroller = e.wrapper.children[0];
            e.options = {
                hScroll: !0,
                vScroll: !0,
                x: 0,
                y: 0,
                bounce: !0,
                bounceLock: !1,
                momentum: !0,
                lockDirection: !0,
                useTransform: !0,
                useTransition: !1,
                topOffset: 0,
                checkDOMChanges: !1,
                handleClick: !0,
                hScrollbar: !0,
                vScrollbar: !0,
                fixedScrollbar: l,
                hideScrollbar: o,
                fadeScrollbar: o && w,
                scrollbarClass: "",
                zoom: !1,
                zoomMin: 1,
                zoomMax: 4,
                doubleTapZoom: 2,
                wheelAction: "scroll",
                snap: !1,
                snapThreshold: 1,
                onRefresh: null,
                onBeforeScrollStart: function(a) {
                    a.preventDefault()
                },
                onScrollStart: null,
                onBeforeScrollMove: null,
                onScrollMove: null,
                onBeforeScrollEnd: null,
                onScrollEnd: null,
                onTouchEnd: null,
                onDestroy: null,
                onZoomStart: null,
                onZoom: null,
                onZoomEnd: null
            };
            for (i in c) e.options[i] = c[i];
            e.x = e.options.x;
            e.y = e.options.y;
            e.options.useTransform = y && e.options.useTransform;
            e.options.hScrollbar = e.options.hScroll && e.options.hScrollbar;
            e.options.vScrollbar = e.options.vScroll && e.options.vScrollbar;
            e.options.zoom = e.options.useTransform && e.options.zoom;
            e.options.useTransition = t && e.options.useTransition;
            e.options.zoom && l && (z = "");
            e.scroller.style[j] = e.options.useTransform ? h + "transform" : "top left";
            e.scroller.style[f] = "0";
            e.scroller.style[k] = "0 0";
            e.options.useTransition && (e.scroller.style[m] = "cubic-bezier(0.33,0.66,0.66,1)");
            e.options.useTransform ? e.scroller.style[d] = "translate(" + e.x + "px," + e.y + "px)" + z : e.scroller.style.cssText += ";position:absolute;top:" + e.y + "px;left:" + e.x + "px";
            if (e.options.useTransition) e.options.fixedScrollbar = !0;
            e.refresh();
            e._bind(q, g);
            e._bind(s);
            v || "none" != e.options.wheelAction && e._bind(F);
            if (e.options.checkDOMChanges) e.checkDOMTime = setInterval(function() {
                e._checkDOMChanges()
            }, 500)
        };
    u.prototype = {
        enabled: !0,
        x: 0,
        y: 0,
        steps: [],
        scale: 1,
        currPageX: 0,
        currPageY: 0,
        pagesX: [],
        pagesY: [],
        aniTime: null,
        wheelZoomCount: 0,
        handleEvent: function(a) {
            switch (a.type) {
            case s:
                if (!v && 0 !== a.button) break;
                this._start(a);
                break;
            case x:
                this._move(a);
                break;
            case r:
            case J:
                this._end(a);
                break;
            case q:
                this._resize();
                break;
            case F:
                this._wheel(a);
                break;
            case H:
                this._transitionEnd(a)
            }
        },
        _checkDOMChanges: function() {
            !this.moved && !this.zoomed && !(this.animating || this.scrollerW == this.scroller.offsetWidth * this.scale && this.scrollerH == this.scroller.offsetHeight * this.scale) && this.refresh()
        },
        _scrollbar: function(b) {
            var e;
            if (this[b + "Scrollbar"]) {
                if (!this[b + "ScrollbarWrapper"]) {
                    e = a.createElement("div");
                    this.options.scrollbarClass ? e.className = this.options.scrollbarClass + b.toUpperCase() : e.style.cssText = "position:absolute;z-index:100;" + ("h" == b ? "height:7px;bottom:1px;left:2px;right:" + (this.vScrollbar ? "7" : "2") + "px" : "width:7px;bottom:" + (this.hScrollbar ? "7" : "2") + "px;top:2px;right:1px");
                    e.style.cssText += ";pointer-events:none;" + h + "transition-property:opacity;" + h + "transition-duration:" + (this.options.fadeScrollbar ? "350ms" : "0") + ";overflow:hidden;opacity:" + (this.options.hideScrollbar ? "0" : "1");
                    this.wrapper.appendChild(e);
                    this[b + "ScrollbarWrapper"] = e;
                    e = a.createElement("div");
                    if (!this.options.scrollbarClass) e.style.cssText = "position:absolute;z-index:100;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);" + h + "background-clip:padding-box;" + h + "box-sizing:border-box;" + ("h" == b ? "height:100%" : "width:100%") + ";" + h + "border-radius:3px;border-radius:3px";
                    e.style.cssText += ";pointer-events:none;" + h + "transition-property:" + h + "transform;" + h + "transition-timing-function:cubic-bezier(0.33,0.66,0.66,1);" + h + "transition-duration:0;" + h + "transform: translate(0,0)" + z;
                    this.options.useTransition && (e.style.cssText += ";" + h + "transition-timing-function:cubic-bezier(0.33,0.66,0.66,1)");
                    this[b + "ScrollbarWrapper"].appendChild(e);
                    this[b + "ScrollbarIndicator"] = e
                }
                "h" == b ? (this.hScrollbarSize = this.hScrollbarWrapper.clientWidth, this.hScrollbarIndicatorSize = c.max(c.round(this.hScrollbarSize * this.hScrollbarSize / this.scrollerW), 8), this.hScrollbarIndicator.style.width = this.hScrollbarIndicatorSize + "px", this.hScrollbarMaxScroll = this.hScrollbarSize - this.hScrollbarIndicatorSize, this.hScrollbarProp = this.hScrollbarMaxScroll / this.maxScrollX) : (this.vScrollbarSize = this.vScrollbarWrapper.clientHeight, this.vScrollbarIndicatorSize = c.max(c.round(this.vScrollbarSize * this.vScrollbarSize / this.scrollerH), 8), this.vScrollbarIndicator.style.height = this.vScrollbarIndicatorSize + "px", this.vScrollbarMaxScroll = this.vScrollbarSize - this.vScrollbarIndicatorSize, this.vScrollbarProp = this.vScrollbarMaxScroll / this.maxScrollY);
                this._scrollbarPos(b, !0)
            } else this[b + "ScrollbarWrapper"] && (y && (this[b + "ScrollbarIndicator"].style[d] = ""), this[b + "ScrollbarWrapper"].parentNode.removeChild(this[b + "ScrollbarWrapper"]), this[b + "ScrollbarWrapper"] = null, this[b + "ScrollbarIndicator"] = null)
        },
        _resize: function() {
            var a = this;
            setTimeout(function() {
                a.refresh()
            }, l ? 200 : 0)
        },
        _pos: function(a, b) {
            if (!this.zoomed) a = this.hScroll ? a : 0, b = this.vScroll ? b : 0, this.options.useTransform ? this.scroller.style[d] = "translate(" + a + "px," + b + "px) scale(" + this.scale + ")" + z : (a = c.round(a), b = c.round(b), this.scroller.style.left = a + "px", this.scroller.style.top = b + "px"), this.x = a, this.y = b, this._scrollbarPos("h"), this._scrollbarPos("v")
        },
        _scrollbarPos: function(a, b) {
            var e = "h" == a ? this.x : this.y;
            if (this[a + "Scrollbar"]) e *= this[a + "ScrollbarProp"], 0 > e ? (this.options.fixedScrollbar || (e = this[a + "ScrollbarIndicatorSize"] + c.round(3 * e), 8 > e && (e = 8), this[a + "ScrollbarIndicator"].style["h" == a ? "width" : "height"] = e + "px"), e = 0) : e > this[a + "ScrollbarMaxScroll"] && (this.options.fixedScrollbar ? e = this[a + "ScrollbarMaxScroll"] : (e = this[a + "ScrollbarIndicatorSize"] - c.round(3 * (e - this[a + "ScrollbarMaxScroll"])), 8 > e && (e = 8), this[a + "ScrollbarIndicator"].style["h" == a ? "width" : "height"] = e + "px", e = this[a + "ScrollbarMaxScroll"] + (this[a + "ScrollbarIndicatorSize"] - e))), this[a + "ScrollbarWrapper"].style[n] = "0", this[a + "ScrollbarWrapper"].style.opacity = b && this.options.hideScrollbar ? "0" : "1", this[a + "ScrollbarIndicator"].style[d] = "translate(" + ("h" == a ? e + "px,0)" : "0," + e + "px)") + z
        },
        _start: function(a) {
            var b = v ? a.touches[0] : a,
                e, f;
            if (this.enabled) {
                this.options.onBeforeScrollStart && this.options.onBeforeScrollStart.call(this, a);
                (this.options.useTransition || this.options.zoom) && this._transitionTime(0);
                this.zoomed = this.animating = this.moved = !1;
                this.dirY = this.dirX = this.absDistY = this.absDistX = this.distY = this.distX = 0;
                if (this.options.zoom && v && 1 < a.touches.length) f = c.abs(a.touches[0].pageX - a.touches[1].pageX), e = c.abs(a.touches[0].pageY - a.touches[1].pageY), this.touchesDistStart = c.sqrt(f * f + e * e), this.originX = c.abs(a.touches[0].pageX + a.touches[1].pageX - 2 * this.wrapperOffsetLeft) / 2 - this.x, this.originY = c.abs(a.touches[0].pageY + a.touches[1].pageY - 2 * this.wrapperOffsetTop) / 2 - this.y, this.options.onZoomStart && this.options.onZoomStart.call(this, a);
                if (this.options.momentum && (this.options.useTransform ? (e = getComputedStyle(this.scroller, null)[d].replace(/[^0-9\-.,]/g, "").split(","), f = +e[4], e = +e[5]) : (f = +getComputedStyle(this.scroller, null).left.replace(/[^0-9-]/g, ""), e = +getComputedStyle(this.scroller, null).top.replace(/[^0-9-]/g, "")), f != this.x || e != this.y)) this.options.useTransition ? this._unbind(H) : D(this.aniTime), this.steps = [], this._pos(f, e), this.options.onScrollEnd && this.options.onScrollEnd.call(this);
                this.absStartX = this.x;
                this.absStartY = this.y;
                this.startX = this.x;
                this.startY = this.y;
                this.pointX = b.pageX;
                this.pointY = b.pageY;
                this.startTime = a.timeStamp || Date.now();
                this.options.onScrollStart && this.options.onScrollStart.call(this, a);
                this._bind(x, g);
                this._bind(r, g);
                this._bind(J, g)
            }
        },
        _move: function(a) {
            var b = v ? a.touches[0] : a,
                e = b.pageX - this.pointX,
                f = b.pageY - this.pointY,
                g = this.x + e,
                h = this.y + f,
                i = a.timeStamp || Date.now();
            this.options.onBeforeScrollMove && this.options.onBeforeScrollMove.call(this, a);
            if (this.options.zoom && v && 1 < a.touches.length) g = c.abs(a.touches[0].pageX - a.touches[1].pageX), h = c.abs(a.touches[0].pageY - a.touches[1].pageY), this.touchesDist = c.sqrt(g * g + h * h), this.zoomed = !0, b = 1 / this.touchesDistStart * this.touchesDist * this.scale, b < this.options.zoomMin ? b = 0.5 * this.options.zoomMin * Math.pow(2, b / this.options.zoomMin) : b > this.options.zoomMax && (b = 2 * this.options.zoomMax * Math.pow(0.5, this.options.zoomMax / b)), this.lastScale = b / this.scale, g = this.originX - this.originX * this.lastScale + this.x, h = this.originY - this.originY * this.lastScale + this.y, this.scroller.style[d] = "translate(" + g + "px," + h + "px) scale(" + b + ")" + z, this.options.onZoom && this.options.onZoom.call(this, a);
            else {
                this.pointX = b.pageX;
                this.pointY = b.pageY;
                if (0 < g || g < this.maxScrollX) g = this.options.bounce ? this.x + e / 2 : 0 <= g || 0 <= this.maxScrollX ? 0 : this.maxScrollX;
                if (h > this.minScrollY || h < this.maxScrollY) h = this.options.bounce ? this.y + f / 2 : h >= this.minScrollY || 0 <= this.maxScrollY ? this.minScrollY : this.maxScrollY;
                this.distX += e;
                this.distY += f;
                this.absDistX = c.abs(this.distX);
                this.absDistY = c.abs(this.distY);
                if (!(6 > this.absDistX && 6 > this.absDistY)) {
                    if (this.options.lockDirection) if (this.absDistX > this.absDistY + 5) h = this.y, f = 0;
                    else if (this.absDistY > this.absDistX + 5) g = this.x, e = 0;
                    this.moved = !0;
                    this._pos(g, h);
                    this.dirX = 0 < e ? -1 : 0 > e ? 1 : 0;
                    this.dirY = 0 < f ? -1 : 0 > f ? 1 : 0;
                    if (300 < i - this.startTime) this.startTime = i, this.startX = this.x, this.startY = this.y;
                    this.options.onScrollMove && this.options.onScrollMove.call(this, a)
                }
            }
        },
        _end: function(b) {
            if (!(v && 0 !== b.touches.length)) {
                var e = this,
                    h = v ? b.changedTouches[0] : b,
                    i, k, j = {
                        dist: 0,
                        time: 0
                    },
                    l = {
                        dist: 0,
                        time: 0
                    },
                    n = (b.timeStamp || Date.now()) - e.startTime,
                    m = e.x,
                    o = e.y;
                e._unbind(x, g);
                e._unbind(r, g);
                e._unbind(J, g);
                e.options.onBeforeScrollEnd && e.options.onBeforeScrollEnd.call(e, b);
                if (e.zoomed) m = e.scale * e.lastScale, m = Math.max(e.options.zoomMin, m), m = Math.min(e.options.zoomMax, m), e.lastScale = m / e.scale, e.scale = m, e.x = e.originX - e.originX * e.lastScale + e.x, e.y = e.originY - e.originY * e.lastScale + e.y, e.scroller.style[f] = "200ms", e.scroller.style[d] = "translate(" + e.x + "px," + e.y + "px) scale(" + e.scale + ")" + z, e.zoomed = !1, e.refresh(), e.options.onZoomEnd && e.options.onZoomEnd.call(e, b);
                else {
                    if (e.moved) {
                        if (300 > n && e.options.momentum) {
                            j = m ? e._momentum(m - e.startX, n, -e.x, e.scrollerW - e.wrapperW + e.x, e.options.bounce ? e.wrapperW : 0) : j;
                            l = o ? e._momentum(o - e.startY, n, -e.y, 0 > e.maxScrollY ? e.scrollerH - e.wrapperH + e.y - e.minScrollY : 0, e.options.bounce ? e.wrapperH : 0) : l;
                            m = e.x + j.dist;
                            o = e.y + l.dist;
                            if (0 < e.x && 0 < m || e.x < e.maxScrollX && m < e.maxScrollX) j = {
                                dist: 0,
                                time: 0
                            };
                            if (e.y > e.minScrollY && o > e.minScrollY || e.y < e.maxScrollY && o < e.maxScrollY) l = {
                                dist: 0,
                                time: 0
                            }
                        }
                        if (j.dist || l.dist) {
                            j = c.max(c.max(j.time, l.time), 10);
                            if (e.options.snap) l = m - e.absStartX, n = o - e.absStartY, c.abs(l) < e.options.snapThreshold && c.abs(n) < e.options.snapThreshold ? e.scrollTo(e.absStartX, e.absStartY, 200) : (l = e._snap(m, o), m = l.x, o = l.y, j = c.max(l.time, j));
                            e.scrollTo(c.round(m), c.round(o), j)
                        } else e.options.snap ? (l = m - e.absStartX, n = o - e.absStartY, c.abs(l) < e.options.snapThreshold && c.abs(n) < e.options.snapThreshold ? e.scrollTo(e.absStartX, e.absStartY, 200) : (l = e._snap(e.x, e.y), (l.x != e.x || l.y != e.y) && e.scrollTo(l.x, l.y, l.time))) : e._resetPos(200)
                    } else {
                        if (v) if (e.doubleTapTimer && e.options.zoom) clearTimeout(e.doubleTapTimer), e.doubleTapTimer = null, e.options.onZoomStart && e.options.onZoomStart.call(e, b), e.zoom(e.pointX, e.pointY, 1 == e.scale ? e.options.doubleTapZoom : 1), e.options.onZoomEnd && setTimeout(function() {
                            e.options.onZoomEnd.call(e, b)
                        }, 200);
                        else if (this.options.handleClick) e.doubleTapTimer = setTimeout(function() {
                            e.doubleTapTimer = null;
                            for (i = h.target; 1 != i.nodeType;) i = i.parentNode;
                            if ("SELECT" != i.tagName && "INPUT" != i.tagName && "TEXTAREA" != i.tagName) k = a.createEvent("MouseEvents"), k.initMouseEvent("click", !0, !0, b.view, 1, h.screenX, h.screenY, h.clientX, h.clientY, b.ctrlKey, b.altKey, b.shiftKey, b.metaKey, 0, null), k._fake = !0, i.dispatchEvent(k)
                        }, e.options.zoom ? 250 : 0);
                        e._resetPos(400)
                    }
                    e.options.onTouchEnd && e.options.onTouchEnd.call(e, b)
                }
            }
        },
        _resetPos: function(a) {
            var b = 0 <= this.x ? 0 : this.x < this.maxScrollX ? this.maxScrollX : this.x,
                c = this.y >= this.minScrollY || 0 < this.maxScrollY ? this.minScrollY : this.y < this.maxScrollY ? this.maxScrollY : this.y;
            if (b == this.x && c == this.y) {
                if (this.moved) this.moved = !1, this.options.onScrollEnd && this.options.onScrollEnd.call(this);
                if (this.hScrollbar && this.options.hideScrollbar) "webkit" == i && (this.hScrollbarWrapper.style[n] = "300ms"), this.hScrollbarWrapper.style.opacity = "0";
                if (this.vScrollbar && this.options.hideScrollbar) "webkit" == i && (this.vScrollbarWrapper.style[n] = "300ms"), this.vScrollbarWrapper.style.opacity = "0"
            } else this.scrollTo(b, c, a || 0)
        },
        _wheel: function(a) {
            var b = this,
                c, d;
            if ("wheelDeltaX" in a) c = a.wheelDeltaX / 12, d = a.wheelDeltaY / 12;
            else if ("wheelDelta" in a) c = d = a.wheelDelta / 12;
            else if ("detail" in a) c = d = 3 * -a.detail;
            else return;
            if ("zoom" == b.options.wheelAction) {
                d = b.scale * Math.pow(2, 1 / 3 * (d ? d / Math.abs(d) : 0));
                if (d < b.options.zoomMin) d = b.options.zoomMin;
                if (d > b.options.zoomMax) d = b.options.zoomMax;
                d != b.scale && (!b.wheelZoomCount && b.options.onZoomStart && b.options.onZoomStart.call(b, a), b.wheelZoomCount++, b.zoom(a.pageX, a.pageY, d, 400), setTimeout(function() {
                    b.wheelZoomCount--;
                    !b.wheelZoomCount && b.options.onZoomEnd && b.options.onZoomEnd.call(b, a)
                }, 400))
            } else {
                c = b.x + c;
                d = b.y + d;
                if (0 < c) c = 0;
                else if (c < b.maxScrollX) c = b.maxScrollX;
                if (d > b.minScrollY) d = b.minScrollY;
                else if (d < b.maxScrollY) d = b.maxScrollY;
                0 > b.maxScrollY && b.scrollTo(c, d, 0)
            }
        },
        _transitionEnd: function(a) {
            a.target == this.scroller && (this._unbind(H), this._startAni())
        },
        _startAni: function() {
            var a = this,
                b = a.x,
                d = a.y,
                e = Date.now(),
                f, g, h;
            if (!a.animating) if (a.steps.length) {
                f = a.steps.shift();
                if (f.x == b && f.y == d) f.time = 0;
                a.animating = !0;
                a.moved = !0;
                a.options.useTransition ? (a._transitionTime(f.time), a._pos(f.x, f.y), a.animating = !1, f.time ? a._bind(H) : a._resetPos(0)) : (h = function() {
                    var i = Date.now();
                    if (i >= e + f.time) a._pos(f.x, f.y), a.animating = !1, a.options.onAnimationEnd && a.options.onAnimationEnd.call(a), a._startAni();
                    else if (i = (i - e) / f.time - 1, g = c.sqrt(1 - i * i), i = (f.x - b) * g + b, a._pos(i, (f.y - d) * g + d), a.animating) a.aniTime = B(h)
                }, h())
            } else a._resetPos(400)
        },
        _transitionTime: function(a) {
            a += "ms";
            this.scroller.style[f] = a;
            this.hScrollbar && (this.hScrollbarIndicator.style[f] = a);
            this.vScrollbar && (this.vScrollbarIndicator.style[f] = a)
        },
        _momentum: function(a, b, d, e, f) {
            var b = c.abs(a) / b,
                g = b * b / 0.0012,
                h = 0,
                h = 0;
            0 < a && g > d ? (d += f / (6 / (6.0E-4 * (g / b))), b = b * d / g, g = d) : 0 > a && g > e && (e += f / (6 / (6.0E-4 * (g / b))), b = b * e / g, g = e);
            return {
                dist: g * (0 > a ? -1 : 1),
                time: c.round(b / 6.0E-4)
            }
        },
        _offset: function(a) {
            for (var b = -a.offsetLeft, c = -a.offsetTop; a = a.offsetParent;) b -= a.offsetLeft, c -= a.offsetTop;
            a != this.wrapper && (b *= this.scale, c *= this.scale);
            return {
                left: b,
                top: c
            }
        },
        _snap: function(a, b) {
            var d, e, f;
            f = this.pagesX.length - 1;
            for (d = 0, e = this.pagesX.length; d < e; d++) if (a >= this.pagesX[d]) {
                f = d;
                break
            }
            f == this.currPageX && 0 < f && 0 > this.dirX && f--;
            a = this.pagesX[f];
            e = (e = c.abs(a - this.pagesX[this.currPageX])) ? 500 * (c.abs(this.x - a) / e) : 0;
            this.currPageX = f;
            f = this.pagesY.length - 1;
            for (d = 0; d < f; d++) if (b >= this.pagesY[d]) {
                f = d;
                break
            }
            f == this.currPageY && 0 < f && 0 > this.dirY && f--;
            b = this.pagesY[f];
            d = (d = c.abs(b - this.pagesY[this.currPageY])) ? 500 * (c.abs(this.y - b) / d) : 0;
            this.currPageY = f;
            f = c.round(c.max(e, d)) || 200;
            return {
                x: a,
                y: b,
                time: f
            }
        },
        _bind: function(a, b) {
            (b || this.scroller).addEventListener(a, this, !0)
        },
        _unbind: function(a, b) {
            (b || this.scroller).removeEventListener(a, this, !0)
        },
        destroy: function() {
            this.scroller.style[d] = "";
            this.vScrollbar = this.hScrollbar = !1;
            this._scrollbar("h");
            this._scrollbar("v");
            this._unbind(q, g);
            this._unbind(s);
            this._unbind(x, g);
            this._unbind(r, g);
            this._unbind(J, g);
            this.options.hasTouch || this._unbind(F);
            this.options.useTransition && this._unbind(H);
            this.options.checkDOMChanges && clearInterval(this.checkDOMTime);
            this.options.onDestroy && this.options.onDestroy.call(this)
        },
        refresh: function() {
            var a, b, d, e = 0;
            b = 0;
            if (this.scale < this.options.zoomMin) this.scale = this.options.zoomMin;
            this.wrapperW = this.wrapper.clientWidth || 1;
            this.wrapperH = this.wrapper.clientHeight || 1;
            this.minScrollY = -this.options.topOffset || 0;
            this.scrollerW = c.round(this.scroller.offsetWidth * this.scale);
            this.scrollerH = c.round((this.scroller.offsetHeight + this.minScrollY) * this.scale);
            this.maxScrollX = this.wrapperW - this.scrollerW;
            this.maxScrollY = this.wrapperH - this.scrollerH + this.minScrollY;
            this.dirY = this.dirX = 0;
            this.options.onRefresh && this.options.onRefresh.call(this);
            this.hScroll = this.options.hScroll && 0 > this.maxScrollX;
            this.vScroll = this.options.vScroll && (!this.options.bounceLock && !this.hScroll || this.scrollerH > this.wrapperH);
            this.hScrollbar = this.hScroll && this.options.hScrollbar;
            this.vScrollbar = this.vScroll && this.options.vScrollbar && this.scrollerH > this.wrapperH;
            a = this._offset(this.wrapper);
            this.wrapperOffsetLeft = -a.left;
            this.wrapperOffsetTop = -a.top;
            if ("string" == typeof this.options.snap) {
                this.pagesX = [];
                this.pagesY = [];
                d = this.scroller.querySelectorAll(this.options.snap);
                for (a = 0, b = d.length; a < b; a++) e = this._offset(d[a]), e.left += this.wrapperOffsetLeft, e.top += this.wrapperOffsetTop, this.pagesX[a] = e.left < this.maxScrollX ? this.maxScrollX : e.left * this.scale, this.pagesY[a] = e.top < this.maxScrollY ? this.maxScrollY : e.top * this.scale
            } else if (this.options.snap) {
                for (this.pagesX = []; e >= this.maxScrollX;) this.pagesX[b] = e, e -= this.wrapperW, b++;
                this.maxScrollX % this.wrapperW && (this.pagesX[this.pagesX.length] = this.maxScrollX - this.pagesX[this.pagesX.length - 1] + this.pagesX[this.pagesX.length - 1]);
                b = e = 0;
                for (this.pagesY = []; e >= this.maxScrollY;) this.pagesY[b] = e, e -= this.wrapperH, b++;
                this.maxScrollY % this.wrapperH && (this.pagesY[this.pagesY.length] = this.maxScrollY - this.pagesY[this.pagesY.length - 1] + this.pagesY[this.pagesY.length - 1])
            }
            this._scrollbar("h");
            this._scrollbar("v");
            this.zoomed || (this.scroller.style[f] = "0", this._resetPos(400))
        },
        scrollTo: function(a, b, c, d) {
            var e = a;
            this.stop();
            e.length || (e = [{
                x: a,
                y: b,
                time: c,
                relative: d
            }]);
            for (a = 0, b = e.length; a < b; a++) {
                if (e[a].relative) e[a].x = this.x - e[a].x, e[a].y = this.y - e[a].y;
                this.steps.push({
                    x: e[a].x,
                    y: e[a].y,
                    time: e[a].time || 0
                })
            }
            this._startAni()
        },
        scrollToElement: function(a, b) {
            var d;
            if (a = a.nodeType ? a : this.scroller.querySelector(a)) d = this._offset(a), d.left += this.wrapperOffsetLeft, d.top += this.wrapperOffsetTop, d.left = 0 < d.left ? 0 : d.left < this.maxScrollX ? this.maxScrollX : d.left, d.top = d.top > this.minScrollY ? this.minScrollY : d.top < this.maxScrollY ? this.maxScrollY : d.top, b = void 0 === b ? c.max(2 * c.abs(d.left), 2 * c.abs(d.top)) : b, this.scrollTo(d.left, d.top, b)
        },
        scrollToPage: function(a, b, c) {
            c = void 0 === c ? 400 : c;
            this.options.onScrollStart && this.options.onScrollStart.call(this);
            if (this.options.snap) a = "next" == a ? this.currPageX + 1 : "prev" == a ? this.currPageX - 1 : a, b = "next" == b ? this.currPageY + 1 : "prev" == b ? this.currPageY - 1 : b, a = 0 > a ? 0 : a > this.pagesX.length - 1 ? this.pagesX.length - 1 : a, b = 0 > b ? 0 : b > this.pagesY.length - 1 ? this.pagesY.length - 1 : b, this.currPageX = a, this.currPageY = b, a = this.pagesX[a], b = this.pagesY[b];
            else {
                a *= -this.wrapperW;
                b *= -this.wrapperH;
                if (a < this.maxScrollX) a = this.maxScrollX;
                if (b < this.maxScrollY) b = this.maxScrollY
            }
            this.scrollTo(a, b, c)
        },
        disable: function() {
            this.stop();
            this._resetPos(0);
            this.enabled = !1;
            this._unbind(x, g);
            this._unbind(r, g);
            this._unbind(J, g)
        },
        enable: function() {
            this.enabled = !0
        },
        stop: function() {
            this.options.useTransition ? this._unbind(H) : D(this.aniTime);
            this.steps = [];
            this.animating = this.moved = !1
        },
        zoom: function(a, b, c, e) {
            var g = c / this.scale;
            if (this.options.useTransform) this.zoomed = !0, e = void 0 === e ? 200 : e, a = a - this.wrapperOffsetLeft - this.x, b = b - this.wrapperOffsetTop - this.y, this.x = a - a * g + this.x, this.y = b - b * g + this.y, this.scale = c, this.refresh(), this.x = 0 < this.x ? 0 : this.x < this.maxScrollX ? this.maxScrollX : this.x, this.y = this.y > this.minScrollY ? this.minScrollY : this.y < this.maxScrollY ? this.maxScrollY : this.y, this.scroller.style[f] = e + "ms", this.scroller.style[d] = "translate(" + this.x + "px," + this.y + "px) scale(" + c + ")" + z, this.zoomed = !1
        },
        isReady: function() {
            return !this.moved && !this.zoomed && !this.animating
        }
    };
    e = null;
    "undefined" !== typeof exports ? exports.iScroll = u : g.iScroll = u
})(window, document);
