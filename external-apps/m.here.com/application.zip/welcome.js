var hereWelcomeDisclaimerKey = "welcomeDisclaimerAccepted",
    hereStartUri = "index.html?back=true#bmk=1";
if (localStorage.getItem(hereWelcomeDisclaimerKey) === "true") {
    window.location = hereStartUri;
}
